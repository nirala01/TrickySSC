D = {
71: dict(
et=r"Position from right = total − position from left + 1.",
es=r"""Step 1: Sunil is 17th from the left in a row of 22, so he is \( 22 - 17 + 1 = 6 \)th from the right end.
Step 2: Facing north, "to the right" means towards the right end; Deepak is 3 places to the right of Sunil.
Step 3: Deepak's position from the right end \( = 6 - 3 = 3 \)rd.""",
hs=r"उत्तर की ओर मुख किए 22 छात्रों की एक पंक्ति में, सुनील बाएँ छोर से 17वें स्थान पर है। यदि दीपक, सुनील के दाएँ तीसरे स्थान पर है, तो दाएँ छोर से दीपक का स्थान क्या है?",
ho={"3rd": "3रा", "2nd": "2रा", "4th": "4था", "1st": "1ला"},
ht=r"दाएँ से स्थान = कुल − बाएँ से स्थान + 1।",
hx=r"""चरण 1: 22 की पंक्ति में सुनील बाएँ से 17वाँ है, अतः वह दाएँ छोर से \( 22 - 17 + 1 = 6 \)वाँ है।
चरण 2: उत्तर की ओर मुख होने पर "दाएँ" का अर्थ दाएँ छोर की ओर है; दीपक, सुनील से 3 स्थान दाएँ है।
चरण 3: दाएँ छोर से दीपक का स्थान \( = 6 - 3 = 3 \)रा।""",
),
72: dict(
et=r"Common letters share common digits; the leftover letter takes the leftover digit.",
es=r"""Step 1: DONE → 5432 uses digits {5, 4, 3, 2}; CODE → 2835 uses digits {2, 8, 3, 5}.
Step 2: The common letters O, D and E take the common digits 5, 3 and 2.
Step 3: The leftover letter N takes 4, and the leftover letter C takes 8, so C = 8.""",
hs=r"एक निश्चित कूट भाषा में, ‘DONE’ को ‘5432’ और ‘CODE’ को ‘2835’ लिखा जाता है। उस कूट भाषा में ‘C’ का कूट क्या है?",
ht=r"उभयनिष्ठ अक्षर ↔ उभयनिष्ठ अंक; बचे हुए अक्षर को बचा हुआ अंक।",
hx=r"""चरण 1: DONE → 5432 में अंक {5, 4, 3, 2} हैं; CODE → 2835 में अंक {2, 8, 3, 5} हैं।
चरण 2: उभयनिष्ठ अक्षर O, D और E के लिए उभयनिष्ठ अंक 5, 3 और 2 हैं।
चरण 3: बचे अक्षर N का कूट 4 और बचे अक्षर C का कूट 8 है, अतः C = 8।""",
),
73: dict(
et=r"Decode each symbol left to right and build the family tree.",
es=r"""Step 1: S – D: S is the brother of D. D + F: D is the son of F. So S and D are sons of F.
Step 2: F ÷ H: F is the father of H, so H is a sibling of S. H × K: H is the wife of K, so H is female and K is H's husband.
Step 3: S is the brother of K's wife H, so S is K's wife's brother.""",
hs=r"एक निश्चित कूट भाषा में,[BR]A + B का अर्थ है ‘A, B का पुत्र है’,[BR]A – B का अर्थ है ‘A, B का भाई है’,[BR]A × B का अर्थ है ‘A, B की पत्नी है’ और[BR]A ÷ B का अर्थ है ‘A, B का पिता है’।[BR]उपरोक्त के आधार पर, यदि ‘S – D + F ÷ H × K’ है, तो S का K से क्या संबंध है?",
ho={"Brother": "भाई", "Wife's brother": "पत्नी का भाई", "Father": "पिता", "Wife's father": "पत्नी के पिता"},
ht=r"हर चिह्न को बाएँ से दाएँ डिकोड करके वंश-वृक्ष बनाएँ।",
hx=r"""चरण 1: S – D: S, D का भाई है। D + F: D, F का पुत्र है। अतः S और D, F के पुत्र हैं।
चरण 2: F ÷ H: F, H का पिता है, अतः H, S की भाई-बहन है। H × K: H, K की पत्नी है, अतः H स्त्री है और K उसका पति है।
चरण 3: S, K की पत्नी H का भाई है, अतः S, K की पत्नी का भाई है।""",
),
74: dict(
et=r"Convert to the same end, then move along the row.",
es=r"""Step 1: Gagan is 13th from the right in a row of 54, so he is \( 54 - 13 + 1 = 42 \)nd from the left.
Step 2: Nitin is 17 places to the left of Gagan.
Step 3: Nitin's position from the left \( = 42 - 17 = 25 \)th.""",
hs=r"उत्तर की ओर मुख किए 54 छात्रों की एक पंक्ति में, गगन दाएँ छोर से 13वें स्थान पर है। यदि नितिन, गगन के बाएँ 17वें स्थान पर है, तो पंक्ति के बाएँ छोर से नितिन का स्थान क्या है?",
ho={"30th": "30वाँ", "27th": "27वाँ", "23rd": "23वाँ", "25th": "25वाँ"},
ht=r"एक ही छोर से स्थान लेकर पंक्ति में आगे बढ़ें।",
hx=r"""चरण 1: 54 की पंक्ति में गगन दाएँ से 13वाँ है, अतः वह बाएँ से \( 54 - 13 + 1 = 42 \)वाँ है।
चरण 2: नितिन, गगन के बाएँ 17 स्थान पर है।
चरण 3: बाएँ से नितिन का स्थान \( = 42 - 17 = 25 \)वाँ।""",
),
75: dict(
et=r"'Some' links through the middle term never guarantee a definite conclusion.",
es=r"""Step 1: All vehicles are machines (vehicles inside machines); some machines are tools (tools overlap machines somewhere).
Step 2: Conclusion (I): the tools that are machines may lie outside the vehicle part, so "some vehicles are tools" is only possible, not definite — it does not follow.
Step 3: Conclusion (II): only some machines are tools; tools may also exist outside machines, so "all tools are machines" does not follow.
Step 4: Neither conclusion (I) nor (II) follows.""",
hs=r"दिए गए कथनों और निष्कर्षों को ध्यानपूर्वक पढ़िए। कथनों में दी गई जानकारी को सत्य मानते हुए, भले ही वह सामान्य रूप से ज्ञात तथ्यों से भिन्न प्रतीत हो, निर्णय कीजिए कि दिए गए निष्कर्षों में से कौन-सा/से कथनों का तार्किक रूप से अनुसरण करता है/करते हैं।[BR]कथन:[BR]सभी वाहन, मशीनें हैं।[BR]कुछ मशीनें, औज़ार हैं।[BR]निष्कर्ष:[BR](I) कुछ वाहन, औज़ार हैं।[BR](II) सभी औज़ार, मशीनें हैं।",
ho={"Both conclusions (I) and (II) follow": "निष्कर्ष (I) और (II) दोनों अनुसरण करते हैं", "Only conclusion (I) follows": "केवल निष्कर्ष (I) अनुसरण करता है", "Only conclusion (II) follows": "केवल निष्कर्ष (II) अनुसरण करता है", "Neither conclusion (I) nor (II) follows": "न तो निष्कर्ष (I) और न ही (II) अनुसरण करता है"},
ht=r"मध्य पद से 'कुछ' का संबंध कभी निश्चित निष्कर्ष नहीं देता।",
hx=r"""चरण 1: सभी वाहन मशीनें हैं (वाहन, मशीन के भीतर); कुछ मशीनें औज़ार हैं (औज़ार कहीं मशीन से मिलते हैं)।
चरण 2: निष्कर्ष (I): मशीन वाले औज़ार वाहन वाले भाग से बाहर भी हो सकते हैं, अतः "कुछ वाहन औज़ार हैं" केवल संभव है, निश्चित नहीं — यह अनुसरण नहीं करता।
चरण 3: निष्कर्ष (II): केवल कुछ मशीनें औज़ार हैं; औज़ार मशीनों से बाहर भी हो सकते हैं, अतः "सभी औज़ार मशीनें हैं" अनुसरण नहीं करता।
चरण 4: न तो निष्कर्ष (I) और न ही (II) अनुसरण करता है।""",
),
76: dict(
et=r"Check the gaps between consecutive letters: −1, −3 in three groups.",
es=r"""Step 1: BAX: B → A is −1 and A → X is −3. SRO: S → R is −1 and R → O is −3. QPM: Q → P is −1 and P → M is −3.
Step 2: TTP: T → T is 0 and T → P is −4, which breaks the (−1, −3) pattern.
Step 3: So TTP does not belong to the group.""",
hs=r"अंग्रेज़ी वर्णमाला क्रम के आधार पर, निम्नलिखित चार में से तीन किसी निश्चित प्रकार से एक समान हैं और इस प्रकार एक समूह बनाते हैं। कौन-सा विकल्प उस समूह से संबंधित नहीं है? (ध्यान दें: असंगत, अक्षर-समूह में व्यंजनों/स्वरों की संख्या या उनके स्थान पर आधारित नहीं है।)",
ht=r"क्रमागत अक्षरों का अंतर देखें: तीन समूहों में −1, −3।",
hx=r"""चरण 1: BAX: B → A = −1 और A → X = −3। SRO: S → R = −1 और R → O = −3। QPM: Q → P = −1 और P → M = −3।
चरण 2: TTP: T → T = 0 और T → P = −4, जो (−1, −3) प्रतिरूप को तोड़ता है।
चरण 3: अतः TTP समूह से संबंधित नहीं है।""",
),
77: dict(
et=r"Each letter of the first cluster moves +3 to give the second.",
es=r"""Step 1: DIP : GLS — D + 3 = G, I + 3 = L, P + 3 = S. BST : EVW — B + 3 = E, S + 3 = V, T + 3 = W.
Step 2: Check each pair: CIG → FLJ (not FKJ); TEL → WHO (not VHP); EHL → HKO (not IFP).
Step 3: HKD → H + 3 = K, K + 3 = N, D + 3 = G, i.e. KNG — the same +3 pattern.""",
hs=r"उस युग्म का चयन कीजिए जो उसी प्रतिरूप का अनुसरण करता है जिसका अनुसरण नीचे दिए गए दो युग्म करते हैं। दोनों युग्म एक ही प्रतिरूप का अनुसरण करते हैं।[BR]\( \text{DIP} : \text{GLS} \)[BR]\( \text{BST} : \text{EVW} \)",
ht=r"पहले समूह का हर अक्षर +3 चलकर दूसरा समूह बनाता है।",
hx=r"""चरण 1: DIP : GLS — D + 3 = G, I + 3 = L, P + 3 = S। BST : EVW — B + 3 = E, S + 3 = V, T + 3 = W।
चरण 2: हर युग्म जाँचें: CIG → FLJ (FKJ नहीं); TEL → WHO (VHP नहीं); EHL → HKO (IFP नहीं)।
चरण 3: HKD → H + 3 = K, K + 3 = N, D + 3 = G, अर्थात KNG — वही +3 प्रतिरूप।""",
),
78: dict(
et=r"Third number = first × second.",
es=r"""Step 1: (2, 7, 14): \( 2 \times 7 = 14 \). (3, 16, 48): \( 3 \times 16 = 48 \). So third = first × second.
Step 2: (8, 6, 56): \( 8 \times 6 = 48 \ne 56 \); (6, 7, 48): \( 6 \times 7 = 42 \ne 48 \); (4, 6, 20): \( 4 \times 6 = 24 \ne 20 \).
Step 3: (5, 3, 15): \( 5 \times 3 = 15 \) — it follows the same rule.""",
hs=r"उस समुच्चय का चयन कीजिए जिसमें संख्याएँ उसी प्रकार संबंधित हैं जिस प्रकार निम्नलिखित समुच्चयों की संख्याएँ संबंधित हैं।[BR](ध्यान दें: संक्रियाएँ पूर्ण संख्याओं पर की जानी चाहिए, संख्याओं को उनके घटक अंकों में तोड़े बिना। उदाहरण: 13 – 13 पर संक्रियाएँ जैसे 13 में जोड़ना/घटाना/गुणा करना आदि किया जा सकता है। 13 को 1 और 3 में तोड़कर फिर 1 और 3 पर गणितीय संक्रियाएँ करने की अनुमति नहीं है।)[BR](2, 7, 14)[BR](3, 16, 48)",
ht=r"तीसरी संख्या = पहली × दूसरी।",
hx=r"""चरण 1: (2, 7, 14): \( 2 \times 7 = 14 \)। (3, 16, 48): \( 3 \times 16 = 48 \)। अतः तीसरी = पहली × दूसरी।
चरण 2: (8, 6, 56): \( 8 \times 6 = 48 \ne 56 \); (6, 7, 48): \( 6 \times 7 = 42 \ne 48 \); (4, 6, 20): \( 4 \times 6 = 24 \ne 20 \)।
चरण 3: (5, 3, 15): \( 5 \times 3 = 15 \) — यह उसी नियम का पालन करता है।""",
),
79: dict(
et=r"Facing the centre: left = clockwise, right = anticlockwise.",
es=r"""Step 1: Number the 7 seats clockwise 0–6 (for people facing the centre, left = clockwise). Put B at 0. A is to the immediate right of B, so A = 6; J is third to the left of B, so J = 3.
Step 2: A is second to the left of O, so O = 6 − 2 = 4. Two people sit between O and D counted from the left of D, so O = D + 3 and D = 1.
Step 3: Z is an immediate neighbour of J (3); seat 4 is O, so Z = 2, and T takes seat 5.
Step 4: From the right of O (anticlockwise): O(4) → J(3) → Z(2), so only one person sits between O and Z.""",
hs=r"A, B, D, J, O, T और Z एक वृत्ताकार मेज़ के चारों ओर केंद्र की ओर मुख करके बैठे हैं। D के बाएँ से गिनने पर O और D के बीच केवल दो व्यक्ति बैठे हैं। J, B के बाएँ तीसरे स्थान पर बैठा है। A, B के ठीक दाएँ बैठा है। A, O के बाएँ दूसरे स्थान पर बैठा है। Z, J का निकटतम पड़ोसी है। O के दाएँ से गिनने पर O और Z के बीच कितने व्यक्ति बैठे हैं?",
ho={"Three": "तीन", "Four": "चार", "One": "एक", "Two": "दो"},
ht=r"केंद्र की ओर मुख: बायाँ = दक्षिणावर्त, दायाँ = वामावर्त।",
hx=r"""चरण 1: 7 सीटों को दक्षिणावर्त 0–6 क्रमांकित करें (केंद्र की ओर मुख होने पर बायाँ = दक्षिणावर्त)। B को 0 पर रखें। A, B के ठीक दाएँ है, अतः A = 6; J, B के बाएँ तीसरा है, अतः J = 3।
चरण 2: A, O के बाएँ दूसरा है, अतः O = 6 − 2 = 4। D के बाएँ से गिनने पर O और D के बीच दो व्यक्ति हैं, अतः O = D + 3 और D = 1।
चरण 3: Z, J (3) का निकटतम पड़ोसी है; सीट 4 पर O है, अतः Z = 2, और T सीट 5 पर।
चरण 4: O के दाएँ से (वामावर्त): O(4) → J(3) → Z(2), अतः O और Z के बीच केवल एक व्यक्ति है।""",
),
80: dict(
et=r"Decode the chain step by step: A → C → E/F across generations.",
es=r"""Step 1: A + B: A is the father of B. B ÷ C: B is the brother of C, so A is also C's father.
Step 2: C – D: C is the husband of D. D × E: D is the mother of E, so C is E's father. E ÷ F: E is the brother of F, so C is also F's father.
Step 3: A is the father of C, who is the father of F, so A is F's father's father.""",
hs=r"एक निश्चित कूट भाषा में,[BR]J ÷ Q का अर्थ है ‘J, Q का भाई है’,[BR]J × Q का अर्थ है ‘J, Q की माँ है’,[BR]J – Q का अर्थ है ‘J, Q का पति है’ और[BR]J + Q का अर्थ है ‘J, Q का पिता है’।[BR]उपरोक्त के आधार पर, यदि ‘A + B ÷ C – D × E ÷ F’ है, तो A का F से क्या संबंध है?",
ho={"Mother's brother": "माँ का भाई", "Father's father": "पिता के पिता", "Mother's father": "माँ के पिता", "Wife's father": "पत्नी के पिता"},
ht=r"कड़ी को क्रम से डिकोड करें: A → C → E/F पीढ़ी-दर-पीढ़ी।",
hx=r"""चरण 1: A + B: A, B का पिता है। B ÷ C: B, C का भाई है, अतः A, C का भी पिता है।
चरण 2: C – D: C, D का पति है। D × E: D, E की माँ है, अतः C, E का पिता है। E ÷ F: E, F का भाई है, अतः C, F का भी पिता है।
चरण 3: A, C का पिता है और C, F का पिता है, अतः A, F के पिता के पिता हैं।""",
),
81: dict(
et=r"Fix V and F first, then place N, E, G, and finally Y and C.",
es=r"""Step 1: Number the seats 1–7 from the left. Two people sit to the left of V, so V = 3. F is fourth from the right end, so F = 4.
Step 2: Two people sit between N and V, so N = 6 (seat 0 does not exist). E is the neighbour of both G and V; seat 4 is F, so E = 2 and G = 1.
Step 3: Y and C take seats 5 and 7; Y is not to the right of C, so Y = 5 and C = 7.
Step 4: Between Y (5) and E (2) sit V (3) and F (4), i.e. two people.""",
hs=r"सात व्यक्ति N, V, C, Y, E, F और G एक पंक्ति में उत्तर की ओर मुख करके बैठे हैं। V के बाएँ केवल दो व्यक्ति बैठे हैं। F दाएँ छोर से चौथे स्थान पर बैठा है। N और V के बीच केवल दो व्यक्ति बैठे हैं। E, G और V दोनों का निकटतम पड़ोसी है। Y, C के दाएँ नहीं बैठा है।[BR]Y और E के बीच कितने व्यक्ति बैठे हैं?",
ho={"Five": "पाँच", "Four": "चार", "Two": "दो", "Three": "तीन"},
ht=r"पहले V और F तय करें, फिर N, E, G, और अंत में Y व C।",
hx=r"""चरण 1: बाएँ से सीटें 1–7 मानें। V के बाएँ दो व्यक्ति हैं, अतः V = 3। F दाएँ छोर से चौथा है, अतः F = 4।
चरण 2: N और V के बीच दो व्यक्ति हैं, अतः N = 6 (सीट 0 नहीं है)। E, G और V दोनों का पड़ोसी है; सीट 4 पर F है, अतः E = 2 और G = 1।
चरण 3: Y और C सीट 5 और 7 पर हैं; Y, C के दाएँ नहीं है, अतः Y = 5 और C = 7।
चरण 4: Y (5) और E (2) के बीच V (3) और F (4) हैं, अर्थात दो व्यक्ति।""",
),
82: dict(
et=r"Every letter position moves −3 from one term to the next.",
es=r"""Step 1: First letters: M, J, G, D → each −3, so the next is A.
Step 2: Second letters: F, C, Z, W → each −3 (C − 3 wraps to Z), so the next is T.
Step 3: Third letters: J, G, D, A → each −3, so the next is X (A − 3 wraps to X). The answer is ATX.""",
hs=r"अंग्रेज़ी वर्णमाला क्रम के आधार पर दी गई श्रृंखला में '?' के स्थान पर क्या आना चाहिए?[BR]MFJ JCG GZD DWA ?",
ht=r"हर अक्षर-स्थान अगले पद में −3 चलता है।",
hx=r"""चरण 1: पहले अक्षर: M, J, G, D → हर बार −3, अतः अगला A।
चरण 2: दूसरे अक्षर: F, C, Z, W → हर बार −3 (C − 3 घूमकर Z), अतः अगला T।
चरण 3: तीसरे अक्षर: J, G, D, A → हर बार −3, अतः अगला X (A − 3 घूमकर X)। उत्तर ATX है।""",
),
83: dict(
et=r"Scan each even digit: left neighbour ∈ {1, 4, 9}, right neighbour odd.",
es=r"""Step 1: Perfect squares among single digits: 1, 4 and 9. Look at every even digit with its two neighbours.
Step 2: 1 4 9 (6th digit 4: preceded by 1, followed by 9) ✓; 1 4 3 (17th digit 4: preceded by 1, followed by 3) ✓.
Step 3: The others fail: 4 6 2 (followed by an even digit), 4 2 2 (followed by an even digit), and the rest are not preceded by 1, 4 or 9.
Step 4: Total = 2.""",
hs=r"निम्नलिखित श्रृंखला को देखकर प्रश्न का उत्तर दीजिए। (गिनती केवल बाएँ से दाएँ की जाए।) (सभी संख्याएँ केवल एक-अंकीय हैं।)[BR](बाएँ) 4 6 2 9 1 4 9 7 1 7 6 5 3 6 4 1 4 3 8 4 2 2 3 9 9 7 6 (दाएँ)[BR]ऐसे कितने सम अंक हैं, जिनमें से प्रत्येक के ठीक पहले एक पूर्ण वर्ग और ठीक बाद एक विषम अंक है? (ध्यान दें: 1 भी एक पूर्ण वर्ग है।)",
ho={"One": "एक", "None": "कोई नहीं", "Three": "तीन", "Two": "दो"},
ht=r"हर सम अंक देखें: बायाँ पड़ोसी ∈ {1, 4, 9}, दायाँ पड़ोसी विषम।",
hx=r"""चरण 1: एक-अंकीय पूर्ण वर्ग: 1, 4 और 9। हर सम अंक को उसके दोनों पड़ोसियों के साथ देखें।
चरण 2: 1 4 9 (6ठा अंक 4: पहले 1, बाद में 9) ✓; 1 4 3 (17वाँ अंक 4: पहले 1, बाद में 3) ✓।
चरण 3: बाकी विफल हैं: 4 6 2 (बाद में सम अंक), 4 2 2 (बाद में सम अंक), और शेष के पहले 1, 4 या 9 नहीं है।
चरण 4: कुल = 2।""",
),
84: dict(
et=r"Letters: each −1; numbers: −5.",
es=r"""Step 1: First letters G, F, E, D → next C. Second letters D, C, B, A → next Z (A − 1 wraps to Z). Third letters H, G, F, E → next D.
Step 2: Numbers 66, 61, 56, 51 fall by 5 each, so the next number is 46.
Step 3: The missing term is CZD 46.""",
hs=r"दी गई श्रृंखला को तार्किक रूप से पूर्ण करने के लिए निम्नलिखित में से कौन-सा अक्षर-संख्या समूह प्रश्न चिह्न (?) का स्थान लेगा?[BR]GDH 66 FCG 61 EBF 56 DAE 51 ?",
ht=r"अक्षर: हर एक −1; संख्याएँ: −5।",
hx=r"""चरण 1: पहले अक्षर G, F, E, D → अगला C। दूसरे अक्षर D, C, B, A → अगला Z (A − 1 घूमकर Z)। तीसरे अक्षर H, G, F, E → अगला D।
चरण 2: संख्याएँ 66, 61, 56, 51 हर बार 5 घटती हैं, अतः अगली संख्या 46।
चरण 3: लुप्त पद CZD 46 है।""",
),
85: dict(
et=r"First letter +2, second letter −5, number −14.",
es=r"""Step 1: QX 18 → SS 4: Q + 2 = S, X − 5 = S, \( 18 - 14 = 4 \).
Step 2: EL 10 → GG −4: E + 2 = G, L − 5 = G, \( 10 - 14 = -4 \). The rule is confirmed.
Step 3: IJ 5 → I + 2 = K, J − 5 = E, \( 5 - 14 = -9 \), giving KE −9.""",
hs=r"QX 18 का संबंध SS 4 से एक निश्चित प्रकार से है। उसी प्रकार, EL 10 का संबंध GG -4 से है। उसी तर्क का पालन करते हुए IJ 5 का संबंध निम्नलिखित में से किससे है?",
ht=r"पहला अक्षर +2, दूसरा अक्षर −5, संख्या −14।",
hx=r"""चरण 1: QX 18 → SS 4: Q + 2 = S, X − 5 = S, \( 18 - 14 = 4 \)।
चरण 2: EL 10 → GG −4: E + 2 = G, L − 5 = G, \( 10 - 14 = -4 \)। नियम की पुष्टि हुई।
चरण 3: IJ 5 → I + 2 = K, J − 5 = E, \( 5 - 14 = -9 \), अर्थात KE −9।""",
),
86: dict(
et=r"Letters jump +9 (wrapping after Z); numbers fall by 5.",
es=r"""Step 1: Letter positions: R = 18, A = 1, J = 10, S = 19. R + 9 = 27 → 27 − 26 = 1 (A), A + 9 = J, J + 9 = S.
Step 2: Next letter: S + 9 = 28 → 28 − 26 = 2, i.e. B.
Step 3: Numbers 45, 40, 35, 30 fall by 5, so the next is 25. The answer is B 25.""",
hs=r"अंग्रेज़ी वर्णमाला क्रम के आधार पर दी गई श्रृंखला में ‘?’ के स्थान पर निम्नलिखित में से कौन-सा आना चाहिए?[BR]R 45, A 40, J 35, S 30, ?",
ht=r"अक्षर +9 (Z के बाद फिर A से); संख्याएँ −5।",
hx=r"""चरण 1: अक्षर-स्थान: R = 18, A = 1, J = 10, S = 19। R + 9 = 27 → 27 − 26 = 1 (A), A + 9 = J, J + 9 = S।
चरण 2: अगला अक्षर: S + 9 = 28 → 28 − 26 = 2, अर्थात B।
चरण 3: संख्याएँ 45, 40, 35, 30 हर बार 5 घटती हैं, अतः अगली 25। उत्तर B 25 है।""",
),
87: dict(
et=r"Pattern +3, +2, −7 across the four letters; EH-JB breaks it.",
es=r"""Step 1: LO-QJ: L → O (+3), O → Q (+2), Q → J (−7). OR-TM: O → R (+3), R → T (+2), T → M (−7). HK-MF: H → K (+3), K → M (+2), M → F (−7).
Step 2: EH-JB: E → H (+3), H → J (+2), but J → B is −8, not −7.
Step 3: So EH-JB does not belong to the group.""",
hs=r"अंग्रेज़ी वर्णमाला क्रम के आधार पर, निम्नलिखित चार अक्षर-समूह युग्मों में से तीन किसी निश्चित प्रकार से एक समान हैं और इस प्रकार एक समूह बनाते हैं। कौन-सा युग्म उस समूह से संबंधित नहीं है? (ध्यान दें: असंगत, अक्षर-समूह में व्यंजनों/स्वरों की संख्या या उनके स्थान पर आधारित नहीं है।)",
ht=r"चारों अक्षरों में +3, +2, −7 का क्रम; EH-JB इसे तोड़ता है।",
hx=r"""चरण 1: LO-QJ: L → O (+3), O → Q (+2), Q → J (−7)। OR-TM: O → R (+3), R → T (+2), T → M (−7)। HK-MF: H → K (+3), K → M (+2), M → F (−7)।
चरण 2: EH-JB: E → H (+3), H → J (+2), पर J → B = −8 है, −7 नहीं।
चरण 3: अतः EH-JB समूह से संबंधित नहीं है।""",
),
88: dict(
et=r"Sort the digits, then read the required positions.",
es=r"""Step 1: The digits of 52178436 in ascending order give 12345678.
Step 2: Third from the left is 3; third from the right is 6.
Step 3: Sum \( = 3 + 6 = 9 \).""",
hs=r"संख्या 52178436 के प्रत्येक अंक को बाएँ से दाएँ आरोही क्रम में व्यवस्थित किया जाता है। इस प्रकार बनी संख्या में बाएँ से तीसरे और दाएँ से तीसरे अंकों का योग क्या होगा?",
ht=r"अंकों को क्रम में लगाकर माँगे गए स्थान पढ़ें।",
hx=r"""चरण 1: 52178436 के अंकों को आरोही क्रम में लगाने पर 12345678 बनता है।
चरण 2: बाएँ से तीसरा अंक 3 है; दाएँ से तीसरा अंक 6 है।
चरण 3: योग \( = 3 + 6 = 9 \)।""",
),
89: dict(
et=r"Differences are 3, 6, 9, 12, 15.",
es=r"""Step 1: The known differences 85 → 97 = 12 and 97 → 112 = 15 suggest differences that rise by 3.
Step 2: So the differences are 3, 6, 9, 12, 15: \( 67 + 3 = 70 \), \( 70 + 6 = 76 \).
Step 3: Check: \( 76 + 9 = 85 \) ✓, so the missing number is 76.""",
hs=r"दी गई श्रृंखला में ‘?’ के स्थान पर क्या आना चाहिए?[BR]67 70 ? 85 97 112",
ht=r"अंतर 3, 6, 9, 12, 15 हैं।",
hx=r"""चरण 1: ज्ञात अंतर 85 → 97 = 12 और 97 → 112 = 15 बताते हैं कि अंतर 3-3 बढ़ रहे हैं।
चरण 2: अतः अंतर 3, 6, 9, 12, 15 हैं: \( 67 + 3 = 70 \), \( 70 + 6 = 76 \)।
चरण 3: जाँच: \( 76 + 9 = 85 \) ✓, अतः लुप्त संख्या 76 है।""",
),
90: dict(
et=r"Find each D, check vowel before and consonant after.",
es=r"""Step 1: Vowels in the series: A, E, U. List every D with its neighbours: K D D, D D U, U D E, Q D V, A D R, R D G, G D E, E D Z, Z D J.
Step 2: Preceded by a vowel: U D E, A D R and E D Z. U D E fails because E after it is a vowel.
Step 3: A D R and E D Z qualify, so there are two such D's.""",
hs=r"निम्नलिखित अक्षर श्रृंखला को देखकर आगे दिए गए प्रश्न का उत्तर दीजिए। गिनती केवल बाएँ से दाएँ की जाए।[BR](बाएँ) K D D U R V U D E C Q D V A D R D G D E D Z D J (दाएँ)[BR]ऐसे कितने D हैं, जिनमें से प्रत्येक के ठीक पहले एक स्वर और ठीक बाद एक व्यंजन है?",
ho={"Two": "दो", "Three": "तीन", "Five": "पाँच", "Four": "चार"},
ht=r"हर D के पहले स्वर और बाद में व्यंजन जाँचें।",
hx=r"""चरण 1: श्रृंखला में स्वर: A, E, U। हर D को उसके पड़ोसियों के साथ लिखें: K D D, D D U, U D E, Q D V, A D R, R D G, G D E, E D Z, Z D J।
चरण 2: पहले स्वर वाले: U D E, A D R और E D Z। U D E विफल है क्योंकि उसके बाद E स्वर है।
चरण 3: A D R और E D Z मान्य हैं, अतः ऐसे दो D हैं।""",
),
91: dict(
et=r"Vowels +1, consonants −1, then count from the right.",
es=r"""Step 1: CURRENT: consonants C, R, R, N, T move back one (B, Q, Q, M, S); vowels U, E move forward one (V, F).
Step 2: The new group is B V Q Q F M S.
Step 3: Third from the right: S (1st), M (2nd), F (3rd) — the letter is F.""",
hs=r"शब्द CURRENT में प्रत्येक स्वर को अंग्रेज़ी वर्णमाला क्रम में उसके ठीक बाद वाले अक्षर से और प्रत्येक व्यंजन को अंग्रेज़ी वर्णमाला क्रम में उसके ठीक पहले वाले अक्षर से बदल दिया जाता है। इस प्रकार बने नए अक्षर-समूह में दाएँ से तीसरा अक्षर निम्नलिखित में से कौन-सा होगा?",
ht=r"स्वर +1, व्यंजन −1, फिर दाएँ से गिनें।",
hx=r"""चरण 1: CURRENT: व्यंजन C, R, R, N, T एक पीछे (B, Q, Q, M, S); स्वर U, E एक आगे (V, F)।
चरण 2: नया समूह B V Q Q F M S है।
चरण 3: दाएँ से तीसरा: S (1), M (2), F (3) — अक्षर F है।""",
),
92: dict(
et=r"Common letters share common digits; B and C take the leftovers.",
es=r"""Step 1: BRAK → 4938 uses digits {4, 9, 3, 8}; ARCK → 2849 uses digits {2, 8, 4, 9}.
Step 2: The common letters A, R and K take the common digits 4, 9 and 8.
Step 3: The leftover letter B takes 3, and C takes the leftover digit 2, so C = 2.""",
hs=r"एक निश्चित कूट भाषा में, ‘BRAK’ को ‘4938’ और ‘ARCK’ को ‘2849’ लिखा जाता है। उस कूट भाषा में ‘C’ का कूट क्या है?",
ht=r"उभयनिष्ठ अक्षर ↔ उभयनिष्ठ अंक; B और C को बचे अंक।",
hx=r"""चरण 1: BRAK → 4938 में अंक {4, 9, 3, 8} हैं; ARCK → 2849 में अंक {2, 8, 4, 9} हैं।
चरण 2: उभयनिष्ठ अक्षर A, R और K के लिए उभयनिष्ठ अंक 4, 9 और 8 हैं।
चरण 3: बचा अक्षर B का कूट 3, और C का कूट बचा अंक 2, अतः C = 2।""",
),
93: dict(
et=r"Fix O on top, then S and M; the Q–P gap decides Q.",
es=r"""Step 1: Number the positions 1 (top) to 7 (bottom). No box is above O, so O = 1. Three boxes are between O and S, so S = 5; M is immediately above S, so M = 4.
Step 2: One box is between Q and M, so Q = 2 or 6. Four boxes are between Q and P: Q = 2 gives P = 7, while Q = 6 would need P = 1 (taken). So Q = 2 and P = 7.
Step 3: R and N fill positions 3 and 6, and R is above N, so R = 3 and N = 6.
Step 4: The box second below R (3) is at position 5, i.e. S.""",
hs=r"सात बक्से M, N, O, P, Q, R और S एक के ऊपर एक रखे हैं, परंतु आवश्यक नहीं कि इसी क्रम में हों। O के ऊपर कोई बक्सा नहीं रखा है। O और S के बीच केवल तीन बक्से रखे हैं। Q और M के बीच केवल एक बक्सा रखा है। M, S के ठीक ऊपर रखा है। Q और P के बीच केवल चार बक्से रखे हैं। R, N के ऊपर किसी स्थान पर रखा है।[BR]R के नीचे दूसरे स्थान पर कौन-सा बक्सा रखा है?",
ht=r"O सबसे ऊपर, फिर S और M; Q–P का अंतर Q तय करता है।",
hx=r"""चरण 1: स्थान 1 (ऊपर) से 7 (नीचे) मानें। O के ऊपर कोई बक्सा नहीं, अतः O = 1। O और S के बीच तीन बक्से, अतः S = 5; M, S के ठीक ऊपर, अतः M = 4।
चरण 2: Q और M के बीच एक बक्सा, अतः Q = 2 या 6। Q और P के बीच चार बक्से: Q = 2 से P = 7, जबकि Q = 6 के लिए P = 1 चाहिए (भरा हुआ)। अतः Q = 2 और P = 7।
चरण 3: R और N स्थान 3 और 6 पर हैं, और R, N के ऊपर है, अतः R = 3 और N = 6।
चरण 4: R (3) के नीचे दूसरा स्थान 5 है, अर्थात S।""",
),
94: dict(
et=r"Differences are perfect squares 1, 4, 9, 16, 25.",
es=r"""Step 1: The known differences are 10 → 19 = 9, 19 → 35 = 16 and 35 → 60 = 25 — consecutive squares.
Step 2: So the first two differences are \( 1^{2} = 1 \) and \( 2^{2} = 4 \): \( 5 + 1 = 6 \).
Step 3: Check: \( 6 + 4 = 10 \) ✓, so the missing number is 6.""",
hs=r"दी गई श्रृंखला में ‘?’ के स्थान पर क्या आना चाहिए?[BR]5 ? 10 19 35 60",
ht=r"अंतर पूर्ण वर्ग 1, 4, 9, 16, 25 हैं।",
hx=r"""चरण 1: ज्ञात अंतर 10 → 19 = 9, 19 → 35 = 16 और 35 → 60 = 25 — क्रमागत वर्ग हैं।
चरण 2: अतः पहले दो अंतर \( 1^{2} = 1 \) और \( 2^{2} = 4 \) हैं: \( 5 + 1 = 6 \)।
चरण 3: जाँच: \( 6 + 4 = 10 \) ✓, अतः लुप्त संख्या 6 है।""",
),
95: dict(
et=r"Track (x, y) after every leg; the final offset gives distance and direction.",
es=r"""Step 1: Start at A (0, 0). 16 km south → (0, −16). Right turn (now west), 14 km → (−14, −16). Right (north), 44 km → (−14, 28).
Step 2: Right (east), 2 km → (−12, 28). Right (south), 15 km → (−12, 13). Left (east), 21 km → (9, 13). Right (south), 13 km → (9, 0) = P.
Step 3: P is 9 km east of A, so he must drive 9 km to the West to reach A.""",
hs=r"श्री योर्ली बिंदु A से शुरू करके दक्षिण की ओर 16 km गाड़ी चलाते हैं। फिर वे दाएँ मुड़कर 14 km चलाते हैं, दाएँ मुड़कर 44 km चलाते हैं। फिर वे दाएँ मुड़कर 2 km चलाते हैं, दाएँ मुड़कर 15 km चलाते हैं। फिर वे बाएँ मुड़कर 21 km चलाते हैं। वे अंतिम बार दाएँ मुड़कर 13 km चलाते हैं और बिंदु P पर रुक जाते हैं। बिंदु A पर फिर से पहुँचने के लिए उन्हें कितनी दूर (सबसे छोटी दूरी) और किस दिशा में गाड़ी चलानी चाहिए? (जब तक निर्दिष्ट न हो, सभी मोड़ केवल 90 डिग्री के हैं।)",
ho={"9 km to the West": "पश्चिम की ओर 9 km", "16 km to the North": "उत्तर की ओर 16 km", "11 km to the South": "दक्षिण की ओर 11 km", "10 km to the East": "पूर्व की ओर 10 km"},
ht=r"हर चरण के बाद (x, y) देखें; अंतिम विस्थापन से दूरी और दिशा।",
hx=r"""चरण 1: A (0, 0) से शुरू। 16 km दक्षिण → (0, −16)। दाएँ (अब पश्चिम), 14 km → (−14, −16)। दाएँ (उत्तर), 44 km → (−14, 28)।
चरण 2: दाएँ (पूर्व), 2 km → (−12, 28)। दाएँ (दक्षिण), 15 km → (−12, 13)। बाएँ (पूर्व), 21 km → (9, 13)। दाएँ (दक्षिण), 13 km → (9, 0) = P।
चरण 3: P, A से 9 km पूर्व में है, अतः A पहुँचने के लिए उन्हें पश्चिम की ओर 9 km चलाना होगा।""",
),
96: dict(
et=r"Every letter moves +5.",
es=r"""Step 1: JDHK → OIMP: J + 5 = O, D + 5 = I, H + 5 = M, K + 5 = P.
Step 2: MGKN → RLPS confirms the same +5 shift.
Step 3: PJNQ → P + 5 = U, J + 5 = O, N + 5 = S, Q + 5 = V, i.e. UOSV.""",
hs=r"अंग्रेज़ी वर्णमाला क्रम के आधार पर JDHK एक निश्चित प्रकार से OIMP से संबंधित है। उसी प्रकार MGKN, RLPS से संबंधित है। उसी तर्क का पालन करते हुए PJNQ निम्नलिखित में से किससे संबंधित है?",
ht=r"हर अक्षर +5 चलता है।",
hx=r"""चरण 1: JDHK → OIMP: J + 5 = O, D + 5 = I, H + 5 = M, K + 5 = P।
चरण 2: MGKN → RLPS से वही +5 नियम पुष्ट होता है।
चरण 3: PJNQ → P + 5 = U, J + 5 = O, N + 5 = S, Q + 5 = V, अर्थात UOSV।""",
),
97: dict(
et=r"Write original and sorted numbers one above the other; count matches.",
es=r"""Step 1: Original: 1 3 5 8 2 7 4. Arranged in ascending order: 1 2 3 4 5 7 8.
Step 2: Compare position by position: 1st (1 = 1) ✓, 6th (7 = 7) ✓; all other positions differ.
Step 3: The positions of two digits remain unchanged.""",
hs=r"संख्या 1358274 के प्रत्येक अंक को बाएँ से दाएँ आरोही क्रम में व्यवस्थित किया जाता है। मूल संख्या की तुलना में कितने अंकों का स्थान अपरिवर्तित रहेगा?",
ho={"One": "एक", "Zero": "शून्य", "Three": "तीन", "Two": "दो"},
ht=r"मूल और क्रमबद्ध संख्या को एक-दूसरे के नीचे लिखकर मेल गिनें।",
hx=r"""चरण 1: मूल: 1 3 5 8 2 7 4। आरोही क्रम में: 1 2 3 4 5 7 8।
चरण 2: स्थान-दर-स्थान तुलना: पहला (1 = 1) ✓, छठा (7 = 7) ✓; बाकी सभी स्थान अलग हैं।
चरण 3: दो अंकों का स्थान अपरिवर्तित रहता है।""",
),
98: dict(
et=r"Sort the digits, then read the required positions.",
es=r"""Step 1: The digits of 36857219 in ascending order give 12356789.
Step 2: Second from the left is 2; third from the right is 7.
Step 3: Sum \( = 2 + 7 = 9 \).""",
hs=r"संख्या 36857219 के प्रत्येक अंक को बाएँ से दाएँ आरोही क्रम में व्यवस्थित किया जाता है। इस प्रकार बनी नई संख्या में बाएँ से दूसरे और दाएँ से तीसरे अंकों का योग क्या होगा?",
ht=r"अंकों को क्रम में लगाकर माँगे गए स्थान पढ़ें।",
hx=r"""चरण 1: 36857219 के अंकों को आरोही क्रम में लगाने पर 12356789 बनता है।
चरण 2: बाएँ से दूसरा अंक 2 है; दाएँ से तीसरा अंक 7 है।
चरण 3: योग \( = 2 + 7 = 9 \)।""",
),
99: dict(
et=r"Three clusters move +2, +2; CEH moves +2, +3.",
es=r"""Step 1: PRT: P → R (+2), R → T (+2). HJL: H → J (+2), J → L (+2). SUW: S → U (+2), U → W (+2).
Step 2: CEH: C → E (+2), E → H (+3), which breaks the (+2, +2) pattern.
Step 3: So CEH does not belong to the group.""",
hs=r"वर्णमाला क्रम के आधार पर, निम्नलिखित चार में से तीन किसी निश्चित प्रकार से एक समान हैं और इस प्रकार एक समूह बनाते हैं। कौन-सा विकल्प उस समूह से संबंधित नहीं है? (ध्यान दें: असंगत, अक्षर-समूह में व्यंजनों/स्वरों की संख्या या उनके स्थान पर आधारित नहीं है।)",
ht=r"तीन समूह +2, +2 चलते हैं; CEH +2, +3।",
hx=r"""चरण 1: PRT: P → R (+2), R → T (+2)। HJL: H → J (+2), J → L (+2)। SUW: S → U (+2), U → W (+2)।
चरण 2: CEH: C → E (+2), E → H (+3), जो (+2, +2) प्रतिरूप को तोड़ता है।
चरण 3: अतः CEH समूह से संबंधित नहीं है।""",
),
100: dict(
et=r"Teachers ∩ Dentists, outside Surgeons = the single overlap region of those two circles only.",
es=r"""Step 1: In the diagram, the region common to Teachers and Dentists but outside Surgeons holds 29.
Step 2: The central 23 is also inside Surgeons, so it is excluded; 16 (Teachers ∩ Surgeons) and 10 (Dentists ∩ Surgeons) are not Teacher–Dentist regions outside Surgeons.
Step 3: Teachers who are also Dentists but not Surgeons = 29.""",
hs=r"[FIGURE-BASED] दिए गए आरेख का ध्यानपूर्वक अध्ययन करके प्रश्न का उत्तर दीजिए। विभिन्न भागों में दी गई संख्याएँ व्यक्तियों की संख्या दर्शाती हैं। (ध्यान दें: दिए गए आँकड़ों को सत्य मानें, भले ही वे सामान्य रूप से ज्ञात तथ्यों से भिन्न प्रतीत हों।)[BR]ऐसे कितने शिक्षक हैं जो दंत चिकित्सक भी हैं परंतु शल्य चिकित्सक नहीं हैं?",
ht=r"शिक्षक ∩ दंत चिकित्सक, शल्य चिकित्सक से बाहर = केवल इन दो वृत्तों का साझा भाग।",
hx=r"""चरण 1: आरेख में शिक्षक और दंत चिकित्सक का साझा परंतु शल्य चिकित्सक से बाहर का भाग 29 है।
चरण 2: केंद्र का 23 शल्य चिकित्सक के भीतर भी है, अतः यह छोड़ा जाता है; 16 (शिक्षक ∩ शल्य) और 10 (दंत ∩ शल्य) शल्य से बाहर के शिक्षक–दंत भाग नहीं हैं।
चरण 3: ऐसे शिक्षक जो दंत चिकित्सक भी हैं परंतु शल्य चिकित्सक नहीं = 29।""",
),
}
