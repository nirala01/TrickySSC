D = {
31: dict(
et=r"Object sliding over a surface → sliding (kinetic) friction.",
es=r"""-> A book pushed across a table slides over the table surface, so the friction acting on it is sliding friction.
-> Sliding (kinetic) friction acts between two solid surfaces moving over each other and opposes the motion.
-> Rolling friction acts when a body rolls (wheels, ball bearings) and is much smaller than sliding friction.
-> Fluid friction (drag) acts on bodies moving through liquids or gases; "magnetic friction" is not a standard type of friction.""",
ef=[r"Order of magnitude: static friction > sliding friction > rolling friction.", r"Friction is reduced by lubricants, ball bearings and streamlining, and increased by treads and grooves."],
hs=r"जब किसी पुस्तक को मेज़ की सतह पर धकेला जाता है, तो मुख्य रूप से किस प्रकार का घर्षण उसकी गति का विरोध करता है?",
ho={"Fluid friction": "तरल घर्षण", "Magnetic friction": "चुंबकीय घर्षण", "Rolling friction": "लोटनिक घर्षण", "Sliding friction": "सर्पी घर्षण"},
ht=r"सतह पर फिसलती वस्तु → सर्पी घर्षण।",
hx=r"""-> मेज़ पर धकेली गई पुस्तक मेज़ की सतह पर फिसलती है, अतः उस पर लगने वाला घर्षण सर्पी घर्षण है।
-> सर्पी (गतिज) घर्षण एक-दूसरे पर फिसलती दो ठोस सतहों के बीच लगता है और गति का विरोध करता है।
-> लोटनिक घर्षण तब लगता है जब कोई वस्तु लुढ़कती है (पहिए, बॉल बेयरिंग) और यह सर्पी घर्षण से बहुत कम होता है।
-> तरल घर्षण (कर्षण) द्रवों या गैसों में चलती वस्तुओं पर लगता है; "चुंबकीय घर्षण" घर्षण का कोई मानक प्रकार नहीं है।""",
hf=[r"परिमाण का क्रम: स्थैतिक घर्षण > सर्पी घर्षण > लोटनिक घर्षण।", r"स्नेहक, बॉल बेयरिंग और धारारेखीय आकार से घर्षण घटता है, जबकि खाँचों और ट्रेड से बढ़ता है।"],
),
32: dict(
et=r"Razia Sultan: 1236–1240, the only woman ruler of the Delhi Sultanate.",
es=r"""-> Razia Sultan, daughter of Iltutmish, ruled the Delhi Sultanate from 1236 to 1240.
-> Iltutmish nominated her as his successor, but the Turkish nobles (the 'Chalisa' or group of Forty) resented a woman ruler.
-> Her favour to the Abyssinian Jalaluddin Yaqut angered the nobles; she was overthrown and killed in 1240.
-> She was succeeded by her brother Muizuddin Bahram Shah; 1246 is when Nasiruddin Mahmud came to the throne.""",
ef=[r"Razia was the first and only woman to sit on the throne of Delhi in the Sultanate period.", r"She married Malik Altunia, the governor of Bathinda, in an attempt to regain power."],
hs=r"इल्तुतमिश की पुत्री रज़िया ने तुर्की सरदारों द्वारा अपदस्थ किए जाने से पहले किन वर्षों के बीच दिल्ली सल्तनत पर शासन किया?",
ht=r"रज़िया सुल्तान: 1236–1240, दिल्ली सल्तनत की एकमात्र महिला शासक।",
hx=r"""-> इल्तुतमिश की पुत्री रज़िया सुल्तान ने 1236 से 1240 तक दिल्ली सल्तनत पर शासन किया।
-> इल्तुतमिश ने उसे अपना उत्तराधिकारी नामित किया था, पर तुर्की सरदार ('चालीसा' या चालीस का दल) एक महिला शासक से असंतुष्ट थे।
-> अबीसीनियाई जलालुद्दीन याकूत पर उसकी कृपा से सरदार नाराज़ हुए; 1240 में उसे अपदस्थ कर मार दिया गया।
-> उसके बाद उसका भाई मुइज़ुद्दीन बहराम शाह गद्दी पर बैठा; 1246 में नासिरुद्दीन महमूद गद्दी पर आया।""",
hf=[r"सल्तनत काल में दिल्ली की गद्दी पर बैठने वाली रज़िया पहली और एकमात्र महिला थी।", r"सत्ता वापस पाने के प्रयास में उसने भटिंडा के सूबेदार मलिक अल्तूनिया से विवाह किया।"],
),
33: dict(
et=r"SDG NIF Progress Report 2025: social protection coverage 22% (2016) → 64.3% (2025).",
es=r"""-> The SDG National Indicator Framework (NIF) Progress Report 2025 is released by the Ministry of Statistics and Programme Implementation (MoSPI).
-> It reports that social protection coverage in India rose from 22% in 2016 to 64.3% in 2025.
-> The rise is credited to schemes such as PM-JAY, PM-KISAN, e-Shram registration, pensions and food security coverage.
-> The other figures (40%, 55%, 78%) do not match the value reported for 2025.""",
ef=[r"The ILO's World Social Protection Report also recorded India's coverage at 64.3% in 2025.", r"SDG 1 (No Poverty) target 1.3 deals with social protection systems for all."],
hs=r"सतत विकास लक्ष्य राष्ट्रीय संकेतक ढाँचा (SDG NIF) प्रगति रिपोर्ट 2025 के अनुसार, सामाजिक सुरक्षा कवरेज 2016 के 22% से बढ़कर 2025 में कितने प्रतिशत हो गया?",
ht=r"SDG NIF प्रगति रिपोर्ट 2025: सामाजिक सुरक्षा कवरेज 22% (2016) → 64.3% (2025)।",
hx=r"""-> SDG राष्ट्रीय संकेतक ढाँचा (NIF) प्रगति रिपोर्ट 2025 सांख्यिकी और कार्यक्रम कार्यान्वयन मंत्रालय (MoSPI) द्वारा जारी की जाती है।
-> इसके अनुसार भारत में सामाजिक सुरक्षा कवरेज 2016 के 22% से बढ़कर 2025 में 64.3% हो गया।
-> इस वृद्धि का श्रेय PM-JAY, PM-KISAN, ई-श्रम पंजीकरण, पेंशन और खाद्य सुरक्षा जैसी योजनाओं को दिया जाता है।
-> अन्य आँकड़े (40%, 55%, 78%) 2025 के लिए बताए गए मान से मेल नहीं खाते।""",
hf=[r"ILO की विश्व सामाजिक सुरक्षा रिपोर्ट ने भी 2025 में भारत का कवरेज 64.3% दर्ज किया।", r"SDG 1 (गरीबी उन्मूलन) का लक्ष्य 1.3 सभी के लिए सामाजिक सुरक्षा प्रणालियों से संबंधित है।"],
),
34: dict(
et=r"Ten Degree Channel: Andaman | Nicobar. Nine Degree: Lakshadweep | Minicoy.",
es=r"""-> The Ten Degree Channel separates the Andaman Islands (Little Andaman) from the Nicobar Islands (Car Nicobar).
-> It lies along about 10° N latitude in the Bay of Bengal.
-> Duncan Passage lies between South Andaman and Little Andaman, within the Andaman group.
-> Palk Strait separates India from Sri Lanka, and the Nine Degree Channel separates Lakshadweep (Kalpeni) from Minicoy.""",
ef=[r"The Eight Degree Channel separates Minicoy from the Maldives.", r"Indira Point, the southernmost point of India, is on Great Nicobar."],
hs=r"निम्नलिखित में से कौन-सा जल निकाय अंडमान द्वीप समूह को निकोबार द्वीप समूह से अलग करता है?",
ho={"Duncan Passage": "डंकन पैसेज", "Ten Degree Channel": "दस डिग्री चैनल", "Palk Strait": "पाक जलडमरूमध्य", "Nine Degree Channel": "नौ डिग्री चैनल"},
ht=r"दस डिग्री चैनल: अंडमान | निकोबार; नौ डिग्री: लक्षद्वीप | मिनिकॉय।",
hx=r"""-> दस डिग्री चैनल अंडमान द्वीप समूह (लिटिल अंडमान) को निकोबार द्वीप समूह (कार निकोबार) से अलग करता है।
-> यह बंगाल की खाड़ी में लगभग 10° उत्तरी अक्षांश पर स्थित है।
-> डंकन पैसेज दक्षिण अंडमान और लिटिल अंडमान के बीच, अंडमान समूह के भीतर ही है।
-> पाक जलडमरूमध्य भारत को श्रीलंका से अलग करता है, और नौ डिग्री चैनल लक्षद्वीप (कल्पेनी) को मिनिकॉय से अलग करता है।""",
hf=[r"आठ डिग्री चैनल मिनिकॉय को मालदीव से अलग करता है।", r"भारत का सबसे दक्षिणी बिंदु इंदिरा पॉइंट ग्रेट निकोबार पर है।"],
),
35: dict(
et=r"Gopurams are the hallmark of Dravidian temples; the key marks Vesara (see note).",
es=r"""-> The official answer key for this question marks "Vesara style", and that is the answer carried here.
-> Note: elaborate gopurams — the towering, sculpted gateways in the enclosure walls — are the textbook defining feature of the Dravidian style of South India, and RRB may revise this key.
-> The Vesara style (Chalukya and Hoysala temples) blends Nagara and Dravidian features and is the style the key associates with the gateways here.
-> The Nagara style of North India has a curvilinear shikhara and no gopurams; "Pala style" refers to eastern Indian art and sculpture, not a temple-gateway style.""",
ef=[r"In Dravidian temples the shrine tower is called the vimana, and the gateway tower is the gopuram.", r"Hoysala temples at Belur and Halebidu are the classic examples of the Vesara style."],
hs=r"विस्तृत गोपुरम की उपस्थिति किस मंदिर स्थापत्य शैली की परिभाषित विशेषता है?",
ho={"Pala style": "पाल शैली", "Dravidian style": "द्रविड़ शैली", "Nagara style": "नागर शैली", "Vesara style": "वेसर शैली"},
ht=r"गोपुरम द्रविड़ मंदिरों की पहचान हैं; आधिकारिक कुंजी वेसर बताती है (टिप्पणी देखें)।",
hx=r"""-> इस प्रश्न की आधिकारिक उत्तर कुंजी "वेसर शैली" बताती है, और यहाँ वही उत्तर रखा गया है।
-> टिप्पणी: विस्तृत गोपुरम — परकोटे की दीवारों में बने ऊँचे, अलंकृत प्रवेश-द्वार — पाठ्यपुस्तकों के अनुसार दक्षिण भारत की द्रविड़ शैली की परिभाषित विशेषता हैं, और RRB यह कुंजी संशोधित कर सकता है।
-> वेसर शैली (चालुक्य और होयसल मंदिर) नागर और द्रविड़ विशेषताओं का मिश्रण है, और कुंजी ने यहाँ प्रवेश-द्वारों को इसी शैली से जोड़ा है।
-> उत्तर भारत की नागर शैली में वक्ररेखीय शिखर होता है और गोपुरम नहीं होते; "पाल शैली" पूर्वी भारत की कला और मूर्तिकला है, मंदिर-द्वार शैली नहीं।""",
hf=[r"द्रविड़ मंदिरों में गर्भगृह के ऊपर का शिखर विमान और प्रवेश-द्वार का शिखर गोपुरम कहलाता है।", r"बेलूर और हलेबीडु के होयसल मंदिर वेसर शैली के प्रमुख उदाहरण हैं।"],
),
36: dict(
et=r"CPU = ALU (processing) + CU (control).",
es=r"""-> The CPU (Central Processing Unit) is the "brain" of the computer: it processes data and controls all other parts.
-> Its Arithmetic Logic Unit (ALU) carries out calculations and logical comparisons — the processing function.
-> Its Control Unit (CU) fetches and decodes instructions and directs the flow of data — the control function.
-> Storage is done by memory and disks, input by devices such as the keyboard, and output/display by monitors and printers.""",
ef=[r"Registers are the fastest memory, located inside the CPU.", r"Clock speed of a CPU is measured in hertz (GHz in modern processors)."],
hs=r"CPU मुख्य रूप से निम्नलिखित में से कौन-से कार्य करता है?",
ho={"Storage and output": "भंडारण और आउटपुट", "Processing and control": "प्रोसेसिंग और नियंत्रण", "Input and calculation": "इनपुट और गणना", "Display and storage": "डिस्प्ले और भंडारण"},
ht=r"CPU = ALU (प्रोसेसिंग) + CU (नियंत्रण)।",
hx=r"""-> CPU (सेंट्रल प्रोसेसिंग यूनिट) कंप्यूटर का "मस्तिष्क" है: यह डेटा को प्रोसेस करता है और अन्य सभी भागों को नियंत्रित करता है।
-> इसकी अंकगणितीय तर्क इकाई (ALU) गणनाएँ और तार्किक तुलनाएँ करती है — यह प्रोसेसिंग कार्य है।
-> इसकी नियंत्रण इकाई (CU) निर्देशों को लाती और डिकोड करती है तथा डेटा के प्रवाह का निर्देशन करती है — यह नियंत्रण कार्य है।
-> भंडारण मेमोरी और डिस्क करती हैं, इनपुट कीबोर्ड जैसे उपकरण, और आउटपुट/डिस्प्ले मॉनिटर और प्रिंटर करते हैं।""",
hf=[r"रजिस्टर सबसे तेज़ मेमोरी हैं, जो CPU के अंदर होते हैं।", r"CPU की क्लॉक स्पीड हर्ट्ज़ में मापी जाती है (आधुनिक प्रोसेसरों में GHz)।"],
),
37: dict(
et=r"Railway Convention Committee: Lok Sabha members nominated by the Speaker.",
es=r"""-> The Railway Convention Committee is an ad hoc parliamentary committee that fixes the rate of dividend payable by the Railways to the general revenues.
-> It is constituted by a resolution of Parliament and is made up of members of both Houses.
-> Its Lok Sabha members are nominated by the Speaker of the Lok Sabha, who also appoints its chairman — the authority given in the key.
-> The Rajya Sabha members are nominated by the Chairman of the Rajya Sabha; the President and the Prime Minister have no role in nominating them.""",
ef=[r"The first Railway Convention Committee was formed in 1949, after the 1924 Acworth-based separation of railway finances.", r"The separate Railway Budget was merged with the Union Budget from 2017-18."],
hs=r"रेलवे अभिसमय समिति के सदस्य भारत के निम्नलिखित में से किस प्राधिकारी द्वारा नामित किए जाते हैं?",
ho={"The President of India": "भारत के राष्ट्रपति", "The Prime Minister of India": "भारत के प्रधानमंत्री", "The Speaker of the Lok Sabha": "लोकसभा अध्यक्ष", "The Chairman of the Rajya Sabha": "राज्यसभा के सभापति"},
ht=r"रेलवे अभिसमय समिति: लोकसभा सदस्य अध्यक्ष द्वारा नामित।",
hx=r"""-> रेलवे अभिसमय समिति एक तदर्थ संसदीय समिति है जो रेलवे द्वारा सामान्य राजस्व को देय लाभांश की दर तय करती है।
-> इसका गठन संसद के संकल्प द्वारा होता है और इसमें दोनों सदनों के सदस्य होते हैं।
-> इसके लोकसभा सदस्य लोकसभा अध्यक्ष द्वारा नामित किए जाते हैं, जो इसके अध्यक्ष की नियुक्ति भी करते हैं — कुंजी में यही प्राधिकारी दिया गया है।
-> राज्यसभा सदस्य राज्यसभा के सभापति द्वारा नामित होते हैं; राष्ट्रपति और प्रधानमंत्री की इनके नामांकन में कोई भूमिका नहीं होती।""",
hf=[r"पहली रेलवे अभिसमय समिति 1949 में बनी, 1924 में रेल वित्त के अलगाव के बाद।", r"अलग रेल बजट को 2017-18 से केंद्रीय बजट में मिला दिया गया।"],
),
38: dict(
et=r"Lala Lajpat Rai: led the anti-Simon protest at Lahore (1928), died of lathi injuries.",
es=r"""-> Lala Lajpat Rai led the protest against the Simon Commission at Lahore on 30 October 1928.
-> He was severely injured in the police lathi-charge ordered by Superintendent James Scott and died on 17 November 1928.
-> The Bardoli Satyagraha (1928) against enhanced land revenue was led by Vallabhbhai Patel.
-> The Nehru Report (1928) was drafted by a committee headed by Motilal Nehru and asked for dominion status, not complete independence.""",
ef=[r"Lala Lajpat Rai was known as 'Punjab Kesari' and was part of the 'Lal-Bal-Pal' trio.", r"Bhagat Singh and his comrades killed J.P. Saunders in 1928 to avenge Lajpat Rai's death."],
hs=r"स्वतंत्रता संग्राम के दौरान लाला लाजपत राय से कौन-सा योगदान सही रूप से जुड़ा है?",
ho={"Leading the anti-Simon Commission protests, where he suffered fatal injuries": "साइमन कमीशन-विरोधी प्रदर्शनों का नेतृत्व, जिनमें उन्हें घातक चोटें आईं",
    "Leading the Bardoli satyagraha against enhanced revenue- demand policies": "बढ़ी हुई राजस्व-माँग नीतियों के विरुद्ध बारदोली सत्याग्रह का नेतृत्व",
    "Drafting the Nehru Report outlining complete independence for India": "भारत की पूर्ण स्वतंत्रता की रूपरेखा वाली नेहरू रिपोर्ट का प्रारूप तैयार करना",
    "Commanding the Congress Volunteers during the Salt March in Gujarat": "गुजरात में नमक यात्रा के दौरान कांग्रेस स्वयंसेवकों की कमान संभालना"},
ht=r"लाला लाजपत राय: लाहौर में साइमन-विरोधी प्रदर्शन (1928), लाठी की चोटों से मृत्यु।",
hx=r"""-> लाला लाजपत राय ने 30 अक्टूबर 1928 को लाहौर में साइमन कमीशन के विरुद्ध प्रदर्शन का नेतृत्व किया।
-> अधीक्षक जेम्स स्कॉट के आदेश पर हुए पुलिस लाठीचार्ज में वे गंभीर रूप से घायल हुए और 17 नवंबर 1928 को उनकी मृत्यु हो गई।
-> बढ़े हुए भू-राजस्व के विरुद्ध बारदोली सत्याग्रह (1928) का नेतृत्व वल्लभभाई पटेल ने किया।
-> नेहरू रिपोर्ट (1928) मोतीलाल नेहरू की अध्यक्षता वाली समिति ने तैयार की और उसमें पूर्ण स्वतंत्रता नहीं, डोमिनियन दर्जे की माँग थी।""",
hf=[r"लाला लाजपत राय 'पंजाब केसरी' कहलाते थे और 'लाल-बाल-पाल' तिकड़ी का हिस्सा थे।", r"लाजपत राय की मृत्यु का बदला लेने के लिए भगत सिंह और साथियों ने 1928 में जे.पी. सांडर्स की हत्या की।"],
),
39: dict(
et=r"Harappan towns: grid plan, roads crossing at right angles.",
es=r"""-> Harappan settlements had a planned layout: a raised Citadel and a larger Lower Town.
-> Roads and streets in the Lower Town ran north–south and east–west and crossed each other at right angles, forming a grid pattern.
-> Houses were built along the streets, and a covered drainage system ran beside them.
-> Irregular, radial and circular street plans are not found in the excavated Harappan cities.""",
ef=[r"Harappan bricks were of a standard ratio of 1 : 2 : 4.", r"The Great Bath was found in the Citadel of Mohenjo-daro."],
hs=r"हड़प्पा के निचले नगर की सड़कें और गलियाँ किस प्रतिरूप में बनाई गई थीं?",
ho={"Grid pattern intersecting at right angles": "समकोण पर काटती हुई ग्रिड प्रतिरूप", "Irregular pattern without fixed alignment": "बिना निश्चित संरेखण का अनियमित प्रतिरूप", "Radial pattern spreading from a centre": "केंद्र से फैलता हुआ त्रिज्यीय प्रतिरूप", "Circular pattern with curved streets": "घुमावदार गलियों वाला वृत्ताकार प्रतिरूप"},
ht=r"हड़प्पा नगर: ग्रिड योजना, समकोण पर काटती सड़कें।",
hx=r"""-> हड़प्पा बस्तियों की योजना सुनियोजित थी: एक ऊँचा दुर्ग और एक बड़ा निचला नगर।
-> निचले नगर की सड़कें और गलियाँ उत्तर–दक्षिण और पूर्व–पश्चिम दिशा में चलती थीं और एक-दूसरे को समकोण पर काटती थीं, जिससे ग्रिड प्रतिरूप बनता था।
-> घर गलियों के किनारे बने थे और उनके साथ-साथ ढकी हुई जल-निकासी प्रणाली थी।
-> उत्खनित हड़प्पा नगरों में अनियमित, त्रिज्यीय या वृत्ताकार सड़क योजना नहीं मिलती।""",
hf=[r"हड़प्पा की ईंटें 1 : 2 : 4 के मानक अनुपात की होती थीं।", r"महान स्नानागार मोहनजोदड़ो के दुर्ग में मिला।"],
),
40: dict(
et=r"Jute: West Bengal produces about three-fourths of India's crop.",
es=r"""-> West Bengal is India's largest jute producer and accounts for roughly three-fourths of the country's output.
-> Jute grows best in the hot, humid Ganga–Brahmaputra delta with well-drained alluvial soil renewed by floods.
-> Bihar, Assam, Odisha and Meghalaya are the other jute-producing states, each with a much smaller share.
-> Hooghly river belt around Kolkata is the main centre of the jute mill industry.""",
ef=[r"Jute is called the 'golden fibre'.", r"India is the world's largest producer of jute, followed by Bangladesh."],
hs=r"निम्नलिखित में से कौन-सा राज्य भारत के कुल जूट उत्पादन का लगभग तीन-चौथाई भाग उत्पन्न करता है?",
ho={"Bihar": "बिहार", "Odisha": "ओडिशा", "Assam": "असम", "West Bengal": "पश्चिम बंगाल"},
ht=r"जूट: पश्चिम बंगाल भारत की लगभग तीन-चौथाई उपज देता है।",
hx=r"""-> पश्चिम बंगाल भारत का सबसे बड़ा जूट उत्पादक है और देश के उत्पादन का लगभग तीन-चौथाई भाग देता है।
-> जूट गर्म, आर्द्र गंगा–ब्रह्मपुत्र डेल्टा की अच्छी जल-निकासी वाली, बाढ़ से नवीनीकृत जलोढ़ मिट्टी में सबसे अच्छा उगता है।
-> बिहार, असम, ओडिशा और मेघालय अन्य जूट उत्पादक राज्य हैं, जिनका हिस्सा काफ़ी कम है।
-> कोलकाता के आसपास हुगली नदी पट्टी जूट मिल उद्योग का मुख्य केंद्र है।""",
hf=[r"जूट को 'सुनहरा रेशा' कहा जाता है।", r"भारत विश्व का सबसे बड़ा जूट उत्पादक है, उसके बाद बांग्लादेश।"],
),
41: dict(
et=r"Fossil fuels (petroleum, coal, natural gas) are non-renewable.",
es=r"""-> A non-renewable resource cannot be replenished within a human lifetime once it is used up.
-> Petroleum is a fossil fuel formed over millions of years from buried organic matter, so it is non-renewable.
-> Solar and wind energy are continuously available from nature and are renewable.
-> Biomass (wood, crop residue, dung) can be regrown or regenerated, so it is also renewable.""",
ef=[r"Coal, petroleum and natural gas are the three main fossil fuels.", r"Mumbai High is India's largest offshore oil field."],
hs=r"निम्नलिखित में से कौन-सा एक अनवीकरणीय संसाधन है?",
ho={"Solar Energy": "सौर ऊर्जा", "Petroleum": "पेट्रोलियम", "Wind Energy": "पवन ऊर्जा", "Biomass": "जैवभार (बायोमास)"},
ht=r"जीवाश्म ईंधन (पेट्रोलियम, कोयला, प्राकृतिक गैस) अनवीकरणीय हैं।",
hx=r"""-> अनवीकरणीय संसाधन एक बार उपयोग होने के बाद मानव जीवनकाल में पुनः नहीं बन सकता।
-> पेट्रोलियम दबे हुए कार्बनिक पदार्थों से लाखों वर्षों में बना जीवाश्म ईंधन है, अतः यह अनवीकरणीय है।
-> सौर और पवन ऊर्जा प्रकृति से लगातार उपलब्ध हैं और नवीकरणीय हैं।
-> जैवभार (लकड़ी, फसल अवशेष, गोबर) फिर से उगाया या बनाया जा सकता है, अतः यह भी नवीकरणीय है।""",
hf=[r"कोयला, पेट्रोलियम और प्राकृतिक गैस तीन मुख्य जीवाश्म ईंधन हैं।", r"मुंबई हाई भारत का सबसे बड़ा अपतटीय तेल क्षेत्र है।"],
),
42: dict(
et=r"Price Stabilisation Fund: set up in 2014-15.",
es=r"""-> The Price Stabilisation Fund (PSF) was set up by the Government of India in 2014-15.
-> It helps regulate the prices of perishable agri-horticultural commodities such as onion, potato and pulses.
-> Under it, the government procures these commodities when prices are low and builds buffer stocks to release when prices rise.
-> It was first under the Department of Agriculture and was moved to the Department of Consumer Affairs in 2016.""",
ef=[r"NAFED is a major central agency that procures onion and pulses for the PSF buffer.", r"Operation Greens (2018) targets price stability of tomato, onion and potato (TOP)."],
hs=r"भारत सरकार ने कृषि-बागवानी वस्तुओं की कीमतों को विनियमित करने के लिए मूल्य स्थिरीकरण कोष (PSF) किस वित्तीय वर्ष में स्थापित किया?",
ht=r"मूल्य स्थिरीकरण कोष: 2014-15 में स्थापित।",
hx=r"""-> भारत सरकार ने मूल्य स्थिरीकरण कोष (PSF) 2014-15 में स्थापित किया।
-> यह प्याज़, आलू और दालों जैसी जल्दी खराब होने वाली कृषि-बागवानी वस्तुओं की कीमतों को नियंत्रित करने में मदद करता है।
-> इसके अंतर्गत सरकार कीमतें कम होने पर इन वस्तुओं की खरीद करके बफ़र स्टॉक बनाती है और कीमतें बढ़ने पर उन्हें जारी करती है।
-> यह पहले कृषि विभाग के अंतर्गत था और 2016 में उपभोक्ता मामले विभाग को स्थानांतरित किया गया।""",
hf=[r"NAFED, PSF बफ़र के लिए प्याज़ और दालें खरीदने वाली प्रमुख केंद्रीय एजेंसी है।", r"ऑपरेशन ग्रीन्स (2018) टमाटर, प्याज़ और आलू (TOP) की कीमतों की स्थिरता पर केंद्रित है।"],
),
43: dict(
et=r"CD = Compact Disc (optical storage).",
es=r"""-> CD stands for Compact Disc, an optical storage medium read and written with a laser.
-> A standard CD stores about 700 MB of data (around 80 minutes of audio).
-> CD-ROM can only be read, CD-R can be written once, and CD-RW can be rewritten many times.
-> "Control Datamine", "Current Directories" and "Color Display" are not expansions used in computing.""",
ef=[r"A single-layer DVD holds about 4.7 GB; a single-layer Blu-ray disc holds about 25 GB.", r"Blu-ray uses a blue-violet laser of shorter wavelength than the red laser of CDs and DVDs."],
hs=r"कंप्यूटर शब्दावली में CD का पूरा रूप क्या है?",
ht=r"CD = कॉम्पैक्ट डिस्क (ऑप्टिकल भंडारण)।",
hx=r"""-> CD का पूरा रूप कॉम्पैक्ट डिस्क (Compact Disc) है, जो लेज़र से पढ़ा और लिखा जाने वाला ऑप्टिकल भंडारण माध्यम है।
-> एक मानक CD में लगभग 700 MB डेटा (लगभग 80 मिनट का ऑडियो) आता है।
-> CD-ROM केवल पढ़ी जा सकती है, CD-R पर एक बार लिखा जा सकता है और CD-RW पर कई बार लिखा जा सकता है।
-> "Control Datamine", "Current Directories" और "Color Display" कंप्यूटिंग में प्रयुक्त विस्तार नहीं हैं।""",
hf=[r"सिंगल-लेयर DVD में लगभग 4.7 GB और सिंगल-लेयर ब्लू-रे डिस्क में लगभग 25 GB आता है।", r"ब्लू-रे में CD और DVD के लाल लेज़र की तुलना में छोटी तरंगदैर्ध्य वाला नीला-बैंगनी लेज़र प्रयुक्त होता है।"],
),
44: dict(
et=r"Abel Prize 2025: Masaki Kashiwara (Japan), for algebraic analysis.",
es=r"""-> The Abel Prize 2025 was awarded to Masaki Kashiwara of Kyoto University, Japan.
-> He was honoured for his fundamental contributions to algebraic analysis and representation theory, including D-modules and crystal bases.
-> He is the first Japanese mathematician to win the Abel Prize.
-> Avi Wigderson won in 2021, Luis Caffarelli in 2023 and Karen Uhlenbeck in 2019.""",
ef=[r"The Abel Prize is awarded by the Norwegian Academy of Science and Letters and is named after Niels Henrik Abel.", r"Michel Talagrand (France) won the Abel Prize in 2024."],
hs=r"निम्नलिखित में से किसे एबेल पुरस्कार 2025 से सम्मानित किया गया?",
ho={"Avi Wigderson": "एवी विग्डर्सन", "Luis Caffarelli": "लुईस कैफ़रेली", "Masaki Kashiwara": "मासाकी काशीवारा", "Karen Uhlenbeck": "करेन उहलेनबेक"},
ht=r"एबेल पुरस्कार 2025: मासाकी काशीवारा (जापान), बीजीय विश्लेषण के लिए।",
hx=r"""-> एबेल पुरस्कार 2025 जापान के क्योटो विश्वविद्यालय के मासाकी काशीवारा को दिया गया।
-> उन्हें बीजीय विश्लेषण और निरूपण सिद्धांत में मौलिक योगदान, जिनमें D-मॉड्यूल और क्रिस्टल बेस शामिल हैं, के लिए सम्मानित किया गया।
-> वे एबेल पुरस्कार जीतने वाले पहले जापानी गणितज्ञ हैं।
-> एवी विग्डर्सन ने 2021 में, लुईस कैफ़रेली ने 2023 में और करेन उहलेनबेक ने 2019 में यह पुरस्कार जीता।""",
hf=[r"एबेल पुरस्कार नॉर्वेजियन एकेडमी ऑफ़ साइंस एंड लेटर्स द्वारा दिया जाता है और नील्स हेनरिक एबेल के नाम पर है।", r"मिशेल तालाग्रां (फ़्रांस) ने 2024 का एबेल पुरस्कार जीता।"],
),
45: dict(
et=r"John McFall: British (UK) Paralympian, ESA's first disabled astronaut candidate.",
es=r"""-> John McFall is a British Paralympic sprinter and orthopaedic surgeon from the United Kingdom.
-> He was selected by the European Space Agency (ESA) in 2022 as the first astronaut with a physical disability (a leg amputee).
-> In 2025 he was cleared for a long-duration mission to the International Space Station.
-> He won a bronze medal in the 100 m sprint at the 2008 Beijing Paralympics.""",
ef=[r"ESA's 'Fly!' feasibility study examined how a disabled astronaut could fly on the ISS.", r"Rakesh Sharma (1984) was the first Indian in space; Shubhanshu Shukla flew to the ISS in 2025 on Axiom-4."],
hs=r"2025 में अंतर्राष्ट्रीय अंतरिक्ष स्टेशन मिशन के लिए चयनित पहले दिव्यांग अंतरिक्ष यात्री जॉन मैकफॉल निम्नलिखित में से किस देश से संबंधित हैं?",
ho={"Canada": "कनाडा", "United Kingdom": "यूनाइटेड किंगडम", "United States of America": "संयुक्त राज्य अमेरिका", "Australia": "ऑस्ट्रेलिया"},
ht=r"जॉन मैकफॉल: ब्रिटिश (UK) पैरालंपियन, ESA के पहले दिव्यांग अंतरिक्ष यात्री।",
hx=r"""-> जॉन मैकफॉल यूनाइटेड किंगडम के एक ब्रिटिश पैरालंपिक धावक और अस्थि-शल्य चिकित्सक हैं।
-> यूरोपीय अंतरिक्ष एजेंसी (ESA) ने उन्हें 2022 में शारीरिक दिव्यांगता (पैर कटा होना) वाले पहले अंतरिक्ष यात्री के रूप में चुना।
-> 2025 में उन्हें अंतर्राष्ट्रीय अंतरिक्ष स्टेशन के दीर्घकालिक मिशन के लिए स्वीकृति मिली।
-> उन्होंने 2008 बीजिंग पैरालंपिक में 100 m दौड़ में कांस्य पदक जीता था।""",
hf=[r"ESA के 'Fly!' अध्ययन ने जाँचा कि कोई दिव्यांग अंतरिक्ष यात्री ISS पर कैसे उड़ान भर सकता है।", r"राकेश शर्मा (1984) अंतरिक्ष में जाने वाले पहले भारतीय थे; शुभांशु शुक्ला 2025 में एक्सिओम-4 से ISS गए।"],
),
46: dict(
et=r"MS Word = application software (word processor); Windows/Linux/BIOS = system software.",
es=r"""-> Application software is used to do a particular task for the user, such as creating documents.
-> MS Word is a word-processing application used to create, edit and format documents.
-> Windows and Linux are operating systems, which are system software.
-> BIOS is firmware stored on the motherboard that starts the computer (booting) — also not application software.""",
ef=[r"MS Excel is a spreadsheet application and MS PowerPoint is a presentation application.", r"LibreOffice Writer and Google Docs are other word processors."],
hs=r"निम्नलिखित में से कौन-सा दस्तावेज़ बनाने के लिए प्रयुक्त एप्लिकेशन सॉफ़्टवेयर का उदाहरण है?",
ho={"MS Word": "MS वर्ड", "Windows": "विंडोज़", "BIOS": "BIOS", "Linux": "लिनक्स"},
ht=r"MS वर्ड = एप्लिकेशन सॉफ़्टवेयर; विंडोज़/लिनक्स/BIOS = सिस्टम सॉफ़्टवेयर।",
hx=r"""-> एप्लिकेशन सॉफ़्टवेयर उपयोगकर्ता के लिए कोई विशेष कार्य करता है, जैसे दस्तावेज़ बनाना।
-> MS वर्ड एक वर्ड-प्रोसेसिंग एप्लिकेशन है, जिससे दस्तावेज़ बनाए, संपादित और फ़ॉर्मेट किए जाते हैं।
-> विंडोज़ और लिनक्स ऑपरेटिंग सिस्टम हैं, जो सिस्टम सॉफ़्टवेयर हैं।
-> BIOS मदरबोर्ड पर संग्रहीत फ़र्मवेयर है जो कंप्यूटर को चालू (बूट) करता है — यह भी एप्लिकेशन सॉफ़्टवेयर नहीं है।""",
hf=[r"MS एक्सेल स्प्रेडशीट एप्लिकेशन है और MS पावरपॉइंट प्रेज़ेंटेशन एप्लिकेशन है।", r"लिब्रेऑफ़िस राइटर और गूगल डॉक्स अन्य वर्ड प्रोसेसर हैं।"],
),
47: dict(
et=r"Rajya Sabha is presided over by the Vice-President (Chairman), not the President.",
es=r"""-> The Rajya Sabha is presided over by its Chairman, who is the Vice-President of India (Article 89) — not the President.
-> The President promulgates ordinances when Parliament is not in session (Article 123).
-> The President summons and prorogues the Houses of Parliament and can dissolve the Lok Sabha (Article 85).
-> The President grants pardons, reprieves, respites and remissions of punishment (Article 72).""",
ef=[r"The Deputy Chairman presides over the Rajya Sabha in the absence of the Chairman.", r"The President is not a member of either House but is a part of Parliament (Article 79)."],
hs=r"निम्नलिखित में से कौन-सा राष्ट्रपति का कार्य नहीं है?",
ho={"Promulgating ordinances": "अध्यादेश जारी करना", "Summoning and proroguing Parliament": "संसद को आहूत और सत्रावसान करना", "Presiding over Rajya Sabha sessions": "राज्यसभा के सत्रों की अध्यक्षता करना", "Granting pardons and remissions": "क्षमादान और दंड में छूट देना"},
ht=r"राज्यसभा की अध्यक्षता उपराष्ट्रपति (सभापति) करते हैं, राष्ट्रपति नहीं।",
hx=r"""-> राज्यसभा की अध्यक्षता उसके सभापति करते हैं, जो भारत के उपराष्ट्रपति होते हैं (अनुच्छेद 89) — राष्ट्रपति नहीं।
-> संसद सत्र में न होने पर राष्ट्रपति अध्यादेश जारी करते हैं (अनुच्छेद 123)।
-> राष्ट्रपति संसद के सदनों को आहूत करते हैं, उनका सत्रावसान करते हैं और लोकसभा भंग कर सकते हैं (अनुच्छेद 85)।
-> राष्ट्रपति क्षमादान, प्रविलंबन, विराम और दंड में छूट देते हैं (अनुच्छेद 72)।""",
hf=[r"सभापति की अनुपस्थिति में उपसभापति राज्यसभा की अध्यक्षता करते हैं।", r"राष्ट्रपति किसी सदन के सदस्य नहीं होते, पर संसद का अंग होते हैं (अनुच्छेद 79)।"],
),
48: dict(
et=r"Empowering rural women = education + vocational skills.",
es=r"""-> Rural women are empowered when they gain education, skills and income of their own.
-> Gender-specific vocational training and education help women find work, start enterprises and take part in decisions, which lifts the whole community.
-> Limiting education to urban centres and restricting women to household duties keep them dependent and excluded.
-> Focusing only on men's employment leaves out half the workforce and does not empower women.""",
ef=[r"DAY-NRLM (Deendayal Antyodaya Yojana – National Rural Livelihoods Mission) organises rural women into self-help groups.", r"The 'Lakhpati Didi' initiative aims to raise SHG women's annual household income to at least ₹1 lakh."],
hs=r"ग्रामीण महिलाओं को सशक्त बनाने के लिए कौन-सा दृष्टिकोण महत्वपूर्ण है, जिससे सामुदायिक विकास होता है?",
ho={"Limiting educational opportunities to urban centres": "शैक्षिक अवसरों को शहरी केंद्रों तक सीमित करना", "Promoting gender-specific vocational training and education": "लैंगिक-विशिष्ट व्यावसायिक प्रशिक्षण और शिक्षा को बढ़ावा देना", "Restricting women's roles to traditional household duties": "महिलाओं की भूमिका को पारंपरिक घरेलू कार्यों तक सीमित करना", "Focussing solely on men's employment programmes": "केवल पुरुषों के रोज़गार कार्यक्रमों पर ध्यान देना"},
ht=r"ग्रामीण महिला सशक्तिकरण = शिक्षा + व्यावसायिक कौशल।",
hx=r"""-> ग्रामीण महिलाएँ तब सशक्त होती हैं जब उन्हें शिक्षा, कौशल और अपनी आय प्राप्त होती है।
-> लैंगिक-विशिष्ट व्यावसायिक प्रशिक्षण और शिक्षा महिलाओं को काम पाने, उद्यम शुरू करने और निर्णयों में भाग लेने में मदद करते हैं, जिससे पूरे समुदाय का विकास होता है।
-> शिक्षा को शहरों तक सीमित करना और महिलाओं को घरेलू कार्यों तक बाँधना उन्हें निर्भर और अलग-थलग रखता है।
-> केवल पुरुषों के रोज़गार पर ध्यान देने से आधी कार्यशक्ति छूट जाती है और महिलाएँ सशक्त नहीं होतीं।""",
hf=[r"DAY-NRLM (दीनदयाल अंत्योदय योजना – राष्ट्रीय ग्रामीण आजीविका मिशन) ग्रामीण महिलाओं को स्वयं सहायता समूहों में संगठित करता है।", r"'लखपति दीदी' पहल का लक्ष्य स्वयं सहायता समूह की महिलाओं की वार्षिक घरेलू आय कम से कम ₹1 लाख करना है।"],
),
49: dict(
et=r"Black (regur) soil: moisture-retentive, best for cotton.",
es=r"""-> Black soil, also called regur or black cotton soil, is ideal for cotton cultivation.
-> It is rich in clay, so it holds moisture for long and develops deep cracks in summer, which helps aeration ("self-ploughing").
-> It is formed from the weathering of basalt lava rocks of the Deccan Plateau (Maharashtra, Gujarat, Madhya Pradesh).
-> Sandy soil drains quickly, laterite soil is leached and acidic, and red soil is porous — none retains moisture like black soil.""",
ef=[r"Black soil is rich in iron, lime, calcium, magnesium and potash but poor in nitrogen and phosphorus.", r"Its black colour comes from titaniferous magnetite and humus."],
hs=r"नमी बनाए रखने के लिए प्रसिद्ध कौन-सी मृदा कपास की खेती के लिए आदर्श है?",
ho={"Sandy soil": "बलुई मृदा", "Black soil": "काली मृदा", "Laterite soil": "लैटेराइट मृदा", "Red soil": "लाल मृदा"},
ht=r"काली (रेगुर) मृदा: नमी धारक, कपास के लिए सर्वोत्तम।",
hx=r"""-> काली मृदा, जिसे रेगुर या काली कपास मृदा भी कहते हैं, कपास की खेती के लिए आदर्श है।
-> इसमें चिकनी मिट्टी अधिक होती है, अतः यह लंबे समय तक नमी रखती है और गर्मियों में गहरी दरारें पड़ती हैं, जिससे वायु-संचार होता है ("स्वतः जुताई")।
-> यह दक्कन पठार (महाराष्ट्र, गुजरात, मध्य प्रदेश) की बेसाल्ट लावा चट्टानों के अपक्षय से बनी है।
-> बलुई मृदा से पानी जल्दी निकल जाता है, लैटेराइट मृदा निक्षालित और अम्लीय होती है, और लाल मृदा छिद्रपूर्ण होती है — कोई भी काली मृदा जैसी नमी नहीं रखती।""",
hf=[r"काली मृदा में लोहा, चूना, कैल्शियम, मैग्नीशियम और पोटाश प्रचुर होते हैं, पर नाइट्रोजन और फ़ॉस्फ़ोरस कम होते हैं।", r"इसका काला रंग टाइटेनीफेरस मैग्नेटाइट और ह्यूमस के कारण होता है।"],
),
50: dict(
et=r"Oct 2025 Centres of Excellence for heritage languages: under PMJVK.",
es=r"""-> In October 2025 the Ministry of Minority Affairs announced support to universities for Centres of Excellence to preserve and promote heritage and classical languages.
-> The support is given under the Pradhan Mantri Jan Vikas Karyakram (PMJVK), the ministry's area-development scheme for minority-concentration areas.
-> A Centre for Jain Studies at DAVV, Indore was launched under it, after earlier centres at the University of Mumbai (Pali, Prakrit, Avesta Pahlavi) and Gujarat University (Prakrit).
-> MANF is a fellowship scheme, NMDFC is a finance corporation, and PM VIKAS is a skilling and livelihood scheme.""",
ef=[r"PMJVK was earlier known as the Multi-sectoral Development Programme (MsDP) and was restructured in 2018.", r"The Ministry of Minority Affairs was created on 29 January 2006."],
hs=r"अक्टूबर 2025 में अल्पसंख्यक कार्य मंत्रालय ने विरासत और शास्त्रीय भाषाओं को बढ़ावा देने के लिए उत्कृष्टता केंद्र स्थापित करने हेतु विश्वविद्यालयों को सहायता देने की घोषणा की। यह पहल किस योजना के अंतर्गत की गई?",
ho={"Maulana Azad National Fellowship (MANF)": "मौलाना आज़ाद राष्ट्रीय फ़ेलोशिप (MANF)", "National Minorities Development Finance Corporation (NMDFC)": "राष्ट्रीय अल्पसंख्यक विकास एवं वित्त निगम (NMDFC)", "Pradhan Mantri Jan Vikas Karyakram (PMJVK)": "प्रधानमंत्री जन विकास कार्यक्रम (PMJVK)", "Pradhan Mantri Virasat Ka Samvardhan (PM VIKAS)": "प्रधानमंत्री विरासत का संवर्धन (PM VIKAS)"},
ht=r"अक्टूबर 2025 विरासत भाषा उत्कृष्टता केंद्र: PMJVK के अंतर्गत।",
hx=r"""-> अक्टूबर 2025 में अल्पसंख्यक कार्य मंत्रालय ने विरासत और शास्त्रीय भाषाओं के संरक्षण और प्रोत्साहन के लिए उत्कृष्टता केंद्रों हेतु विश्वविद्यालयों को सहायता देने की घोषणा की।
-> यह सहायता प्रधानमंत्री जन विकास कार्यक्रम (PMJVK) के अंतर्गत दी जाती है, जो अल्पसंख्यक-बहुल क्षेत्रों के लिए मंत्रालय की क्षेत्र-विकास योजना है।
-> इसके अंतर्गत इंदौर के DAVV में जैन अध्ययन केंद्र शुरू हुआ; इससे पहले मुंबई विश्वविद्यालय (पाली, प्राकृत, अवेस्ता पहलवी) और गुजरात विश्वविद्यालय (प्राकृत) में केंद्र बने थे।
-> MANF एक फ़ेलोशिप योजना है, NMDFC एक वित्त निगम है और PM VIKAS कौशल एवं आजीविका योजना है।""",
hf=[r"PMJVK पहले बहु-क्षेत्रीय विकास कार्यक्रम (MsDP) कहलाता था और 2018 में पुनर्गठित हुआ।", r"अल्पसंख्यक कार्य मंत्रालय का गठन 29 जनवरी 2006 को हुआ।"],
),
}
