D = {
1: dict(
et=r"SI = P × R × T ÷ 100.",
es=r"""Step 1: Simple interest \( = \dfrac{P \times R \times T}{100} \), with P = ₹1000, R = 5% and T = 2 years.
Step 2: SI \( = \dfrac{1000 \times 5 \times 2}{100} = \dfrac{10000}{100} \).
Step 3: SI \( = 100 \), so the simple interest is ₹100.""",
hs=r"यदि मूलधन ₹1000, दर 5% वार्षिक और समय 2 वर्ष है, तो साधारण ब्याज कितना है?",
ht=r"साधारण ब्याज = मूलधन × दर × समय ÷ 100।",
hx=r"""चरण 1: साधारण ब्याज \( = \dfrac{P \times R \times T}{100} \), जहाँ P = ₹1000, R = 5% और T = 2 वर्ष।
चरण 2: साधारण ब्याज \( = \dfrac{1000 \times 5 \times 2}{100} = \dfrac{10000}{100} \)।
चरण 3: साधारण ब्याज \( = 100 \), अर्थात ₹100।""",
),
2: dict(
et=r"Departing together again = LCM of the intervals.",
es=r"""Step 1: The trains next leave together after LCM(12, 18, 27) minutes.
Step 2: \( 12 = 2^{2} \times 3,\; 18 = 2 \times 3^{2},\; 27 = 3^{3} \Rightarrow \text{LCM} = 2^{2} \times 3^{3} = 108 \) minutes.
Step 3: 108 minutes \( = 1 \) hour 48 minutes, so 6:00 am + 1 h 48 min = 7:48 am.""",
hs=r"दिल्ली, लखनऊ और जयपुर से रेलगाड़ियाँ क्रमशः हर 12 मिनट, 18 मिनट और 27 मिनट पर रवाना होती हैं। यदि सभी सुबह 6:00 बजे एक साथ रवाना होती हैं, तो वे फिर से एक साथ कब रवाना होंगी?",
ho={"7:36 am": "सुबह 7:36", "7:48 am": "सुबह 7:48", "7:24 am": "सुबह 7:24", "7:40 am": "सुबह 7:40"},
ht=r"फिर से एक साथ = अंतरालों का LCM।",
hx=r"""चरण 1: रेलगाड़ियाँ अगली बार LCM(12, 18, 27) मिनट बाद एक साथ चलेंगी।
चरण 2: \( 12 = 2^{2} \times 3,\; 18 = 2 \times 3^{2},\; 27 = 3^{3} \Rightarrow \text{LCM} = 2^{2} \times 3^{3} = 108 \) मिनट।
चरण 3: 108 मिनट \( = 1 \) घंटा 48 मिनट, अतः सुबह 6:00 + 1 घंटा 48 मिनट = सुबह 7:48।""",
),
3: dict(
et=r"Third proportional to a and b = b² ÷ a.",
es=r"""Step 1: If x is the third proportional to 5 and 10, then \( 5 : 10 = 10 : x \).
Step 2: Product of extremes = product of means: \( 5x = 10 \times 10 = 100 \).
Step 3: \( x = \dfrac{100}{5} = 20 \).""",
hs=r"यदि 5 और 10 दिए गए हैं, तो इन संख्याओं का तृतीयानुपाती क्या है?",
ht=r"a और b का तृतीयानुपाती = b² ÷ a।",
hx=r"""चरण 1: यदि x, 5 और 10 का तृतीयानुपाती है, तो \( 5 : 10 = 10 : x \)।
चरण 2: बाह्य पदों का गुणनफल = मध्य पदों का गुणनफल: \( 5x = 10 \times 10 = 100 \)।
चरण 3: \( x = \dfrac{100}{5} = 20 \)।""",
),
4: dict(
et=r"Weighted average = Σ(score × weight) ÷ Σ weights.",
es=r"""Step 1: Weighted total \( = 75 \times 2 + 80 \times 3 + 90 \times 5 = 150 + 240 + 450 = 840 \).
Step 2: Total weight \( = 2 + 3 + 5 = 10 \).
Step 3: Weighted average \( = \dfrac{840}{10} = 84 \).""",
hs=r"एक छात्र तीन परीक्षाओं में 75, 80 और 90 अंक प्राप्त करता है, जिनके भार क्रमशः 2, 3 और 5 हैं। भारित औसत अंक क्या है?",
ht=r"भारित औसत = Σ(अंक × भार) ÷ कुल भार।",
hx=r"""चरण 1: भारित योग \( = 75 \times 2 + 80 \times 3 + 90 \times 5 = 150 + 240 + 450 = 840 \)।
चरण 2: कुल भार \( = 2 + 3 + 5 = 10 \)।
चरण 3: भारित औसत \( = \dfrac{840}{10} = 84 \)।""",
),
5: dict(
et=r"Profit % = (articles SP-equivalent − articles sold) ÷ articles sold × 100.",
es=r"""Step 1: Let the cost price of 1 pen be ₹1. Then the CP of 60 pens = ₹60.
Step 2: He sells 60 pens for the purchase price of 72 pens, so SP = ₹72 and profit = \( 72 - 60 = 12 \).
Step 3: Profit % \( = \dfrac{12}{60} \times 100 = 20\% \).""",
hs=r"एक खुदरा विक्रेता 60 पेन खरीदता है और उन्हें 72 पेनों के क्रय मूल्य पर बेचता है। उसका लाभ प्रतिशत ज्ञात कीजिए।",
ht=r"लाभ% = (72 − 60) ÷ 60 × 100।",
hx=r"""चरण 1: मान लीजिए 1 पेन का क्रय मूल्य ₹1 है, तो 60 पेनों का क्रय मूल्य = ₹60।
चरण 2: वह 60 पेन, 72 पेनों के क्रय मूल्य पर बेचता है, अतः विक्रय मूल्य = ₹72 और लाभ = \( 72 - 60 = 12 \)।
चरण 3: लाभ% \( = \dfrac{12}{60} \times 100 = 20\% \)।""",
),
6: dict(
et=r"Convert every scheme to an effective discount %; least beneficial = smallest discount.",
es=r"""Step 1: Scheme (A): \( 100 - 100 \times 0.56 \times 0.88 = 100 - 49.28 = 50.72\% \) discount.
Step 2: Scheme (B): \( 100 - 100 \times 0.82 \times 0.57 \times 0.77 \approx 100 - 35.99 = 64.01\% \) discount.
Step 3: Scheme (C): for 10 toys of marked price 1 each, cost \( = 4 \times 0.92 + 6 \times 0.62 = 3.68 + 3.72 = 7.40 \), i.e. a 26% discount.
Step 4: Scheme (D): pays for 7 of 10 items, i.e. a 30% discount.
Step 5: The smallest discount is 26% under scheme (C), so scheme C is the least beneficial to her.""",
hs=r"एक दुकानदार समान अंकित मूल्य वाले खिलौनों पर निम्नलिखित योजनाएँ देता है।[BR](A) किसी भी संख्या में खिलौने खरीदने पर 44% और 12% की क्रमिक छूट।[BR](B) किसी भी संख्या में खिलौने खरीदने पर 18%, 43% और 23% की क्रमिक छूट।[BR](C) पहले 4 खिलौनों पर 8% छूट और उसके बाद प्रत्येक खिलौने पर 38% छूट।[BR](D) दस वस्तुएँ खरीदने पर ग्राहक से केवल सात वस्तुओं का बिल लिया जाता है।[BR]एक ग्राहक 10 खिलौने खरीदना चाहती है। उपरोक्त में से कौन-सी योजना उसके लिए सबसे कम लाभकारी है?",
ht=r"हर योजना को प्रभावी छूट% में बदलें; सबसे कम छूट = सबसे कम लाभकारी।",
hx=r"""चरण 1: योजना (A): \( 100 - 100 \times 0.56 \times 0.88 = 100 - 49.28 = 50.72\% \) छूट।
चरण 2: योजना (B): \( 100 - 100 \times 0.82 \times 0.57 \times 0.77 \approx 100 - 35.99 = 64.01\% \) छूट।
चरण 3: योजना (C): 1 अंकित मूल्य वाले 10 खिलौनों की लागत \( = 4 \times 0.92 + 6 \times 0.62 = 3.68 + 3.72 = 7.40 \), अर्थात 26% छूट।
चरण 4: योजना (D): 10 में से 7 वस्तुओं का भुगतान, अर्थात 30% छूट।
चरण 5: सबसे कम छूट (26%) योजना (C) में है, अतः योजना C उसके लिए सबसे कम लाभकारी है।""",
),
7: dict(
et=r"Form two equations from sum and relation, then subtract.",
es=r"""Step 1: Let the ages be \( x \) and \( y \) with \( x + y = 44 \) and \( y = 2x - 4 \).
Step 2: \( x + 2x - 4 = 44 \Rightarrow 3x = 48 \Rightarrow x = 16 \), so \( y = 28 \).
Step 3: Difference \( = 28 - 16 = 12 \) years.""",
hs=r"दो भाई-बहनों की आयु का योग 44 वर्ष है। यदि एक की आयु दूसरे की आयु के दोगुने से 4 वर्ष कम है, तो उनकी आयु में कितना अंतर है?",
ho={"10 years": "10 वर्ष", "12 years": "12 वर्ष", "14 years": "14 वर्ष", "8 years": "8 वर्ष"},
ht=r"योग और संबंध से दो समीकरण बनाकर हल करें।",
hx=r"""चरण 1: मान लीजिए आयु \( x \) और \( y \) हैं, जहाँ \( x + y = 44 \) और \( y = 2x - 4 \)।
चरण 2: \( x + 2x - 4 = 44 \Rightarrow 3x = 48 \Rightarrow x = 16 \), अतः \( y = 28 \)।
चरण 3: अंतर \( = 28 - 16 = 12 \) वर्ष।""",
),
8: dict(
et=r"Average speed = total distance ÷ total time (never the average of speeds).",
es=r"""Step 1: Distance \( = 72 \times 3 + 60 \times 1.5 = 216 + 90 = 306 \) km.
Step 2: Total time \( = 3 + 1.5 = 4.5 \) hours.
Step 3: Average speed \( = \dfrac{306}{4.5} = 68 \) km/h.""",
hs=r"एक रेलगाड़ी 3 घंटे तक 72 km/h की चाल से और फिर 1.5 घंटे तक 60 km/h की चाल से चलती है। रेलगाड़ी की औसत चाल क्या है?",
ht=r"औसत चाल = कुल दूरी ÷ कुल समय।",
hx=r"""चरण 1: दूरी \( = 72 \times 3 + 60 \times 1.5 = 216 + 90 = 306 \) km।
चरण 2: कुल समय \( = 3 + 1.5 = 4.5 \) घंटे।
चरण 3: औसत चाल \( = \dfrac{306}{4.5} = 68 \) km/h।""",
),
9: dict(
et=r"sin P = cos Q ⇒ P + Q = 90°; tan 45° + cot 45° = 2.",
es=r"""Step 1: \( \sin 6A = \cos 12A \) means \( 6A + 12A = 90^\circ \), so \( 18A = 90^\circ \) and \( A = 5^\circ \).
Step 2: Then \( 9A = 45^\circ \).
Step 3: \( \tan 45^\circ + \cot 45^\circ = 1 + 1 = 2 \).""",
hs=r"यदि sin6A = cos12A है, तो tan9A + cot9A का मान ज्ञात कीजिए।",
ht=r"sin P = cos Q ⇒ P + Q = 90°।",
hx=r"""चरण 1: \( \sin 6A = \cos 12A \) का अर्थ है \( 6A + 12A = 90^\circ \), अतः \( 18A = 90^\circ \) और \( A = 5^\circ \)।
चरण 2: तब \( 9A = 45^\circ \)।
चरण 3: \( \tan 45^\circ + \cot 45^\circ = 1 + 1 = 2 \)।""",
),
10: dict(
et=r"Successive changes multiply: MP × 0.75 × 1.20.",
es=r"""Step 1: After a 25% discount, price \( = 4000 \times 0.75 = 3000 \).
Step 2: Increasing this by 20% gives \( 3000 \times 1.20 = 3600 \).
Step 3: The final selling price is ₹3,600.""",
hs=r"एक दुकानदार किसी वस्तु पर ₹4,000 अंकित करता है। एक त्योहार के दौरान वह पहले अंकित मूल्य पर 25% छूट देता है। एक सप्ताह बाद, अधिक लाभ कमाने के लिए वह छूट वाले मूल्य को 20% बढ़ा देता है। इन क्रमिक परिवर्तनों के बाद वस्तु का अंतिम विक्रय मूल्य क्या है?",
ht=r"क्रमिक परिवर्तन गुणा होते हैं: 4000 × 0.75 × 1.20।",
hx=r"""चरण 1: 25% छूट के बाद मूल्य \( = 4000 \times 0.75 = 3000 \)।
चरण 2: इसमें 20% वृद्धि से \( 3000 \times 1.20 = 3600 \)।
चरण 3: अंतिम विक्रय मूल्य ₹3,600 है।""",
),
11: dict(
et=r"Same time ⇒ distances are in the ratio of speeds.",
es=r"""Step 1: Faster car's speed \( = \dfrac{140}{2} = 70 \) km/h, which is 7 parts.
Step 2: One part \( = 10 \) km/h, so the slower car's speed \( = 5 \times 10 = 50 \) km/h.
Step 3: In 2 hours the slower car covers \( 50 \times 2 = 100 \) km.""",
hs=r"दो कारों की चाल का अनुपात \( 5 : 7 \) है। तेज़ कार 2 घंटे में 140 km तय करती है। उतने ही समय में धीमी कार कितनी दूरी तय करेगी?",
ht=r"समान समय में दूरियाँ चालों के अनुपात में होती हैं।",
hx=r"""चरण 1: तेज़ कार की चाल \( = \dfrac{140}{2} = 70 \) km/h, जो 7 भाग है।
चरण 2: 1 भाग \( = 10 \) km/h, अतः धीमी कार की चाल \( = 5 \times 10 = 50 \) km/h।
चरण 3: 2 घंटे में धीमी कार \( 50 \times 2 = 100 \) km तय करती है।""",
),
12: dict(
et=r"If a + b + c = 0 then a³ + b³ + c³ = 3abc.",
es=r"""Step 1: Here \( a = 24,\; b = -7,\; c = -17 \) and \( a + b + c = 24 - 7 - 17 = 0 \).
Step 2: So \( a^{3} + b^{3} + c^{3} = 3abc \).
Step 3: \( 3 \times 24 \times (-7) \times (-17) = 3 \times 24 \times 119 = 8568 \).""",
hs=r"\( 24^{3} + (-7)^{3} + (-17)^{3} \) का मान ज्ञात कीजिए।",
ht=r"यदि a + b + c = 0, तो a³ + b³ + c³ = 3abc।",
hx=r"""चरण 1: यहाँ \( a = 24,\; b = -7,\; c = -17 \) और \( a + b + c = 24 - 7 - 17 = 0 \)।
चरण 2: अतः \( a^{3} + b^{3} + c^{3} = 3abc \)।
चरण 3: \( 3 \times 24 \times (-7) \times (-17) = 3 \times 24 \times 119 = 8568 \)।""",
),
13: dict(
et=r"Overall discount % = weighted average of the two rates.",
es=r"""Step 1: Discount on the first 70% of the price \( = 15\% \text{ of } 70\% = 10.5\% \) of the price.
Step 2: Discount on the remaining 30% \( = 5\% \text{ of } 30\% = 1.5\% \) of the price.
Step 3: Total discount \( = 10.5\% + 1.5\% = 12\% \) (₹6,000 on ₹50,000).""",
hs=r"एक टेलीविज़न ₹50,000 पर अंकित है। एक खुदरा विक्रेता मूल्य के पहले 70% पर 15% छूट और शेष पर 5% छूट देता है। दी गई कुल प्रतिशत छूट कितनी है?",
ht=r"कुल छूट% = दोनों दरों का भारित औसत।",
hx=r"""चरण 1: मूल्य के पहले 70% पर छूट = 70% का 15% \( = 0.15 \times 70\% = 10.5\% \)।
चरण 2: शेष 30% पर छूट = 30% का 5% \( = 0.05 \times 30\% = 1.5\% \)।
चरण 3: कुल छूट \( = 10.5\% + 1.5\% = 12\% \) (₹50,000 पर ₹6,000)।""",
),
14: dict(
et=r"Divisible by 4 ⇔ last two digits divisible by 4.",
es=r"""Step 1: 2X2 is divisible by 4 only if the two-digit number X2 is divisible by 4.
Step 2: Two-digit multiples of 4 ending in 2 are 12, 32, 52, 72 and 92, so X must be 1, 3, 5, 7 or 9.
Step 3: Among the given digits 1, 0, 4 and 2, only 1 works: \( 212 \div 4 = 53 \).""",
hs=r"निम्नलिखित में से कौन-सा अंक X के स्थान पर रखा जाए ताकि तीन अंकों की संख्या 2X2, 4 से विभाज्य हो?",
ht=r"4 से विभाज्यता ⇔ अंतिम दो अंक 4 से विभाज्य।",
hx=r"""चरण 1: 2X2, 4 से तभी विभाज्य है जब दो अंकों की संख्या X2, 4 से विभाज्य हो।
चरण 2: 2 पर समाप्त होने वाले 4 के दो-अंकीय गुणज 12, 32, 52, 72 और 92 हैं, अतः X = 1, 3, 5, 7 या 9।
चरण 3: दिए गए अंकों 1, 0, 4 और 2 में से केवल 1 सही है: \( 212 \div 4 = 53 \)।""",
),
15: dict(
et=r"Substitute, then cross-multiply the proportion.",
es=r"""Step 1: With a = 6, b = 8, c = 12: \( (6 + 2) : (8 - 2) = (12 + 4) : (d - 4) \), i.e. \( 8 : 6 = 16 : (d - 4) \).
Step 2: Cross-multiplying, \( 8(d - 4) = 6 \times 16 = 96 \Rightarrow d - 4 = 12 \).
Step 3: \( d = 16 \).""",
hs=r"चार संख्याएँ a, b, c और d संबंध \( (a + 2) : (b - 2) = (c + 4) : (d - 4) \) को संतुष्ट करती हैं। यदि a = 6, b = 8 और c = 12 है, तो d का मान ज्ञात कीजिए।",
ht=r"मान रखकर समानुपात में वज्र-गुणन करें।",
hx=r"""चरण 1: a = 6, b = 8, c = 12 रखने पर \( (6 + 2) : (8 - 2) = (12 + 4) : (d - 4) \), अर्थात \( 8 : 6 = 16 : (d - 4) \)।
चरण 2: वज्र-गुणन से \( 8(d - 4) = 6 \times 16 = 96 \Rightarrow d - 4 = 12 \)।
चरण 3: \( d = 16 \)।""",
),
16: dict(
et=r"Largest 4-digit multiple of the LCM, plus the common remainder.",
es=r"""Step 1: LCM(7, 6, 10) \( = 210 \).
Step 2: \( 9999 \div 210 = 47 \) remainder 129, so the largest four-digit multiple of 210 is \( 210 \times 47 = 9870 \).
Step 3: Required number \( = 9870 + 5 = 9875 \), which is still a four-digit number.""",
hs=r"चार अंकों की वह सबसे बड़ी संख्या, जिसे 7, 6 और 10 से भाग देने पर प्रत्येक स्थिति में शेषफल 5 आता है, है:",
ht=r"LCM का सबसे बड़ा चार-अंकीय गुणज + समान शेषफल।",
hx=r"""चरण 1: LCM(7, 6, 10) \( = 210 \)।
चरण 2: \( 9999 \div 210 = 47 \) शेष 129, अतः 210 का सबसे बड़ा चार-अंकीय गुणज \( = 210 \times 47 = 9870 \)।
चरण 3: अभीष्ट संख्या \( = 9870 + 5 = 9875 \), जो अब भी चार अंकों की है।""",
),
17: dict(
et=r"Opposite: add speeds; same direction: subtract speeds; distance = sum of lengths.",
es=r"""Step 1: Total length \( = 200 + 300 = 500 \) m. Opposite directions: relative speed \( = \dfrac{500}{15} = \dfrac{100}{3} \) m/s \( = 120 \) km/h.
Step 2: Speed of Y \( = 120 - 72 = 48 \) km/h.
Step 3: Same direction: relative speed \( = 72 - 48 = 24 \) km/h \( = \dfrac{24 \times 5}{18} = \dfrac{20}{3} \) m/s.
Step 4: Time \( = 500 \div \dfrac{20}{3} = 75 \) seconds.""",
hs=r"दो रेलगाड़ियाँ X और Y समानांतर पटरियों पर चल रही हैं। रेलगाड़ी X 200 m लंबी है और 72 km/hr की चाल से चलती है। रेलगाड़ी Y 300 m लंबी है। यदि रेलगाड़ियाँ विपरीत दिशाओं में चल रही हों, तो वे 15 सेकंड में एक-दूसरे को पूरी तरह पार कर लेती हैं। यदि रेलगाड़ियाँ एक ही दिशा में चल रही होतीं, तो तेज़ रेलगाड़ी को धीमी रेलगाड़ी से आगे निकलने में कितना समय लगता?",
ho={"72 seconds": "72 सेकंड", "67.5 seconds": "67.5 सेकंड", "75 seconds": "75 सेकंड", "78 seconds": "78 सेकंड"},
ht=r"विपरीत दिशा: चालें जोड़ें; एक ही दिशा: चालें घटाएँ; दूरी = लंबाइयों का योग।",
hx=r"""चरण 1: कुल लंबाई \( = 200 + 300 = 500 \) m। विपरीत दिशा में सापेक्ष चाल \( = \dfrac{500}{15} = \dfrac{100}{3} \) m/s \( = 120 \) km/h।
चरण 2: Y की चाल \( = 120 - 72 = 48 \) km/h।
चरण 3: एक ही दिशा में सापेक्ष चाल \( = 72 - 48 = 24 \) km/h \( = \dfrac{24 \times 5}{18} = \dfrac{20}{3} \) m/s।
चरण 4: समय \( = 500 \div \dfrac{20}{3} = 75 \) सेकंड।""",
),
18: dict(
et=r"Rhombus side = √((d₁/2)² + (d₂/2)²); perimeter = 4 × side.",
es=r"""Step 1: The diagonals bisect each other at right angles, so the half-diagonals are 112 m and 210 m.
Step 2: Side \( = \sqrt{112^{2} + 210^{2}} = \sqrt{12544 + 44100} = \sqrt{56644} = 238 \) m.
Step 3: Perimeter \( = 4 \times 238 = 952 \) m.""",
hs=r"एक समचतुर्भुजाकार खेत के विकर्ण 224 m और 420 m लंबे हैं। खेत का परिमाप (m में) क्या है?",
ht=r"समचतुर्भुज की भुजा = √((d₁/2)² + (d₂/2)²)।",
hx=r"""चरण 1: विकर्ण एक-दूसरे को समकोण पर समद्विभाजित करते हैं, अतः अर्ध-विकर्ण 112 m और 210 m हैं।
चरण 2: भुजा \( = \sqrt{112^{2} + 210^{2}} = \sqrt{12544 + 44100} = \sqrt{56644} = 238 \) m।
चरण 3: परिमाप \( = 4 \times 238 = 952 \) m।""",
),
19: dict(
et=r"A = P(1 + r/100)ⁿ.",
es=r"""Step 1: Amount \( = P\left(1 + \dfrac{R}{100}\right)^{n} = 4000 \times (1.1)^{2} \).
Step 2: \( (1.1)^{2} = 1.21 \), so the amount \( = 4000 \times 1.21 \).
Step 3: Amount \( = 4840 \), i.e. ₹4840.""",
hs=r"₹4000 को 10% वार्षिक चक्रवृद्धि ब्याज पर, वार्षिक रूप से संयोजित, 2 वर्षों के लिए निवेश करने पर कुल राशि की गणना कीजिए।",
ht=r"मिश्रधन = P(1 + r/100)ⁿ।",
hx=r"""चरण 1: मिश्रधन \( = P\left(1 + \dfrac{R}{100}\right)^{n} = 4000 \times (1.1)^{2} \)।
चरण 2: \( (1.1)^{2} = 1.21 \), अतः मिश्रधन \( = 4000 \times 1.21 \)।
चरण 3: मिश्रधन \( = 4840 \), अर्थात ₹4840।""",
),
20: dict(
et=r"Net rate = sum of filling rates − emptying rate.",
es=r"""Step 1: Net work per hour \( = \dfrac{1}{4} + \dfrac{1}{11} - \dfrac{1}{11} = \dfrac{1}{4} \) of the cistern.
Step 2: The filling and emptying taps of 11 hours cancel, so the full cistern fills in 4 hours.
Step 3: One-fourth of it fills in \( 4 \times \dfrac{1}{4} = 1 \) hour.""",
hs=r"दो नल किसी टंकी को क्रमशः 4 घंटे और 11 घंटे में भर सकते हैं। एक तीसरा नल उसे 11 घंटे में खाली कर सकता है। यदि सभी नल एक साथ खोल दिए जाएँ, तो खाली टंकी का एक-चौथाई भाग भरने में कितना समय (घंटों में) लगेगा?",
ht=r"शुद्ध दर = भरने की दरों का योग − खाली करने की दर।",
hx=r"""चरण 1: प्रति घंटा शुद्ध कार्य \( = \dfrac{1}{4} + \dfrac{1}{11} - \dfrac{1}{11} = \dfrac{1}{4} \) टंकी।
चरण 2: 11 घंटे वाले भरने और खाली करने वाले नल एक-दूसरे को निरस्त कर देते हैं, अतः पूरी टंकी 4 घंटे में भरती है।
चरण 3: इसका एक-चौथाई भाग \( 4 \times \dfrac{1}{4} = 1 \) घंटे में भरेगा।""",
),
21: dict(
et=r"Appending d makes 10N + d; find d so that 13 divides it.",
es=r"""Step 1: \( 92419 = 13 \times 7109 + 2 \), so 92419 leaves remainder 2 on division by 13.
Step 2: Appending a digit d gives \( 10 \times 92419 + d \), whose remainder is \( 10 \times 2 + d = 20 + d \) (mod 13), i.e. \( 7 + d \) (mod 13).
Step 3: \( 7 + d \) is a multiple of 13 when \( d = 6 \); check: \( 924196 = 13 \times 71092 \).""",
hs=r"एक लेन-देन कोड 92419, 13 से विभाज्य नहीं है। इसे 13 से विभाज्य बनाने के लिए संख्या के अंत में सबसे छोटा अंक जोड़ा जाना चाहिए। वह अंक क्या है?",
ht=r"अंत में अंक d जोड़ने पर संख्या 10N + d बनती है; d ऐसा चुनें कि यह 13 से विभाज्य हो।",
hx=r"""चरण 1: \( 92419 = 13 \times 7109 + 2 \), अतः 13 से भाग देने पर शेषफल 2 है।
चरण 2: अंक d जोड़ने पर संख्या \( 10 \times 92419 + d \) बनती है, जिसका शेषफल \( 10 \times 2 + d = 20 + d \) (mod 13), अर्थात \( 7 + d \) (mod 13) है।
चरण 3: \( d = 6 \) पर \( 7 + d \) 13 का गुणज है; जाँच: \( 924196 = 13 \times 71092 \)।""",
),
22: dict(
et=r"Write L = 72 − S, apply the new ratio and solve.",
es=r"""Step 1: Let the smaller number be \( S \); the larger is \( 72 - S \).
Step 2: \( \dfrac{(72 - S) + 8}{S - 6} = \dfrac{3}{2} \Rightarrow 2(80 - S) = 3(S - 6) \).
Step 3: \( 160 - 2S = 3S - 18 \Rightarrow 5S = 178 \Rightarrow S = 35.6 \).""",
hs=r"दो संख्याओं का योग 72 है। यदि बड़ी संख्या में 8 की वृद्धि की जाए और छोटी संख्या में 6 की कमी की जाए, तो परिणामी संख्याएँ क्रमशः \( 3 : 2 \) के अनुपात में होती हैं। मूल दो संख्याओं में से छोटी संख्या ज्ञात कीजिए।",
ht=r"बड़ी संख्या = 72 − छोटी; नया अनुपात लगाकर हल करें।",
hx=r"""चरण 1: मान लीजिए छोटी संख्या \( S \) है; बड़ी संख्या \( 72 - S \) है।
चरण 2: \( \dfrac{(72 - S) + 8}{S - 6} = \dfrac{3}{2} \Rightarrow 2(80 - S) = 3(S - 6) \)।
चरण 3: \( 160 - 2S = 3S - 18 \Rightarrow 5S = 178 \Rightarrow S = 35.6 \)।""",
),
23: dict(
et=r"Difference of percentages × number = given difference.",
es=r"""Step 1: \( 40\% - 25\% = 15\% \) of the number is 36.
Step 2: Number \( = \dfrac{36 \times 100}{15} \).
Step 3: Number \( = 240 \).""",
hs=r"यदि किसी संख्या का 40%, उसी के 25% से 36 अधिक है, तो वह संख्या है:",
ht=r"प्रतिशतों का अंतर × संख्या = दिया गया अंतर।",
hx=r"""चरण 1: संख्या का \( 40\% - 25\% = 15\% \) भाग 36 है।
चरण 2: संख्या \( = \dfrac{36 \times 100}{15} \)।
चरण 3: संख्या \( = 240 \)।""",
),
24: dict(
et=r"Fall in total = fall in average × k.",
es=r"""Step 1: Subtracting 48 from each of two numbers lowers the total by \( 2 \times 48 = 96 \).
Step 2: The average falls from \( x \) to \( x - 12 \), i.e. by 12, so the total falls by \( 12k \).
Step 3: \( 12k = 96 \Rightarrow k = 8 \).""",
hs=r"k संख्याओं का औसत x है। यदि किन्हीं दो संख्याओं में से प्रत्येक में से 48 घटा दिया जाए, तो नया औसत (x − 12) प्राप्त होता है। k का मान ज्ञात कीजिए।",
ht=r"योग में कमी = औसत में कमी × k।",
hx=r"""चरण 1: दो संख्याओं में से प्रत्येक में से 48 घटाने पर योग \( 2 \times 48 = 96 \) घटता है।
चरण 2: औसत \( x \) से घटकर \( x - 12 \) होता है, अर्थात 12 कम, अतः योग \( 12k \) घटता है।
चरण 3: \( 12k = 96 \Rightarrow k = 8 \)।""",
),
25: dict(
et=r"Successive discounts multiply the remaining fractions.",
es=r"""Step 1: After three successive 10% discounts, the price paid \( = 100 \times 0.9 \times 0.9 \times 0.9 \).
Step 2: \( 0.9^{3} = 0.729 \), so 72.9% of the price is paid.
Step 3: Single equivalent discount \( = 100 - 72.9 = 27.1\% \).""",
hs=r"किसी वस्तु पर 10% की तीन क्रमिक छूटों के समतुल्य एकल छूट ज्ञात कीजिए।",
ht=r"क्रमिक छूटों में बचे हुए भिन्न गुणा होते हैं।",
hx=r"""चरण 1: 10% की तीन क्रमिक छूटों के बाद भुगतान मूल्य \( = 100 \times 0.9 \times 0.9 \times 0.9 \)।
चरण 2: \( 0.9^{3} = 0.729 \), अतः मूल्य का 72.9% भुगतान होता है।
चरण 3: समतुल्य एकल छूट \( = 100 - 72.9 = 27.1\% \)।""",
),
26: dict(
et=r"Take 9^(x−1) common: 9^(x−1) × (9 − 1) = 72.",
es=r"""Step 1: \( 9^{x} - 9^{x-1} = 9^{x-1}(9 - 1) = 8 \times 9^{x-1} = 72 \).
Step 2: \( 9^{x-1} = 9 = 9^{1} \Rightarrow x - 1 = 1 \Rightarrow x = 2 \).
Step 3: \( \dfrac{2x - 1}{2x + 3} = \dfrac{4 - 1}{4 + 3} = \dfrac{3}{7} \).""",
hs=r"यदि \( 9^{x} - 9^{x-1} = 72 \) है, तो \( \dfrac{2x - 1}{2x + 3} \) का मान है:",
ht=r"9^(x−1) उभयनिष्ठ लें: 9^(x−1) × (9 − 1) = 72।",
hx=r"""चरण 1: \( 9^{x} - 9^{x-1} = 9^{x-1}(9 - 1) = 8 \times 9^{x-1} = 72 \)।
चरण 2: \( 9^{x-1} = 9 = 9^{1} \Rightarrow x - 1 = 1 \Rightarrow x = 2 \)।
चरण 3: \( \dfrac{2x - 1}{2x + 3} = \dfrac{4 - 1}{4 + 3} = \dfrac{3}{7} \)।""",
),
27: dict(
et=r"Vinculum (bar) first, then ( ), { }, [ ].",
es=r"""Step 1: Vinculum: \( \overline{2.2 - 1.8} = 0.4 \), so \( 3.2 - 0.4 = 2.8 \).
Step 2: Curly bracket: \( 3.3 - 2.8 = 0.5 \); square bracket: \( 6.5 - 0.5 = 6 \).
Step 3: \( 10.5 - 6 = 4.5 \).""",
hs=r"सरल कीजिए: \( 10.5 - [6.5 - \{3.3 - (3.2 - \overline{2.2 - 1.8})\}] \)",
ht=r"पहले रेखा-कोष्ठक (vinculum), फिर ( ), { }, [ ]।",
hx=r"""चरण 1: रेखा-कोष्ठक: \( \overline{2.2 - 1.8} = 0.4 \), अतः \( 3.2 - 0.4 = 2.8 \)।
चरण 2: मझला कोष्ठक: \( 3.3 - 2.8 = 0.5 \); बड़ा कोष्ठक: \( 6.5 - 0.5 = 6 \)।
चरण 3: \( 10.5 - 6 = 4.5 \)।""",
),
28: dict(
et=r"Net rate = 1/18 + 1/9 − 1/27 per hour; time = 1 ÷ net rate.",
es=r"""Step 1: Per hour: M fills \( \dfrac{1}{18} \), N fills \( \dfrac{1}{9} \) and the leak empties \( \dfrac{1}{27} \) of the tank.
Step 2: Net \( = \dfrac{3 + 6 - 2}{54} = \dfrac{7}{54} \) of the tank per hour.
Step 3: Time \( = \dfrac{54}{7} = 7\dfrac{5}{7} \) hours.""",
hs=r"एक टंकी को दो नलों M और N द्वारा भरा जा रहा है। M टंकी को 18 घंटे में पूरा भरता है और N उसे 9 घंटे में भरता है। टंकी के तल में एक रिसाव पूरी भरी टंकी को 27 घंटे में खाली कर सकता है। यदि रिसाव जारी रहते हुए दोनों नल खोल दिए जाएँ, तो खाली टंकी को पूरा भरने में कितना समय लगेगा?",
ho={r"\( 6\dfrac{5}{7} \) hours": r"\( 6\dfrac{5}{7} \) घंटे", r"\( 7\dfrac{3}{7} \) hours": r"\( 7\dfrac{3}{7} \) घंटे", r"\( 7\dfrac{5}{7} \) hours": r"\( 7\dfrac{5}{7} \) घंटे", r"\( 6\dfrac{4}{7} \) hours": r"\( 6\dfrac{4}{7} \) घंटे"},
ht=r"शुद्ध दर = 1/18 + 1/9 − 1/27 प्रति घंटा; समय = 1 ÷ शुद्ध दर।",
hx=r"""चरण 1: प्रति घंटा: M टंकी का \( \dfrac{1}{18} \), N \( \dfrac{1}{9} \) भाग भरता है और रिसाव \( \dfrac{1}{27} \) भाग खाली करता है।
चरण 2: शुद्ध \( = \dfrac{3 + 6 - 2}{54} = \dfrac{7}{54} \) टंकी प्रति घंटा।
चरण 3: समय \( = \dfrac{54}{7} = 7\dfrac{5}{7} \) घंटे।""",
),
29: dict(
et=r"CSA = 2πrh; TSA = 2πr(h + r).",
es=r"""Step 1: CSA of the first cylinder \( = 2\pi r h = 2\pi \times 4 \times 7 = 56\pi \) cm².
Step 2: Second cylinder: \( r = 2 \) cm; TSA \( = 2\pi \times 2 \times (h + 2) = 4\pi(h + 2) = 56\pi \Rightarrow h + 2 = 14 \Rightarrow h = 12 \) cm.
Step 3: CSA of the second cylinder \( = 2\pi \times 2 \times 12 = 48\pi \) cm².""",
hs=r"एक ठोस बेलन का वक्र पृष्ठीय क्षेत्रफल संख्यात्मक रूप से एक अन्य बेलन के कुल पृष्ठीय क्षेत्रफल के बराबर है, जिसकी त्रिज्या पहले बेलन की त्रिज्या की आधी है। यदि पहले बेलन की ऊँचाई और त्रिज्या क्रमशः 7 cm और 4 cm हैं, तो दूसरे बेलन का वक्र पृष्ठीय क्षेत्रफल ज्ञात कीजिए।",
ht=r"वक्र पृष्ठ = 2πrh; कुल पृष्ठ = 2πr(h + r)।",
hx=r"""चरण 1: पहले बेलन का वक्र पृष्ठीय क्षेत्रफल \( = 2\pi r h = 2\pi \times 4 \times 7 = 56\pi \) cm²।
चरण 2: दूसरा बेलन: \( r = 2 \) cm; कुल पृष्ठ \( = 2\pi \times 2 \times (h + 2) = 4\pi(h + 2) = 56\pi \Rightarrow h + 2 = 14 \Rightarrow h = 12 \) cm।
चरण 3: दूसरे बेलन का वक्र पृष्ठीय क्षेत्रफल \( = 2\pi \times 2 \times 12 = 48\pi \) cm²।""",
),
30: dict(
et=r"In a trapezium, the segment joining the midpoints of the diagonals = half the difference of the parallel sides.",
es=r"""Step 1: AB \( \parallel \) DC, so ABCD is a trapezium with parallel sides AB = 74 cm and DC = 26 cm.
Step 2: The segment joining the midpoints of the diagonals of a trapezium is parallel to the bases and equals \( \dfrac{AB - DC}{2} \); BC and AD are not needed.
Step 3: EF \( = \dfrac{74 - 26}{2} = \dfrac{48}{2} = 24 \) cm.""",
hs=r"ABCD एक चतुर्भुज है जिसमें AB \( \parallel \) DC है, तथा E और F क्रमशः विकर्णों AC और BD के मध्य-बिंदु हैं। यदि AB = 74 cm, BC = 91 cm, DC = 26 cm और AD = 39 cm है, तो EF की लंबाई (cm में) क्या है?",
ht=r"समलंब में विकर्णों के मध्य-बिंदुओं को मिलाने वाला रेखाखंड = समांतर भुजाओं के अंतर का आधा।",
hx=r"""चरण 1: AB \( \parallel \) DC, अतः ABCD एक समलंब है जिसकी समांतर भुजाएँ AB = 74 cm और DC = 26 cm हैं।
चरण 2: समलंब के विकर्णों के मध्य-बिंदुओं को मिलाने वाला रेखाखंड आधारों के समांतर और \( \dfrac{AB - DC}{2} \) के बराबर होता है; BC और AD की आवश्यकता नहीं है।
चरण 3: EF \( = \dfrac{74 - 26}{2} = \dfrac{48}{2} = 24 \) cm।""",
),
}
