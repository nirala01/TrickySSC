D = {
51: dict(
et=r"CSW69 (March 2025): UN Headquarters, New York — Beijing+30 review.",
es=r"""-> The 69th session of the UN Commission on the Status of Women (CSW69) was held at the UN Headquarters in New York, USA, in March 2025.
-> It reviewed 30 years of the Beijing Declaration and Platform for Action (Beijing+30).
-> The Commission meets every year in New York, usually in March, under the UN Economic and Social Council (ECOSOC).
-> Rio de Janeiro, Berlin and Oslo are not the venues of CSW sessions.""",
ef=[r"The CSW was established in 1946 by ECOSOC.", r"The Fourth World Conference on Women was held in Beijing in 1995."],
hs=r"मार्च 2025 में महिलाओं की स्थिति पर संयुक्त राष्ट्र आयोग का 69वाँ सत्र कहाँ आयोजित हुआ?",
ho={"Rio de Janeiro, Brazil": "रियो डी जनेरियो, ब्राज़ील", "New York, USA": "न्यूयॉर्क, अमेरिका", "Berlin, Germany": "बर्लिन, जर्मनी", "Oslo, Norway": "ओस्लो, नॉर्वे"},
ht=r"CSW69 (मार्च 2025): संयुक्त राष्ट्र मुख्यालय, न्यूयॉर्क — बीजिंग+30 समीक्षा।",
hx=r"""-> महिलाओं की स्थिति पर संयुक्त राष्ट्र आयोग का 69वाँ सत्र (CSW69) मार्च 2025 में न्यूयॉर्क, अमेरिका स्थित संयुक्त राष्ट्र मुख्यालय में हुआ।
-> इसमें बीजिंग घोषणा और कार्य-मंच के 30 वर्षों (बीजिंग+30) की समीक्षा हुई।
-> यह आयोग संयुक्त राष्ट्र आर्थिक और सामाजिक परिषद (ECOSOC) के अंतर्गत हर वर्ष, सामान्यतः मार्च में, न्यूयॉर्क में बैठक करता है।
-> रियो डी जनेरियो, बर्लिन और ओस्लो CSW सत्रों के स्थल नहीं हैं।""",
hf=[r"CSW की स्थापना 1946 में ECOSOC द्वारा की गई।", r"महिलाओं पर चौथा विश्व सम्मेलन 1995 में बीजिंग में हुआ।"],
),
52: dict(
et=r"Gangaikonda(chola) = Rajendra I, after his Ganga expedition.",
es=r"""-> Rajendra Chola I assumed the title "Gangaikonda" (Gangaikondachola — the Chola who conquered the Ganga) after his northern campaign to the Ganga around 1022 CE.
-> He built a new capital, Gangaikondacholapuram, with the Brihadisvara temple there.
-> Rajaraja I (his father) built the Brihadisvara temple at Thanjavur; Vijayalaya founded the imperial Chola line in the 9th century.
-> Pulakesin II was a Chalukya king of Badami, not a Chola.""",
ef=[r"Rajendra I also led a naval expedition to Srivijaya (South-East Asia) and took the title 'Kadaramkonda'.", r"Chola village administration is known from the Uttaramerur inscriptions."],
hs=r"प्रारंभिक मध्यकाल के निम्नलिखित राजाओं में से किसने 'गंगईकोंड' उपाधि धारण की?",
ho={"Rajaraja I": "राजराज प्रथम", "Rajendra I": "राजेंद्र प्रथम", "Pulakesin II": "पुलकेशिन द्वितीय", "Vijayalaya": "विजयालय"},
ht=r"गंगईकोंड (चोल) = राजेंद्र प्रथम, गंगा अभियान के बाद।",
hx=r"""-> राजेंद्र चोल प्रथम ने लगभग 1022 ई. में गंगा तक के उत्तरी अभियान के बाद "गंगईकोंड" (गंगईकोंडचोल — गंगा को जीतने वाला चोल) उपाधि धारण की।
-> उसने नई राजधानी गंगईकोंडचोलपुरम बसाई और वहाँ बृहदीश्वर मंदिर बनवाया।
-> राजराज प्रथम (उसके पिता) ने तंजावुर का बृहदीश्वर मंदिर बनवाया; विजयालय ने 9वीं शताब्दी में शाही चोल वंश की स्थापना की।
-> पुलकेशिन द्वितीय बादामी का चालुक्य राजा था, चोल नहीं।""",
hf=[r"राजेंद्र प्रथम ने श्रीविजय (दक्षिण-पूर्व एशिया) तक नौसैनिक अभियान भी किया और 'कडारमकोंड' उपाधि ली।", r"चोल ग्राम प्रशासन की जानकारी उत्तरमेरूर अभिलेखों से मिलती है।"],
),
53: dict(
et=r"Gita Rahasya — Bal Gangadhar Tilak (written in Mandalay jail).",
es=r"""-> Bal Gangadhar Tilak, a leading Extremist, wrote "Gita Rahasya", a commentary on the Bhagavad Gita stressing Karma Yoga.
-> He wrote it in Marathi while imprisoned in Mandalay jail (Burma) between 1908 and 1914.
-> Tilak also started the newspapers Kesari (Marathi) and Mahratta (English) and gave the slogan "Swaraj is my birthright".
-> Bipin Chandra Pal, Aurobindo Ghose and Lala Lajpat Rai were other Extremists but did not write this book.""",
ef=[r"Tilak also wrote 'The Arctic Home in the Vedas'.", r"He started the public Ganapati and Shivaji festivals in Maharashtra."],
hs=r"किस उग्रवादी नेता ने प्रसिद्ध कृति 'गीता रहस्य' लिखी?",
ho={"Bipin Chandra Pal": "बिपिन चंद्र पाल", "Aurobindo Ghose": "अरविंद घोष", "Lala Lajpat Rai": "लाला लाजपत राय", "Bal Gangadhar Tilak": "बाल गंगाधर तिलक"},
ht=r"गीता रहस्य — बाल गंगाधर तिलक (मांडले जेल में लिखी)।",
hx=r"""-> प्रमुख उग्रवादी नेता बाल गंगाधर तिलक ने कर्मयोग पर बल देने वाली भगवद्गीता की व्याख्या "गीता रहस्य" लिखी।
-> उन्होंने इसे 1908 से 1914 के बीच मांडले जेल (बर्मा) में बंदी रहते हुए मराठी में लिखा।
-> तिलक ने केसरी (मराठी) और मराठा (अंग्रेज़ी) समाचार-पत्र भी शुरू किए और "स्वराज मेरा जन्मसिद्ध अधिकार है" का नारा दिया।
-> बिपिन चंद्र पाल, अरविंद घोष और लाला लाजपत राय भी उग्रवादी थे, पर उन्होंने यह पुस्तक नहीं लिखी।""",
hf=[r"तिलक ने 'द आर्कटिक होम इन द वेदाज़' भी लिखी।", r"उन्होंने महाराष्ट्र में सार्वजनिक गणपति और शिवाजी उत्सव शुरू किए।"],
),
54: dict(
et=r"Society of Association Executives (SAE): launched in Bengaluru, October 2025.",
es=r"""-> India's Society of Association Executives (SAE) was officially launched in October 2025 in Bengaluru.
-> The launch took place at the Hilton, Embassy Manyata Business Park, Bengaluru.
-> SAE is a professional body for executives who run industry and professional associations, aligned with bodies such as ASAE (USA) and ESAE (Europe).
-> Ahmedabad, New Delhi and Patna were not the launch city.""",
ef=[r"ASAE stands for the American Society of Association Executives.", r"Bengaluru is the capital of Karnataka and is often called India's 'Silicon Valley'."],
hs=r"अक्टूबर 2025 में भारत की सोसाइटी ऑफ़ एसोसिएशन एग्ज़ीक्यूटिव्स (SAE) निम्नलिखित में से किस शहर में आधिकारिक रूप से शुरू की गई?",
ho={"Ahmedabad": "अहमदाबाद", "New Delhi": "नई दिल्ली", "Patna": "पटना", "Bengaluru": "बेंगलुरु"},
ht=r"सोसाइटी ऑफ़ एसोसिएशन एग्ज़ीक्यूटिव्स (SAE): बेंगलुरु, अक्टूबर 2025।",
hx=r"""-> भारत की सोसाइटी ऑफ़ एसोसिएशन एग्ज़ीक्यूटिव्स (SAE) अक्टूबर 2025 में बेंगलुरु में आधिकारिक रूप से शुरू की गई।
-> इसका शुभारंभ बेंगलुरु के हिल्टन, एम्बेसी मान्यता बिज़नेस पार्क में हुआ।
-> SAE उद्योग और पेशेवर संघों को चलाने वाले अधिकारियों का पेशेवर निकाय है, जो ASAE (अमेरिका) और ESAE (यूरोप) जैसे निकायों से जुड़ा है।
-> अहमदाबाद, नई दिल्ली और पटना शुभारंभ स्थल नहीं थे।""",
hf=[r"ASAE का पूरा रूप अमेरिकन सोसाइटी ऑफ़ एसोसिएशन एग्ज़ीक्यूटिव्स है।", r"बेंगलुरु कर्नाटक की राजधानी है और इसे भारत की 'सिलिकॉन वैली' कहा जाता है।"],
),
55: dict(
et=r"F = ma ⇒ 1 N = 1 kg⋅m/s².",
es=r"""-> By Newton's second law, force = mass × acceleration (F = ma).
-> Mass is measured in kg and acceleration in m/s², so the unit of force is kg⋅m/s².
-> One newton is the force that gives a mass of 1 kg an acceleration of 1 m/s².
-> kg⋅m/s is the unit of momentum, and kg⋅m²/s² is the unit of energy (joule).""",
ef=[r"1 joule = 1 newton × 1 metre = 1 kg⋅m²/s².", r"1 kilogram-weight (kgf) ≈ 9.8 N."],
hs=r"बल की SI व्युत्पन्न इकाई न्यूटन (N) है। SI मूल इकाइयों का कौन-सा संयोजन न्यूटन के तुल्य है?",
ht=r"F = ma ⇒ 1 N = 1 kg⋅m/s²।",
hx=r"""-> न्यूटन के गति के दूसरे नियम से, बल = द्रव्यमान × त्वरण (F = ma)।
-> द्रव्यमान kg में और त्वरण m/s² में मापा जाता है, अतः बल की इकाई kg⋅m/s² है।
-> एक न्यूटन वह बल है जो 1 kg द्रव्यमान को 1 m/s² का त्वरण देता है।
-> kg⋅m/s संवेग की इकाई है, और kg⋅m²/s² ऊर्जा (जूल) की इकाई है।""",
hf=[r"1 जूल = 1 न्यूटन × 1 मीटर = 1 kg⋅m²/s²।", r"1 किलोग्राम-भार (kgf) ≈ 9.8 N।"],
),
56: dict(
et=r"Chandrayaan-5 (LUPEX, with JAXA): launched on Japan's H3-24L.",
es=r"""-> Chandrayaan-5 is the joint India–Japan Lunar Polar Exploration mission (LUPEX) of ISRO and JAXA.
-> It will be launched on Japan's H3-24L rocket.
-> JAXA is providing the launch vehicle and the rover, while ISRO is providing the lander.
-> The mission will study water ice and other volatiles near the Moon's south pole; PSLV and GSLV variants are not its launcher.""",
ef=[r"Chandrayaan-3's Vikram lander touched down near the lunar south pole on 23 August 2023, now observed as National Space Day.", r"Chandrayaan-3 was launched by LVM3 (earlier called GSLV Mk III)."],
hs=r"चंद्रयान-5 के लिए किस प्रक्षेपण यान का उपयोग किया जाएगा?",
ht=r"चंद्रयान-5 (LUPEX, JAXA के साथ): जापान के H3-24L से प्रक्षेपण।",
hx=r"""-> चंद्रयान-5, ISRO और JAXA का भारत–जापान संयुक्त चंद्र ध्रुवीय अन्वेषण मिशन (LUPEX) है।
-> इसे जापान के H3-24L रॉकेट से प्रक्षेपित किया जाएगा।
-> JAXA प्रक्षेपण यान और रोवर दे रहा है, जबकि ISRO लैंडर दे रहा है।
-> यह मिशन चंद्रमा के दक्षिणी ध्रुव के पास जल-बर्फ़ और अन्य वाष्पशील पदार्थों का अध्ययन करेगा; PSLV और GSLV संस्करण इसके प्रक्षेपक नहीं हैं।""",
hf=[r"चंद्रयान-3 का विक्रम लैंडर 23 अगस्त 2023 को चंद्र दक्षिणी ध्रुव के पास उतरा, यह दिन अब राष्ट्रीय अंतरिक्ष दिवस है।", r"चंद्रयान-3 को LVM3 (पहले GSLV Mk III) से प्रक्षेपित किया गया।"],
),
57: dict(
et=r"Article 141: SC's law binds all courts in India.",
es=r"""-> Article 141 says that the law declared by the Supreme Court shall be binding on all courts within the territory of India.
-> This includes High Courts, district and subordinate courts and tribunals.
-> The binding effect makes Supreme Court judgments precedents for the whole country.
-> Article 142 lets the Supreme Court pass any order needed for "complete justice", and Article 144 requires all authorities to act in aid of the Supreme Court.""",
ef=[r"The Supreme Court itself is not bound by its earlier decisions and can overrule them.", r"Article 124 deals with the establishment and constitution of the Supreme Court."],
hs=r"भारतीय संविधान का अनुच्छेद 141 घोषित करता है कि सर्वोच्च न्यायालय द्वारा निर्धारित विधि ____ पर बाध्यकारी है।",
ho={"State governments": "राज्य सरकारों", "Only High Courts": "केवल उच्च न्यायालयों", "All tribunals except civil courts": "दीवानी न्यायालयों को छोड़कर सभी न्यायाधिकरणों", "All courts within the territory of India": "भारत के राज्यक्षेत्र के भीतर सभी न्यायालयों"},
ht=r"अनुच्छेद 141: सर्वोच्च न्यायालय की विधि भारत के सभी न्यायालयों पर बाध्यकारी।",
hx=r"""-> अनुच्छेद 141 के अनुसार सर्वोच्च न्यायालय द्वारा घोषित विधि भारत के राज्यक्षेत्र के भीतर सभी न्यायालयों पर बाध्यकारी होगी।
-> इसमें उच्च न्यायालय, ज़िला और अधीनस्थ न्यायालय तथा न्यायाधिकरण शामिल हैं।
-> इसी बाध्यकारी प्रभाव से सर्वोच्च न्यायालय के निर्णय पूरे देश के लिए नज़ीर बनते हैं।
-> अनुच्छेद 142 सर्वोच्च न्यायालय को "पूर्ण न्याय" के लिए आवश्यक आदेश देने देता है, और अनुच्छेद 144 सभी प्राधिकारियों को सर्वोच्च न्यायालय की सहायता करने को कहता है।""",
hf=[r"सर्वोच्च न्यायालय स्वयं अपने पूर्व निर्णयों से बाध्य नहीं है और उन्हें पलट सकता है।", r"अनुच्छेद 124 सर्वोच्च न्यायालय की स्थापना और गठन से संबंधित है।"],
),
58: dict(
et=r"CAA 2019: Afghanistan, Bangladesh, Pakistan; entry on or before 31 Dec 2014.",
es=r"""-> The Citizenship (Amendment) Act, 2019 covers Hindu, Sikh, Buddhist, Jain, Parsi and Christian migrants from Afghanistan, Bangladesh and Pakistan.
-> Those who entered India on or before 31 December 2014 are eligible for Indian citizenship.
-> It reduced the residence requirement for naturalisation for these groups from 11 years to 5 years.
-> Bhutan, Maldives, Sri Lanka, Myanmar and Nepal are not covered by the Act.""",
ef=[r"The CAA rules were notified in March 2024.", r"Citizenship is in the Union List, and Articles 5–11 of the Constitution deal with it."],
hs=r"CAA, 2019 के अंतर्गत निम्नलिखित में से किन देशों के हिंदू, सिख, बौद्ध, जैन, पारसी और ईसाई नागरिक, यदि वे 31 दिसंबर 2014 को या उससे पहले भारत आए हों, भारतीय नागरिकता प्राप्त करने के पात्र हैं?",
ho={"Bhutan, Bangladesh, and Maldives": "भूटान, बांग्लादेश और मालदीव", "Afghanistan, Sri Lanka, and Bangladesh": "अफ़ग़ानिस्तान, श्रीलंका और बांग्लादेश", "Pakistan, Myanmar, and Nepal": "पाकिस्तान, म्यांमार और नेपाल", "Afghanistan, Bangladesh, and Pakistan": "अफ़ग़ानिस्तान, बांग्लादेश और पाकिस्तान"},
ht=r"CAA 2019: अफ़ग़ानिस्तान, बांग्लादेश, पाकिस्तान; 31 दिसंबर 2014 तक प्रवेश।",
hx=r"""-> नागरिकता (संशोधन) अधिनियम, 2019 अफ़ग़ानिस्तान, बांग्लादेश और पाकिस्तान से आए हिंदू, सिख, बौद्ध, जैन, पारसी और ईसाई प्रवासियों पर लागू है।
-> जो 31 दिसंबर 2014 को या उससे पहले भारत आए, वे भारतीय नागरिकता के पात्र हैं।
-> इसने इन समूहों के लिए देशीयकरण की निवास-अवधि 11 वर्ष से घटाकर 5 वर्ष कर दी।
-> भूटान, मालदीव, श्रीलंका, म्यांमार और नेपाल इस अधिनियम में शामिल नहीं हैं।""",
hf=[r"CAA के नियम मार्च 2024 में अधिसूचित हुए।", r"नागरिकता संघ सूची का विषय है, और संविधान के अनुच्छेद 5–11 इससे संबंधित हैं।"],
),
59: dict(
et=r"Airborne microplastics over the Sundarbans (2025): IISER Kolkata.",
es=r"""-> Scientists of the Indian Institute of Science Education and Research (IISER) Kolkata detected airborne microplastics over the Sundarbans mangroves in 2025.
-> The team sampled PM10-bound particles over the protected mangrove forest during a winter campaign in January 2025.
-> It was reported as the first evidence of airborne microplastics in any natural ecosystem of India.
-> NIO Goa, IIT Kharagpur and WII Dehradun did not carry out this study.""",
ef=[r"The Sundarbans is the world's largest contiguous mangrove forest, in the Ganga–Brahmaputra–Meghna delta.", r"Sundarbans National Park is a UNESCO World Heritage Site and a tiger reserve."],
hs=r"सुंदरबन के मैंग्रोव में वायुवाहित माइक्रोप्लास्टिक का पता लगाने वाला 2025 का अध्ययन किस संस्थान के वैज्ञानिकों ने किया?",
ho={"NIO Goa": "NIO गोवा", "IISER Kolkata": "IISER कोलकाता", "IIT Kharagpur": "IIT खड़गपुर", "WII Dehradun": "WII देहरादून"},
ht=r"सुंदरबन के ऊपर वायुवाहित माइक्रोप्लास्टिक (2025): IISER कोलकाता।",
hx=r"""-> भारतीय विज्ञान शिक्षा एवं अनुसंधान संस्थान (IISER) कोलकाता के वैज्ञानिकों ने 2025 में सुंदरबन के मैंग्रोव के ऊपर वायुवाहित माइक्रोप्लास्टिक का पता लगाया।
-> दल ने जनवरी 2025 में शीतकालीन अभियान के दौरान संरक्षित मैंग्रोव वन के ऊपर PM10 से जुड़े कणों के नमूने लिए।
-> इसे भारत के किसी भी प्राकृतिक पारिस्थितिकी तंत्र में वायुवाहित माइक्रोप्लास्टिक का पहला प्रमाण बताया गया।
-> NIO गोवा, IIT खड़गपुर और WII देहरादून ने यह अध्ययन नहीं किया।""",
hf=[r"सुंदरबन गंगा–ब्रह्मपुत्र–मेघना डेल्टा में स्थित विश्व का सबसे बड़ा सतत मैंग्रोव वन है।", r"सुंदरबन राष्ट्रीय उद्यान यूनेस्को विश्व धरोहर स्थल और बाघ अभयारण्य है।"],
),
60: dict(
et=r"UNDP = United Nations Development Programme (1965, New York).",
es=r"""-> UNDP stands for United Nations Development Programme.
-> It was established in 1965 and has its headquarters in New York.
-> It works to eradicate poverty and reduce inequality and helps countries achieve the Sustainable Development Goals.
-> UNDP publishes the annual Human Development Report and the Human Development Index (HDI).""",
ef=[r"The Human Development Index measures health, education and standard of living.", r"UNEP (environment) is headquartered in Nairobi, Kenya."],
hs=r"UNDP का पूरा रूप क्या है?",
ho={"United Nations Development Programme": "संयुक्त राष्ट्र विकास कार्यक्रम", "Union of Nations Development Programme": "यूनियन ऑफ़ नेशंस डेवलपमेंट प्रोग्राम", "Union of Nations Deployment Programme": "यूनियन ऑफ़ नेशंस डिप्लॉयमेंट प्रोग्राम", "United Nations Deployment Programme": "यूनाइटेड नेशंस डिप्लॉयमेंट प्रोग्राम"},
ht=r"UNDP = संयुक्त राष्ट्र विकास कार्यक्रम (1965, न्यूयॉर्क)।",
hx=r"""-> UNDP का पूरा रूप United Nations Development Programme (संयुक्त राष्ट्र विकास कार्यक्रम) है।
-> इसकी स्थापना 1965 में हुई और इसका मुख्यालय न्यूयॉर्क में है।
-> यह गरीबी उन्मूलन और असमानता घटाने के लिए काम करता है और देशों को सतत विकास लक्ष्य प्राप्त करने में मदद करता है।
-> UNDP वार्षिक मानव विकास रिपोर्ट और मानव विकास सूचकांक (HDI) प्रकाशित करता है।""",
hf=[r"मानव विकास सूचकांक स्वास्थ्य, शिक्षा और जीवन-स्तर को मापता है।", r"UNEP (पर्यावरण) का मुख्यालय नैरोबी, केन्या में है।"],
),
61: dict(
et=r"Per-app GPU usage: Task Manager → Processes tab (GPU column).",
es=r"""-> In Windows 10/11 Task Manager, the Processes tab lists every running app with its CPU, memory, disk, network and GPU usage.
-> Its GPU column shows real-time graphics card utilisation for each individual application.
-> The Performance tab shows overall graphs for the whole GPU, not usage per app.
-> App history shows past resource use of Store apps, and Startup manages programs that run at boot.""",
ef=[r"Ctrl + Shift + Esc opens Task Manager directly.", r"The Details tab shows each process with its PID (process identifier)."],
hs=r"आधुनिक विंडोज़ संस्करणों (विंडोज़ 10/11) में, टास्क मैनेजर का कौन-सा टैब उपयोगकर्ताओं को अलग-अलग एप्लिकेशन के लिए ग्राफ़िक्स कार्ड का रियल-टाइम उपयोग देखने देता है?",
ho={"Processes": "प्रोसेसेज़ (Processes)", "Performance": "परफ़ॉर्मेंस (Performance)", "App History": "ऐप हिस्ट्री (App History)", "Startup": "स्टार्टअप (Startup)"},
ht=r"प्रति-ऐप GPU उपयोग: टास्क मैनेजर → Processes टैब (GPU कॉलम)।",
hx=r"""-> विंडोज़ 10/11 के टास्क मैनेजर में Processes टैब हर चल रहे ऐप का CPU, मेमोरी, डिस्क, नेटवर्क और GPU उपयोग दिखाता है।
-> इसका GPU कॉलम प्रत्येक एप्लिकेशन के लिए ग्राफ़िक्स कार्ड का रियल-टाइम उपयोग दिखाता है।
-> Performance टैब पूरे GPU के कुल ग्राफ़ दिखाता है, प्रति-ऐप उपयोग नहीं।
-> App history स्टोर ऐप्स का पिछला संसाधन उपयोग दिखाता है, और Startup बूट पर चलने वाले प्रोग्राम संभालता है।""",
hf=[r"Ctrl + Shift + Esc दबाने से टास्क मैनेजर सीधे खुलता है।", r"Details टैब हर प्रोसेस को उसके PID (प्रोसेस आइडेंटिफ़ायर) के साथ दिखाता है।"],
),
62: dict(
et=r"Faraizi movement: Haji Shariatullah, then his son Dudu Mian.",
es=r"""-> The Faraizi (Farazi) Movement was a 19th-century religious reform and peasant movement in eastern Bengal.
-> It was founded by Haji Shariatullah in 1818 and was later led by his son Muhsinuddin Ahmad, popularly called Dudu Mian.
-> Under Dudu Mian it opposed zamindars, indigo planters and illegal cesses, and he declared that land belonged to God.
-> U Kiang Nongbah led the Jaintia revolt, Birsa Munda the Munda Ulgulan, and Majnu Shah was a leader of the Fakir rebellion.""",
ef=[r"The Faraizis took their name from 'farz' (obligatory religious duties).", r"Titu Mir led the Wahabi-influenced peasant revolt at Barasat (1831)."],
hs=r"19वीं शताब्दी के दौरान बंगाल में फ़राज़ी आंदोलन से निम्नलिखित में से कौन जुड़ा था?",
ho={"Maznoom Shah": "मजनूं शाह", "Dadu Mian": "दादू मियाँ", "U Kiang Nongbah": "यू कियांग नोंगबाह", "Birsa Munda": "बिरसा मुंडा"},
ht=r"फ़राज़ी आंदोलन: हाजी शरीयतुल्लाह, फिर उनके पुत्र दूदू (दादू) मियाँ।",
hx=r"""-> फ़राज़ी आंदोलन 19वीं शताब्दी का पूर्वी बंगाल का धार्मिक सुधार और किसान आंदोलन था।
-> इसकी स्थापना 1818 में हाजी शरीयतुल्लाह ने की और बाद में उनके पुत्र मुहसिनुद्दीन अहमद, जो दूदू (दादू) मियाँ कहलाते थे, ने नेतृत्व किया।
-> दूदू मियाँ के नेतृत्व में इसने ज़मींदारों, नील बागान मालिकों और अवैध करों का विरोध किया, और उन्होंने घोषित किया कि भूमि ईश्वर की है।
-> यू कियांग नोंगबाह ने जयंतिया विद्रोह, बिरसा मुंडा ने मुंडा उलगुलान का नेतृत्व किया, और मजनूं शाह फ़कीर विद्रोह के नेता थे।""",
hf=[r"फ़राज़ियों का नाम 'फ़र्ज़' (अनिवार्य धार्मिक कर्तव्य) से पड़ा।", r"तीतू मीर ने बारासात (1831) में वहाबी-प्रभावित किसान विद्रोह का नेतृत्व किया।"],
),
63: dict(
et=r"Stockholm 1972: first UN conference on the human environment.",
es=r"""-> The United Nations Conference on the Human Environment at Stockholm (June 1972) was the first global meeting that made the environment a major international issue.
-> It adopted the Stockholm Declaration and led to the creation of the United Nations Environment Programme (UNEP).
-> 5 June, the opening day of the conference, is observed as World Environment Day.
-> The Rio Earth Summit (1992), the Johannesburg Summit (2002) and the Doha meeting (2012) came later.""",
ef=[r"India's Prime Minister Indira Gandhi addressed the Stockholm Conference.", r"The Rio Earth Summit adopted Agenda 21 and opened the UNFCCC for signature."],
hs=r"किस वैश्विक घटना ने पहली बार पर्यावरण संरक्षण और विकास पर समन्वित अंतर्राष्ट्रीय कार्रवाई शुरू की?",
ho={"Rio Conference, 1992": "रियो सम्मेलन, 1992", "Doha Climate Meeting, 2012": "दोहा जलवायु बैठक, 2012", "Stockholm Conference, 1972": "स्टॉकहोम सम्मेलन, 1972", "Johannesburg Summit, 2002": "जोहान्सबर्ग शिखर सम्मेलन, 2002"},
ht=r"स्टॉकहोम 1972: मानव पर्यावरण पर पहला संयुक्त राष्ट्र सम्मेलन।",
hx=r"""-> स्टॉकहोम में मानव पर्यावरण पर संयुक्त राष्ट्र सम्मेलन (जून 1972) पहली वैश्विक बैठक थी जिसने पर्यावरण को प्रमुख अंतर्राष्ट्रीय मुद्दा बनाया।
-> इसमें स्टॉकहोम घोषणा अपनाई गई और संयुक्त राष्ट्र पर्यावरण कार्यक्रम (UNEP) की स्थापना हुई।
-> सम्मेलन के पहले दिन, 5 जून, को विश्व पर्यावरण दिवस के रूप में मनाया जाता है।
-> रियो पृथ्वी सम्मेलन (1992), जोहान्सबर्ग शिखर सम्मेलन (2002) और दोहा बैठक (2012) बाद में हुए।""",
hf=[r"भारत की प्रधानमंत्री इंदिरा गांधी ने स्टॉकहोम सम्मेलन को संबोधित किया।", r"रियो पृथ्वी सम्मेलन में एजेंडा 21 अपनाया गया और UNFCCC हस्ताक्षर के लिए खोला गया।"],
),
64: dict(
et=r"Proteins → amino acids; carbohydrates → glucose; fats → fatty acids + glycerol.",
es=r"""-> Proteins are polymers of amino acids, so their complete digestion yields amino acids.
-> Pepsin in the stomach begins protein digestion, and trypsin (from the pancreas) and peptidases in the small intestine complete it.
-> The amino acids are absorbed by the villi of the small intestine into the blood.
-> Glucose is the end product of carbohydrate digestion, while fatty acids and glycerol come from fats.""",
ef=[r"Bile from the liver emulsifies fats but contains no digestive enzyme.", r"Saliva contains salivary amylase (ptyalin), which starts starch digestion in the mouth."],
hs=r"मनुष्यों में प्रोटीन के पूर्ण पाचन से किन पदार्थों का निर्माण होता है?",
ho={"Glucose": "ग्लूकोज़", "Amino acids": "अमीनो अम्ल", "Fatty acids": "वसा अम्ल", "Glycerol": "ग्लिसरॉल"},
ht=r"प्रोटीन → अमीनो अम्ल; कार्बोहाइड्रेट → ग्लूकोज़; वसा → वसा अम्ल + ग्लिसरॉल।",
hx=r"""-> प्रोटीन अमीनो अम्लों के बहुलक हैं, अतः उनके पूर्ण पाचन से अमीनो अम्ल बनते हैं।
-> आमाशय में पेप्सिन प्रोटीन का पाचन शुरू करता है, और छोटी आँत में ट्रिप्सिन (अग्न्याशय से) तथा पेप्टिडेज़ इसे पूरा करते हैं।
-> अमीनो अम्ल छोटी आँत के रसांकुरों (विलाई) द्वारा रक्त में अवशोषित होते हैं।
-> ग्लूकोज़ कार्बोहाइड्रेट पाचन का अंतिम उत्पाद है, जबकि वसा अम्ल और ग्लिसरॉल वसा से बनते हैं।""",
hf=[r"यकृत का पित्त वसा का पायसीकरण करता है, पर इसमें कोई पाचक एंज़ाइम नहीं होता।", r"लार में लार एमाइलेज़ (टायलिन) होता है, जो मुँह में स्टार्च का पाचन शुरू करता है।"],
),
65: dict(
et=r"DPSP: non-justiciable but fundamental in governance (Article 37).",
es=r"""-> The Directive Principles of State Policy are in Part IV (Articles 36–51) of the Constitution.
-> Article 37 says they are not enforceable by any court (non-justiciable).
-> The same Article declares them "fundamental in the governance of the country", and the State must apply them in making laws.
-> They are not mere administrative rules, and emergencies do not make them justiciable.""",
ef=[r"The idea of Directive Principles was borrowed from the Irish Constitution.", r"Fundamental Rights (Part III) are justiciable, unlike the Directive Principles."],
hs=r"भारतीय संविधान के अनुसार, राज्य के नीति निदेशक तत्व ___________ हैं।",
ho={"Purely administrative rules": "पूर्णतः प्रशासनिक नियम", "Justiciable and legally enforceable": "न्यायोचित और कानूनी रूप से प्रवर्तनीय", "Non-justiciable but fundamental in governance": "गैर-न्यायोचित, परंतु शासन में मूलभूत", "Justiciable only during emergencies": "केवल आपातकाल के दौरान न्यायोचित"},
ht=r"नीति निदेशक तत्व: गैर-न्यायोचित, परंतु शासन में मूलभूत (अनुच्छेद 37)।",
hx=r"""-> राज्य के नीति निदेशक तत्व संविधान के भाग IV (अनुच्छेद 36–51) में हैं।
-> अनुच्छेद 37 के अनुसार इन्हें किसी न्यायालय द्वारा लागू नहीं कराया जा सकता (गैर-न्यायोचित)।
-> यही अनुच्छेद इन्हें "देश के शासन में मूलभूत" घोषित करता है, और राज्य को विधि बनाते समय इन्हें लागू करना चाहिए।
-> ये मात्र प्रशासनिक नियम नहीं हैं, और आपातकाल में भी ये न्यायोचित नहीं होते।""",
hf=[r"नीति निदेशक तत्वों का विचार आयरलैंड के संविधान से लिया गया।", r"मौलिक अधिकार (भाग III) न्यायोचित हैं, नीति निदेशक तत्वों के विपरीत।"],
),
66: dict(
et=r"Article 9: voluntarily acquiring foreign citizenship ends Indian citizenship.",
es=r"""-> Article 9 says that a person who voluntarily acquires the citizenship of a foreign State shall not be a citizen of India.
-> By ending Indian citizenship on acquiring another, it implicitly rules out dual citizenship.
-> Article 5 deals with citizenship at the commencement of the Constitution, and Article 7 with migrants to Pakistan.
-> Article 3 is about forming new States and altering State boundaries, not citizenship.""",
ef=[r"Overseas Citizenship of India (OCI) gives long-term visa benefits but is not dual citizenship.", r"Article 11 empowers Parliament to make laws on citizenship (Citizenship Act, 1955)."],
hs=r"कौन-सा अनुच्छेद भारत में 'दोहरी नागरिकता' को अप्रत्यक्ष रूप से प्रतिबंधित करता है?",
ho={"Article 5": "अनुच्छेद 5", "Article 9": "अनुच्छेद 9", "Article 7": "अनुच्छेद 7", "Article 3": "अनुच्छेद 3"},
ht=r"अनुच्छेद 9: स्वेच्छा से विदेशी नागरिकता लेने पर भारतीय नागरिकता समाप्त।",
hx=r"""-> अनुच्छेद 9 कहता है कि जो व्यक्ति स्वेच्छा से किसी विदेशी राज्य की नागरिकता प्राप्त करता है, वह भारत का नागरिक नहीं रहेगा।
-> दूसरी नागरिकता लेने पर भारतीय नागरिकता समाप्त करके यह अप्रत्यक्ष रूप से दोहरी नागरिकता को रोकता है।
-> अनुच्छेद 5 संविधान के प्रारंभ पर नागरिकता से, और अनुच्छेद 7 पाकिस्तान गए प्रवासियों से संबंधित है।
-> अनुच्छेद 3 नए राज्यों के गठन और राज्यों की सीमाओं में परिवर्तन से संबंधित है, नागरिकता से नहीं।""",
hf=[r"भारत की प्रवासी नागरिकता (OCI) दीर्घकालिक वीज़ा लाभ देती है, पर यह दोहरी नागरिकता नहीं है।", r"अनुच्छेद 11 संसद को नागरिकता पर कानून बनाने का अधिकार देता है (नागरिकता अधिनियम, 1955)।"],
),
67: dict(
et=r"Siddhesvara Mahadeva (Barakar, Bengal): Nagara (rekha-deul) style, not Dravidian.",
es=r"""-> The Siddhesvara Mahadeva temple at Barakar (West Bengal) has a tall curvilinear rekha-deul shikhara — the Nagara style of North and East India, not Dravidian.
-> The Shore Temple at Mamallapuram was built by the Pallava king Narasimhavarman II (Rajasimha) in the Dravidian style.
-> The Brihadeeswara temple at Thanjavur was built by Rajaraja I, with a towering vimana — a classic Dravidian temple.
-> The temple at Gangaikondacholapuram was built by Rajendra I, also in the Dravidian style.""",
ef=[r"The Brihadeeswara temple is part of the UNESCO 'Great Living Chola Temples' site.", r"The Kailasanatha temple at Kanchipuram is another early Pallava Dravidian temple."],
hs=r"निम्नलिखित में से कौन-सा मंदिर द्रविड़ मंदिर स्थापत्य शैली का प्रमुख उदाहरण नहीं है?",
ho={"Siddhesvara Mahadeva Temple": "सिद्धेश्वर महादेव मंदिर", "Shore Temple": "शोर (तटीय) मंदिर", "Gangaikondacholapuram Temple": "गंगईकोंडचोलपुरम मंदिर", "Brihadeeswara Temple": "बृहदीश्वर मंदिर"},
ht=r"सिद्धेश्वर महादेव (बराकर, बंगाल): नागर (रेख-देउल) शैली, द्रविड़ नहीं।",
hx=r"""-> बराकर (पश्चिम बंगाल) के सिद्धेश्वर महादेव मंदिर में ऊँचा वक्ररेखीय रेख-देउल शिखर है — यह उत्तर और पूर्व भारत की नागर शैली है, द्रविड़ नहीं।
-> महाबलीपुरम का शोर मंदिर पल्लव राजा नरसिंहवर्मन द्वितीय (राजसिंह) ने द्रविड़ शैली में बनवाया।
-> तंजावुर का बृहदीश्वर मंदिर राजराज प्रथम ने ऊँचे विमान के साथ बनवाया — यह द्रविड़ मंदिर का उत्कृष्ट उदाहरण है।
-> गंगईकोंडचोलपुरम का मंदिर राजेंद्र प्रथम ने बनवाया, यह भी द्रविड़ शैली का है।""",
hf=[r"बृहदीश्वर मंदिर यूनेस्को के 'महान जीवंत चोल मंदिर' स्थल का हिस्सा है।", r"कांचीपुरम का कैलाशनाथ मंदिर एक अन्य प्रारंभिक पल्लव द्रविड़ मंदिर है।"],
),
68: dict(
et=r"Gandharva: the formal, sacred music of ancient India; Gana was its lighter counterpart.",
es=r"""-> In ancient India, Gandharva was the formal, rule-bound music regarded as divine and used in ritual contexts, as described in the Natyashastra tradition.
-> Gana was the more flexible music used in drama and entertainment, open to regional variety.
-> Prabandha was a later medieval form of composed songs.
-> Dhrupad developed much later, in the medieval period, especially at the court of Raja Man Singh Tomar of Gwalior.""",
ef=[r"Bharata's Natyashastra is the oldest surviving Indian treatise on drama, music and dance.", r"Tansen of Akbar's court was a famous Dhrupad singer."],
hs=r"प्राचीन भारत में निम्नलिखित में से किस संगीत शैली को औपचारिक और दैवीय माना जाता था?",
ho={"Dhrupad": "ध्रुपद", "Gandharva": "गांधर्व", "Gana": "गान", "Prabandh": "प्रबंध"},
ht=r"गांधर्व: प्राचीन भारत का औपचारिक, पवित्र संगीत; गान उसका हल्का रूप था।",
hx=r"""-> प्राचीन भारत में गांधर्व औपचारिक, नियमबद्ध संगीत था जिसे दैवीय माना जाता था और धार्मिक संदर्भों में प्रयोग होता था, जैसा नाट्यशास्त्र परंपरा में वर्णित है।
-> गान अधिक लचीला संगीत था, जो नाटक और मनोरंजन में प्रयुक्त होता था और जिसमें क्षेत्रीय विविधता थी।
-> प्रबंध बाद के मध्यकाल का रचित गीतों का रूप था।
-> ध्रुपद बहुत बाद, मध्यकाल में विकसित हुआ, विशेषकर ग्वालियर के राजा मान सिंह तोमर के दरबार में।""",
hf=[r"भरत का नाट्यशास्त्र नाटक, संगीत और नृत्य पर उपलब्ध सबसे प्राचीन भारतीय ग्रंथ है।", r"अकबर के दरबार के तानसेन प्रसिद्ध ध्रुपद गायक थे।"],
),
69: dict(
et=r"Red × white → pink F1 = incomplete dominance (blending).",
es=r"""-> When true-breeding red and white parents give pink F1 plants, neither allele is fully dominant.
-> The heterozygote shows an intermediate (blended) phenotype — this is incomplete dominance, as in snapdragon and Mirabilis (four o'clock plant).
-> In the F2 generation the ratio is 1 red : 2 pink : 1 white, so phenotype and genotype ratios are the same.
-> In co-dominance both traits appear together (e.g. AB blood group); in complete dominance F1 would look like one parent; sex-linkage involves genes on sex chromosomes.""",
ef=[r"Carl Correns described incomplete dominance in Mirabilis jalapa.", r"Mendel's monohybrid F2 ratio for complete dominance is 3 : 1."],
hs=r"शुद्ध-प्रजनन वाले लाल फूल और शुद्ध-प्रजनन वाले सफ़ेद फूल वाले पौधों के संकरण में प्रथम संतति (F1) गुलाबी थी। यह किस प्रकार की वंशागति का उदाहरण है?",
ho={"Incomplete Dominance": "अपूर्ण प्रभाविता", "Co-dominance": "सह-प्रभाविता", "Complete Dominance": "पूर्ण प्रभाविता", "Sex-linkage": "लिंग-सहलग्नता"},
ht=r"लाल × सफ़ेद → गुलाबी F1 = अपूर्ण प्रभाविता।",
hx=r"""-> जब शुद्ध-प्रजनन वाले लाल और सफ़ेद जनकों से गुलाबी F1 पौधे बनते हैं, तो कोई भी एलील पूर्णतः प्रभावी नहीं होता।
-> विषमयुग्मजी में मध्यवर्ती (मिश्रित) लक्षण दिखता है — यह अपूर्ण प्रभाविता है, जैसे स्नैपड्रैगन और मिराबिलिस (गुलाबाँस) में।
-> F2 पीढ़ी में अनुपात 1 लाल : 2 गुलाबी : 1 सफ़ेद होता है, अतः लक्षण-प्रारूप और जीन-प्रारूप अनुपात समान होते हैं।
-> सह-प्रभाविता में दोनों लक्षण साथ दिखते हैं (जैसे AB रक्त समूह); पूर्ण प्रभाविता में F1 एक जनक जैसा दिखता; लिंग-सहलग्नता में जीन लिंग गुणसूत्रों पर होते हैं।""",
hf=[r"कार्ल कोरेन्स ने मिराबिलिस जलापा में अपूर्ण प्रभाविता का वर्णन किया।", r"पूर्ण प्रभाविता में मेंडल का एकसंकर F2 अनुपात 3 : 1 होता है।"],
),
70: dict(
et=r"Tropical deciduous (monsoon) forests: teak and sal.",
es=r"""-> Tropical deciduous (monsoon) forests are the most widespread forests of India, found where rainfall is about 70–200 cm.
-> Teak and sal are the most characteristic trees of these forests, which shed their leaves in the dry season.
-> Mangroves grow in tidal swamps of deltas (e.g. the Sundarbans).
-> Deodar and fir are coniferous trees of the Himalayan montane forests.""",
ef=[r"Other trees of the moist deciduous forests are shisham, sandalwood, khair and mahua.", r"Tropical evergreen forests (ebony, mahogany, rosewood) occur where rainfall exceeds 200 cm."],
hs=r"निम्नलिखित में से कौन-सा वृक्ष भारत के उष्णकटिबंधीय पर्णपाती वनों की विशेषता है?",
ho={"Mangrove": "मैंग्रोव", "Deodar": "देवदार", "Teak": "सागौन", "Fir": "फ़र"},
ht=r"उष्णकटिबंधीय पर्णपाती (मानसूनी) वन: सागौन और साल।",
hx=r"""-> उष्णकटिबंधीय पर्णपाती (मानसूनी) वन भारत के सबसे विस्तृत वन हैं, जो लगभग 70–200 cm वर्षा वाले क्षेत्रों में मिलते हैं।
-> सागौन और साल इन वनों के सबसे विशिष्ट वृक्ष हैं, जो शुष्क ऋतु में पत्तियाँ गिरा देते हैं।
-> मैंग्रोव डेल्टाओं के ज्वारीय दलदलों (जैसे सुंदरबन) में उगते हैं।
-> देवदार और फ़र हिमालय के पर्वतीय वनों के शंकुधारी वृक्ष हैं।""",
hf=[r"आर्द्र पर्णपाती वनों के अन्य वृक्ष शीशम, चंदन, खैर और महुआ हैं।", r"उष्णकटिबंधीय सदाबहार वन (आबनूस, महोगनी, रोज़वुड) 200 cm से अधिक वर्षा वाले क्षेत्रों में होते हैं।"],
),
}
