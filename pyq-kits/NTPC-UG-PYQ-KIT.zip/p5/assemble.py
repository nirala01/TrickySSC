import sys, os, shutil, time
sys.path.insert(0, "/home/claude/p5")
from base import *

K = int(sys.argv[1])
E = load_edits(K)
PREFIX = E.META["PREFIX"]
hdr, Q = parse_txt(f"{OUT}/{PREFIX}-questions-EN.txt")
EXAM, YEAR = hdr["EXAM"], hdr["YEAR"]
D = load_authoring(K)
assert sorted(D) == list(range(1, 101)), f"authoring covers {len(D)}"
CH = E.CH

qe, qh, se, sh = [], [], [], []
for n in range(1, 101):
    b, a, key = Q[n], D[n], Q[n]["ANSWER"]
    qe.append([n, b["SUBJECT"], CH[n], EXAM, YEAR, b["TEXT"], b["A"], b["B"], b["C"], b["D"], key])
    qh.append([n, b["SUBJECT"], CH[n], EXAM, YEAR, a["hs"], *hi_opts(Q, n, a.get("ho", {})), key])
    se.append([n, to_html(a["es"], a.get("ef"), key, "EN"), a["et"].strip(), b["CONCEPT"]])
    sh.append([n, to_html(a["hx"], a.get("hf"), key, "HI"), a["ht"].strip(), b["CONCEPT"]])

files = {f"{PREFIX}-questions-EN.csv": (QH, qe), f"{PREFIX}-questions-HI.csv": (QH, qh),
         f"{PREFIX}-solutions-EN.csv": (SH, se), f"{PREFIX}-solutions-HI.csv": (SH, sh)}
for name, (h, rows) in files.items():
    write_csv(f"{OUT}/{name}", h, rows)
print("written", list(files))
