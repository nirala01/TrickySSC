"""PROMPT-5-NTPC shared base — set-agnostic. Every subject rule keys on SUBJ[n], never on n."""
import re, csv, os, importlib.util

SUBJECTS = ("General Awareness", "Mathematics", "General Intelligence and Reasoning")
OUT = "/home/claude/out"


def load_edits(K):
    spec = importlib.util.spec_from_file_location(f"edits{K}", f"/home/claude/w/s{K}/edits.py")
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m


def parse_txt(path):
    s = open(path, encoding="utf-8").read()
    hdr = dict(re.findall(r"^(EXAM|YEAR|PAPER|LANG): (.*)$", s, re.M))
    Q = {}
    for m in re.finditer(r"^\[Q(\d+)\]\n((?:.+\n?)*)", s, re.M):
        b = {}
        for line in m.group(2).splitlines():
            mm = re.match(r"^(SUBJECT|CONCEPT|TEXT|A|B|C|D|ANSWER): ?(.*)$", line)
            if mm: b[mm.group(1)] = mm.group(2)
        Q[int(m.group(1))] = b
    assert sorted(Q) == list(range(1, 101)), "txt must have Q1..Q100"
    return hdr, Q


def esc(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def fix_colon(s):
    parts = re.split(r"(\\\(.*?\\\))", s)
    return "".join(p if p.startswith("\\(") else re.sub(r"\s+:", ":", p) for p in parts)


def h_step(t):
    return ('<div style="margin-top:8px;"><strong style="color:#155724;font-size:0.88rem;">'
            + t + "</strong></div>")


def h_bul(t):
    return ('<div style="margin-left:14px;color:#374151;font-size:0.87rem;line-height:1.7;">'
            '<span style="color:#FF6B00;font-weight:700;margin-right:4px;">&mdash;</span>'
            + t + "</div>")


def h_verdict(x, lang):
    lab = "सही उत्तर: विकल्प" if lang == "HI" else "Correct Answer: Option"
    return ('<div style="margin-top:8px;font-weight:700;color:#00A86B;font-size:0.88rem;">'
            "&there4; " + lab + " (" + x + ")</div>")


STEP = re.compile(r"^(?:Step|चरण)\s+(\d+):\s*(.*)$")


def to_html(raw, facts, correct, lang):
    out = []
    for line in raw.strip().split("\n"):
        s = line.strip()
        if not s:
            continue
        m = STEP.match(s)
        if m:
            lab = "चरण" if lang == "HI" else "Step"
            out.append(h_step(lab + " " + m.group(1) + ": " + esc(fix_colon(m.group(2)))))
        elif s.startswith("-> "):
            out.append(h_bul(esc(fix_colon(s[3:]))))
        else:
            out.append(h_bul(esc(fix_colon(s))))
    if facts:
        out.append(h_step("अतिरिक्त तथ्य:" if lang == "HI" else "Exam Facts:"))
        for f in facts:
            out.append(h_bul(esc(fix_colon(f))))
    out.append(h_verdict(correct, lang))
    return "".join(out)


def hi_opts(Q_EN, n, mp):
    """mp = {<exact EN option text>: <HI option text>}; options absent from mp stay English."""
    texts = [Q_EN[n][L] for L in "ABCD"]
    extra = [k for k in mp if k not in texts]
    assert not extra, f"Q{n} extra keys {extra}"
    return [mp.get(t, t) for t in texts]


QH = ["qNum", "subject", "chapterId", "exam", "year", "text", "option_A", "option_B", "option_C", "option_D", "correct"]
SH = ["qNum", "explanation", "trick", "concept"]


def write_csv(path, header, rows):
    with open(path, "w", newline="", encoding="utf-8-sig") as fh:
        w = csv.writer(fh); w.writerow(header); w.writerows(rows)


def load_authoring(K):
    """Merge s{K}/a1..a4 dicts into one D."""
    D = {}
    for i in range(1, 5):
        p = f"/home/claude/w/s{K}/a{i}.py"
        spec = importlib.util.spec_from_file_location(f"a{K}_{i}", p)
        m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
        for n, v in m.D.items():
            assert n not in D, f"Q{n} authored twice"
            D[n] = v
    return D
