"""Row-level negative controls. usage: controls.py K"""
import sys, os, re, csv, shutil, tempfile
sys.path.insert(0, "/home/claude/p5")
from base import *
import checks

K = int(sys.argv[1]); E = load_edits(K); P = E.META["PREFIX"]
hdr, Q = parse_txt(f"{OUT}/{P}-questions-EN.txt")
SUBJ = {n: Q[n]["SUBJECT"] for n in Q}
MATHS = [n for n in SUBJ if SUBJ[n] == "Mathematics"]; GA = [n for n in SUBJ if SUBJ[n] == "General Awareness"]
REAS = [n for n in SUBJ if SUBJ[n] == "General Intelligence and Reasoning"]
NAMES = {"qe": "questions-EN", "qh": "questions-HI", "se": "solutions-EN", "sh": "solutions-HI"}

def load(tmp, k):
    p = f"{tmp}/{P}-{NAMES[k]}.csv"
    with open(p, encoding="utf-8-sig") as fh: rows = list(csv.reader(fh))
    return p, rows

def save(p, rows, bom=True):
    with open(p, "w", newline="", encoding="utf-8-sig" if bom else "utf-8") as fh: csv.writer(fh).writerows(rows)

def find(rows, n, col):
    h = rows[0]; ci = h.index(col); ri = [i for i, r in enumerate(rows) if r and r[0] == str(n)]
    assert ri, (n, col); return ri[0], ci

def steps_count(rows, n):
    r, c = find(rows, n, "explanation"); return len(re.findall(r"<strong[^>]*>(?:Step|चरण) \d+:", rows[r][c]))

results = []
def control(name, edits):
    tmp = tempfile.mkdtemp()
    for k in NAMES: shutil.copy(f"{OUT}/{P}-{NAMES[k]}.csv", tmp)
    changed = False
    for k, fn in edits:
        p, rows = load(tmp, k)
        before = [list(r) for r in rows]
        res = fn(rows, p)
        if res == "SAVED": changed = True; continue
        if rows != before: changed = True
        save(p, rows)
    assert changed, f"control {name} did not change anything"
    try:
        F, _ = checks.run(K, tmp); caught = bool(F)
    except Exception as e:
        caught = True; F = [f"CRASH {e}"]
    results.append((name, caught)); shutil.rmtree(tmp)

def setcell(n, col, f):
    def g(rows, p):
        r, c = find(rows, n, col); rows[r][c] = f(rows[r][c])
    return g

def three_step(rows_name, pool):
    p, rows = load(OUT, rows_name)
    for n in pool:
        if steps_count(rows, n) == 3: return n
    raise AssertionError("no 3-step row")

m0, g0, r0 = MATHS[0], GA[0], REAS[0]
dfrac_row = next(n for n in range(1, 101) if "\\dfrac" in load(OUT, "se")[1][n][1])
times_row = next(n for n in range(1, 101) if "\\times" in load(OUT, "se")[1][n][1])
m3 = three_step("se", MATHS); r3 = three_step("sh", REAS)
bar_row = next((n for n in range(1, 101) if "||" in Q[n]["TEXT"]), None)
br_row = next(n for n in range(1, 101) if "[BR]" in Q[n]["TEXT"])
tab_row = next((n for n in range(1, 101) if " | " in Q[n]["TEXT"]), None)
digit_row = next(n for n in MATHS if re.search(r"\d", Q[n]["A"]))
hi_opt_row = next(n for n in GA if Q[n]["A"] != load(OUT, "qh")[1][n][6])

control("question text drift", [("qe", setcell(5, "text", lambda s: s + " x"))])
control("option altered", [("qe", setcell(5, "option_B", lambda s: s + "!"))])
control("EN key flip", [("qe", setcell(1, "correct", lambda s: "A" if s != "A" else "B"))])
control("HI key flip only", [("qh", setcell(1, "correct", lambda s: "A" if s != "A" else "B"))])
control("subject misspelt", [("qe", setcell(r0, "subject", lambda s: "General Intelligence & Reasoning"))])
control("subject swapped one file", [("qh", setcell(g0, "subject", lambda s: "Mathematics"))])
control("subject differs from txt", [("qe", setcell(g0, "subject", lambda s: "Mathematics")), ("qh", setcell(g0, "subject", lambda s: "Mathematics"))])
control("wrong exam", [("qe", setcell(3, "exam", lambda s: "ssc-cgl"))])
control("wrong year HI", [("qh", setcell(3, "year", lambda s: "2025"))])
control("dropped row", [("se", lambda rows, p: rows.pop(50))])
control("101st row", [("qe", lambda rows, p: rows.append(["101"] + rows[1][1:]))])
control("renamed header", [("qe", lambda rows, p: rows[0].__setitem__(5, "question"))])
def strip_bom(rows, p): save(p, rows, bom=False); return "SAVED"
control("stripped BOM", [("sh", strip_bom)])
control("empty cell", [("se", setcell(7, "trick", lambda s: ""))])
control("chapterId not in whitelist", [("qe", setcell(g0, "chapterId", lambda s: "ga.space")), ("qh", setcell(g0, "chapterId", lambda s: "ga.space"))])
control("chapterId family != subject", [("qe", setcell(g0, "chapterId", lambda s: "quant.percentage")), ("qh", setcell(g0, "chapterId", lambda s: "quant.percentage"))])
control("chapterId EN != HI", [("qh", setcell(m0, "chapterId", lambda s: "quant.other" if s != "quant.other" else "quant.average"))])
control("chapterId column missing", [("qe", lambda rows, p: [r.pop(2) for r in rows])])
control("concept drift", [("se", setcell(9, "concept", lambda s: s + " x"))])
control("concept translated", [("sh", setcell(9, "concept", lambda s: "श्रृंखला"))])
control("verdict removed", [("se", setcell(10, "explanation", lambda s: re.sub(r'<div style="margin-top:8px;font-weight:700;color:#00A86B.*$', "", s)))])
control("wrong verdict letter", [("sh", setcell(10, "explanation", lambda s: re.sub(r"\(([A-D])\)</div>$", lambda m: "(" + ("A" if m.group(1) != "A" else "B") + ")</div>", s)))])
def drop_step(s):
    i = [m.start() for m in re.finditer(r'<div style="margin-top:8px;"><strong', s)]; j = s.find("</div>", i[-1]) + 6
    return s[:i[-1]] + s[j:]
control("steps<3 EN (Maths)", [("se", setcell(m3, "explanation", drop_step))])
control("steps<3 HI (Reasoning)", [("sh", setcell(r3, "explanation", drop_step))])
control("GA facts removed EN", [("se", setcell(g0, "explanation", lambda s: s.replace("Exam Facts:", "Notes")))])
control("GA facts removed HI", [("sh", setcell(g0, "explanation", lambda s: s.replace("अतिरिक्त तथ्य:", "टिप्पणी")))])
def drop_bullet(s):
    k = s.find('<div style="margin-left:14px'); j = s.find("</div>", k) + 6; return s[:k] + s[j:]
control("GA bullets<4", [("se", setcell(g0, "explanation", drop_bullet))])
control("hard-coded Option (X)", [("se", setcell(m0, "trick", lambda s: s + " Option (C) is right."))])
control("hard-coded विकल्प (X)", [("sh", setcell(m0, "trick", lambda s: s + " विकल्प (C) सही है।"))])
control("Devanagari in EN", [("se", setcell(m0, "trick", lambda s: s + " उत्तर"))])
control("HI stem loses Devanagari", [("qh", setcell(m0, "text", lambda s: Q[m0]["TEXT"]))])
control("HI solution copies EN", [("sh", setcell(5, "explanation", lambda s: load(OUT, "se")[1][5][1]))])
if bar_row: control("HI stem loses ||", [("qh", setcell(bar_row, "text", lambda s: s.replace("||", " ")))])
control("figure tag dropped HI", [("qh", setcell(next(n for n in Q if "[FIGURE-BASED]" in Q[n]["TEXT"]), "text", lambda s: s.replace("[FIGURE-BASED] ", "")))]) if any("[FIGURE-BASED]" in Q[n]["TEXT"] for n in Q) else None
control("HI stem loses [BR]", [("qh", setcell(br_row, "text", lambda s: s.replace("[BR]", " ", 1)))])
if tab_row: control("HI stem loses a table row", [("qh", setcell(tab_row, "text", lambda s: s.rsplit("[BR]", 1)[0]))])
control("HI option digit-set broken", [("qh", setcell(digit_row, "option_A", lambda s: re.sub(r"\d", lambda m: str((int(m.group()) + 1) % 10), s, count=1)))])
control("HI option swapped to another EN option", [("qh", setcell(hi_opt_row, "option_A", lambda s: Q[hi_opt_row]["B"]))])
control("HI option != module", [("qh", setcell(hi_opt_row, "option_C", lambda s: s + " ।"))])
control("dropped backslash dfrac", [("se", setcell(dfrac_row, "explanation", lambda s: s.replace("\\dfrac", "dfrac", 1)))])
control("dropped backslash times", [("se", setcell(times_row, "explanation", lambda s: s.replace("\\times", "times", 1)))])
control("constructed \\costheta", [("se", setcell(m0, "explanation", lambda s: s.replace("\\(", "\\( \\costheta", 1)))])
control("unbalanced paren", [("se", setcell(m0, "explanation", lambda s: s.replace("\\)", "", 1)))])
control("injected \\uXXXX", [("sh", setcell(m0, "trick", lambda s: s + "\\u2212"))])
control("injected TAB", [("se", setcell(m0, "trick", lambda s: s + "\t"))])
control("doubled backslash", [("se", setcell(m0, "explanation", lambda s: s.replace("\\(", "\\\\(", 1)))])
control("B1 padded colon", [("qe", setcell(5, "option_A", lambda s: s + " 4 : 9")), ("qh", setcell(5, "option_A", lambda s: s + " 4 : 9"))])
control("plain-text Rs", [("se", setcell(m0, "trick", lambda s: s + " Rs. 500"))])
control("plain-text x math", [("se", setcell(m0, "trick", lambda s: s + " 12 x 62"))])
control("Devanagari inside span", [("sh", setcell(m0, "explanation", lambda s: s.replace("\\( ", "\\( \\text{मूल्य} ", 1)))])
control("(figure 2) rewritten", [("qh", setcell(5, "option_B", lambda s: "(चित्र 2)"))])
control("<u> in solution", [("se", setcell(g0, "trick", lambda s: s + " <u>x</u>"))])

ok = sum(c for _, c in results)
print(f"controls caught {ok}/{len(results)}"); print("NOT CAUGHT:", [n for n, c in results if not c])
