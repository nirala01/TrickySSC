"""PROMPT-5-NTPC §10 self-check. usage: checks.py K [dir]. Prints FAILURES first."""
import sys, re, csv, collections, importlib.util
sys.path.insert(0, "/home/claude/p5")
from base import *

DEV = re.compile(r"[\u0900-\u097F]")
CH_IDS = set(re.findall(r"^((?:reason|ga|quant)\.[a-z0-9-]+) — ", open("/home/claude/p5/chapter_ids.txt", encoding="utf-8").read(), re.M))
KNOWN = set("""frac dfrac tfrac sqrt text times div pi theta cdot circ left right le ge leq geq neq ne approx angle triangle
alpha beta gamma sin cos tan cot sec cosec csc log quad qquad because therefore Rightarrow rightarrow Leftrightarrow implies
to infty pm mp degree overline underline hat bar vec boxed mathrm mathbf operatorname cdots ldots dots binom sum prod int
lfloor rfloor lceil rceil mid parallel perp sim cong equiv propto in notin cup cap subset supset emptyset forall exists
square triangleq lt gt percent displaystyle large Large small begin end array matrix pmatrix bmatrix cases hline downarrow uparrow
uparrow lambda mu sigma rho phi omega delta Delta epsilon tau nu""".split())


def run(K, d=OUT):
    E = load_edits(K); P = E.META["PREFIX"]
    hdr, Q = parse_txt(f"{OUT}/{P}-questions-EN.txt")
    SUBJ = {n: Q[n]["SUBJECT"] for n in Q}
    F = []
    def rd(name, hdrx):
        raw = open(f"{d}/{P}-{name}.csv", "rb").read()
        if not raw.startswith(b"\xef\xbb\xbf"): F.append(f"{name}: no BOM")
        rows = list(csv.DictReader(open(f"{d}/{P}-{name}.csv", encoding="utf-8-sig")))
        with open(f"{d}/{P}-{name}.csv", encoding="utf-8-sig") as fh: h = next(csv.reader(fh))
        if h != hdrx: F.append(f"{name}: header {h}")
        if [r.get("qNum") for r in rows] != [str(i) for i in range(1, 101)]: F.append(f"{name}: qNum/rows {len(rows)}")
        for r in rows:
            for k, v in r.items():
                if k is None or v is None: F.append(f"{name}: ragged row {r.get('qNum')}"); continue
                if not str(v).strip() and not (k == "trick" and name.startswith("questions")): F.append(f"{name} Q{r['qNum']} empty {k}")
        return {int(r["qNum"]): r for r in rows if (r.get("qNum") or "").isdigit()}
    qe, qh = rd("questions-EN", QH), rd("questions-HI", QH)
    se, sh = rd("solutions-EN", SH), rd("solutions-HI", SH)
    if F and any("qNum/rows" in f or "header" in f for f in F): return F, {}
    keys = collections.Counter()
    for n in range(1, 101):
        b = Q[n]
        for lab, r in (("EN", qe[n]), ("HI", qh[n])):
            if r["subject"] not in SUBJECTS: F.append(f"Q{n} {lab} subject invalid")
            if r["subject"] != SUBJ[n]: F.append(f"Q{n} {lab} subject != txt")
            if r["exam"] != hdr["EXAM"]: F.append(f"Q{n} {lab} exam")
            if r["year"] != hdr["YEAR"]: F.append(f"Q{n} {lab} year")
            cid = r["chapterId"]
            if cid not in CH_IDS: F.append(f"Q{n} {lab} chapterId {cid}")
            fam = {"General Awareness": "ga.", "Mathematics": "quant.", "General Intelligence and Reasoning": "reason."}[SUBJ[n]]
            if not cid.startswith(fam): F.append(f"Q{n} {lab} chapter family")
            if r["correct"] not in "ABCD" or len(r["correct"]) != 1: F.append(f"Q{n} {lab} key")
        if qe[n]["chapterId"] != qh[n]["chapterId"]: F.append(f"Q{n} chapterId EN!=HI")
        if qe[n]["correct"] != b["ANSWER"]: F.append(f"Q{n} EN key != txt")
        if qh[n]["correct"] != qe[n]["correct"]: F.append(f"Q{n} HI key != EN")
        keys[qe[n]["correct"]] += 1
        if qe[n]["text"] != b["TEXT"] or [qe[n][f"option_{L}"] for L in "ABCD"] != [b[L] for L in "ABCD"]: F.append(f"Q{n} EN question drift")
        # solutions
        for lab, r, qrow in (("EN", se[n], qe[n]), ("HI", sh[n], qh[n])):
            ex = r["explanation"]
            vm = re.search(r"&there4; (?:Correct Answer: Option|सही उत्तर: विकल्प) \(([A-D])\)</div>$", ex)
            if not vm or vm.group(1) != qrow["correct"]: F.append(f"Q{n} {lab} verdict")
            body = re.sub(r'<div style="margin-top:8px;font-weight:700;color:#00A86B[^>]*>.*?</div>$', "", ex)
            allt = body + " " + r["trick"]
            if re.search(r"(?:[Oo]ption|विकल्प)\s*\(?([A-Da-d])\)?(?![A-Za-z])", re.sub(r"<[^>]+>", " ", allt)): F.append(f"Q{n} {lab} hard-coded option letter")
            if r["concept"] != b["CONCEPT"]: F.append(f"Q{n} {lab} concept")
            steps = len(re.findall(r"<strong[^>]*>(?:Step|चरण) \d+:", body))
            buls = body.count("&mdash;</span>")
            facts = ("Exam Facts:" in body) if lab == "EN" else ("अतिरिक्त तथ्य:" in body)
            if SUBJ[n] in ("Mathematics", "General Intelligence and Reasoning") and steps < 3: F.append(f"Q{n} {lab} steps {steps}")
            if SUBJ[n] == "General Awareness":
                nf = len(re.findall(r"(?:Exam Facts:|अतिरिक्त तथ्य:)</strong></div>(.*)$", body, re.S)[0].split("&mdash;</span>")) - 1 if facts else 0
                if buls - nf < 4: F.append(f"Q{n} {lab} bullets {buls - nf}")
                if not facts: F.append(f"Q{n} {lab} facts missing")
            if SUBJ[n] == "Mathematics" and "\\(" not in body: F.append(f"Q{n} {lab} maths without KaTeX")
            if re.search(r"<u>|&lt;u&gt;", allt): F.append(f"Q{n} {lab} <u> in solution")
            if re.search(r"\bRs\.?\s*\d", allt) or re.search(r"\d\s*x\s*\d", re.sub(r"\\\(.*?\\\)", "", allt)): F.append(f"Q{n} {lab} plain-text math")
            if re.search(r"[<>]", r["trick"]): F.append(f"Q{n} {lab} raw angle in trick")
        if DEV.search(se[n]["explanation"] + se[n]["trick"]): F.append(f"Q{n} EN solution Devanagari")
        if not DEV.search(sh[n]["explanation"]): F.append(f"Q{n} HI solution no Devanagari")
        if sh[n]["explanation"] == se[n]["explanation"]: F.append(f"Q{n} HI solution copies EN")
        # Hindi question
        hs, es_ = qh[n]["text"], qe[n]["text"]
        if not DEV.search(hs): F.append(f"Q{n} HI stem no Devanagari")
        if ("||" in es_) != ("||" in hs) or hs.count("||") != es_.count("||"): F.append(f"Q{n} HI || mismatch")
        if hs.count("[BR]") != es_.count("[BR]"): F.append(f"Q{n} HI [BR] count")
        if hs.count(" | ") != es_.count(" | "): F.append(f"Q{n} HI table pipes")
        if ("[FIGURE-BASED]" in es_) != ("[FIGURE-BASED]" in hs): F.append(f"Q{n} HI figure tag")
        for L in "ABCD":
            eo, ho = qe[n][f"option_{L}"], qh[n][f"option_{L}"]
            if sorted(re.findall(r"\d", eo)) != sorted(re.findall(r"\d", ho)): F.append(f"Q{n}{L} HI option digits")
            others = [qe[n][f"option_{M}"] for M in "ABCD" if M != L]
            if ho in others and ho != eo: F.append(f"Q{n}{L} HI option equals another EN option")
            if re.search(r"\(figure \d\)", eo) and ho != eo: F.append(f"Q{n}{L} figure label translated")
        # whole-cell scans
        for lab, cells in (("qEN", [qe[n][k] for k in QH[5:10]]), ("qHI", [qh[n][k] for k in QH[5:10]]),
                           ("sEN", [se[n]["explanation"], se[n]["trick"]]), ("sHI", [sh[n]["explanation"], sh[n]["trick"]])):
            for c in cells:
                if c.count("\\(") != c.count("\\)"): F.append(f"Q{n} {lab} unbalanced KaTeX")
                if re.search(r"\\u[0-9a-fA-F]{4}", c) or "\t" in c or "\f" in c or "\v" in c: F.append(f"Q{n} {lab} \\u/TAB/FF")
                if "\\\\" in c: F.append(f"Q{n} {lab} doubled backslash")
                if re.search(r"(?<![\\A-Za-z])(frac|dfrac|tfrac|sqrt|text|operatorname)\{", c): F.append(f"Q{n} {lab} bare brace command")
                for sp in re.findall(r"\\\((.*?)\\\)", c):
                    if DEV.search(sp): F.append(f"Q{n} {lab} Devanagari in KaTeX")
                    if re.search(r"(?<![\\A-Za-z{])(times|div|pi|theta|cdot|circ)(?![A-Za-z])", sp): F.append(f"Q{n} {lab} bare symbol command")
                    for cmd in re.findall(r"\\([A-Za-z]+)", sp):
                        if cmd not in KNOWN: F.append(f"Q{n} {lab} unknown command \\{cmd}")
                if lab.startswith("q"):
                    t = re.sub(r"\\\(.*?\\\)", "KTX", c)
                    if re.search(r"\s:", t): F.append(f"Q{n} {lab} B1 padded colon")
                    if re.search(r"\(figure \d\)", c) and "[FIGURE-BASED]" not in qe[n]["text"]: F.append(f"Q{n} {lab} figure label w/o figure")
                if lab == "qEN" and DEV.search(c): F.append(f"Q{n} qEN Devanagari")
    try:
        A = load_authoring(K)
        for n in range(1, 101):
            exp = [A[n]["hs"], *hi_opts(Q, n, A[n].get("ho", {}))]
            got = [qh[n]["text"]] + [qh[n][f"option_{L}"] for L in "ABCD"]
            if exp != got: F.append(f"Q{n} HI row != recomputed module")
    except Exception as e:
        F.append(f"recompute failed: {e}")
    other = sum(1 for n in qe if qe[n]["chapterId"].endswith(".other"))
    if other >= 4: F.append(f".other count {other}")
    cnt = collections.Counter(SUBJ.values())
    return F, dict(keys=dict(sorted(keys.items())), subjects=dict(cnt), other=other)


if __name__ == "__main__":
    K = int(sys.argv[1]); d = sys.argv[2] if len(sys.argv) > 2 else OUT
    F, info = run(K, d)
    print("FAILURES:", len(F)); [print("  ", f) for f in F[:60]]
    print(info)
