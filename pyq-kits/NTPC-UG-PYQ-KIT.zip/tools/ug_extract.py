"""Extract a QMaths 'Paper Set' RRB NTPC UG PDF: 100 questions, options, green key, images per question."""
import fitz, re, sys, json
SUBJ = {"Quant": "Mathematics", "GA": "General Awareness", "Reasoning": "General Intelligence and Reasoning"}

def lines_of(page):
    W = page.rect.width
    out = []
    for b in page.get_text('dict')['blocks']:
        if b['type'] != 0: continue
        for l in b['lines']:
            sp = [s for s in l['spans'] if s['text'].strip()]
            if not sp: continue
            x0 = min(s['bbox'][0] for s in sp); y0 = min(s['bbox'][1] for s in sp)
            col = 0 if x0 < W / 2 - 10 else 1
            out.append(dict(col=col, x=x0, y=y0, spans=sp, bbox=l['bbox']))
    return out

def extract(path):
    d = fitz.open(path)
    seq = []
    for pno, page in enumerate(d):
        L = lines_of(page)
        imgs = []
        for info in page.get_image_info(xrefs=True):
            x0, y0, x1, y1 = info['bbox']
            if x1 - x0 > 500: continue      # footer banner
            imgs.append(dict(col=0 if x0 < page.rect.width / 2 - 10 else 1, y=y0, bbox=(x0, y0, x1, y1), xref=info['xref'], pno=pno))
        for col in (0, 1):
            items = [('L', l) for l in L if l['col'] == col] + [('I', i) for i in imgs if i['col'] == col]
            items.sort(key=lambda t: t[1]['y'])
            for k, it in items:
                it['pno'] = pno; seq.append((k, it))
    Q = {}; cur = None; mode = None; hdr = None
    for k, it in seq:
        if k == 'I':
            if cur: (cur['opts'][-1]['imgs'] if mode == 'opt' and cur['opts'] else cur['stem_imgs']).append(it)
            continue
        txt = ''.join(s['text'] for s in it['spans']).strip()
        if txt.startswith('Paper Set'): hdr = txt; continue
        if txt in ('✓', 'Blackbook') or txt in SUBJ and len(it['spans']) == 1 and it['spans'][0]['size'] > 11: continue
        m = re.match(r'^Q(\d+)\s+(Quant|GA|Reasoning)$', txt)
        if m:
            cur = Q[int(m.group(1))] = dict(subj=SUBJ[m.group(2)], stem=[], stem_imgs=[], opts=[], pno=it['pno'], y=it['y'], col=it['col']); mode = 'stem'; continue
        if cur is None: continue
        first = it['spans'][0]['text'].strip()
        mm = re.match(r'^([ABCD])\.$', first)
        if mm and it['spans'][0]['font'].endswith('Bold'):
            green = it['spans'][0]['color'] == 0x065f46
            cur['opts'].append(dict(L=mm.group(1), t=''.join(s['text'] for s in it['spans'][1:]).strip(), g=green, imgs=[], spans=it['spans'][1:]))
            mode = 'opt'; continue
        if txt in ('Quant', 'GA', 'Reasoning'): continue
        if mode == 'stem': cur['stem'].append(dict(t=txt, spans=it['spans']))
        else: cur['opts'][-1]['t'] = (cur['opts'][-1]['t'] + ' ' + txt).strip()
    return Q, hdr

if __name__ == '__main__':
    Q, hdr = extract(sys.argv[1])
    print(hdr, len(Q))
    bad = []
    for n in range(1, 101):
        q = Q.get(n)
        if not q: bad.append((n, 'missing')); continue
        g = [o['L'] for o in q['opts'] if o['g']]
        if len(q['opts']) != 4 or [o['L'] for o in q['opts']] != list('ABCD') or len(g) != 1: bad.append((n, len(q['opts']), g))
    print('bad', bad)
