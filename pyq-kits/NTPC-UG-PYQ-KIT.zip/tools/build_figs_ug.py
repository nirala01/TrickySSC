"""Figures docx for a UG set: one stem image per [FIGURE-BASED] question.  usage: build_figs_ug.py K"""
import sys, importlib.util, fitz, io
from docx import Document
from docx.shared import Inches
from PIL import Image
sys.path.insert(0, '/home/claude/tools')
from ug_extract import extract
K = int(sys.argv[1]); SD = f'/home/claude/w/s{K}'
spec = importlib.util.spec_from_file_location('edits', f'{SD}/edits.py'); E = importlib.util.module_from_spec(spec); spec.loader.exec_module(E)
Q, hdr = extract(f'{SD}/src.pdf'); d = fitz.open(f'{SD}/src.pdf')
doc = Document(); doc.add_paragraph(f"{E.META['PAPER']} — figures")
for n in sorted(E.FIGURES):
    im = Q[n]['stem_imgs'][0]
    base = fitz.Pixmap(d, im['xref'])
    pil = Image.frombytes('RGB' if base.n - base.alpha < 4 else 'CMYK', (base.width, base.height), fitz.Pixmap(fitz.csRGB, base).samples if base.n - base.alpha != 3 else (fitz.Pixmap(base, 0) if base.alpha else base).samples)
    sm = d.xref_get_key(im['xref'], 'SMask')
    if sm[0] == 'xref':
        mask = fitz.Pixmap(d, int(sm[1].split()[0]))
        m = Image.frombytes('L', (mask.width, mask.height), mask.samples).resize(pil.size)
        bg = Image.new('RGB', pil.size, 'white'); bg.paste(pil, mask=m); pil = bg
    path = f'{SD}/{E.FIGURES[n]}.png'; pil.save(path)
    doc.add_paragraph(f"Q{n}"); doc.add_paragraph("[figure]")
    doc.add_paragraph().add_run().add_picture(path, width=Inches(min(5.5, pil.width / 96)))
    print('Q', n, pil.size, path)
out = f"/home/claude/out/{E.META['PREFIX']}-figures.docx"; doc.save(out); print(out)
