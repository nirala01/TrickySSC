"""PROMPT-1 builder for a QMaths RRB NTPC UG 'Paper Set' PDF.  usage: python3 build_txt_ug.py <K>"""
import sys, re, importlib.util, collections, os
sys.path.insert(0, '/home/claude/tools')
from ug_extract import extract

K = int(sys.argv[1])
SD = f'/home/claude/w/s{K}'
spec = importlib.util.spec_from_file_location('edits', f'{SD}/edits.py'); E = importlib.util.module_from_spec(spec); spec.loader.exec_module(E)
Q, hdr = extract(f'{SD}/src.pdf')
SUBJECTS = ("General Awareness", "Mathematics", "General Intelligence and Reasoning")

def clean_spans(spans):
    return ''.join(s['text'] for s in spans if s['color'] != 0xffffff)

STRIPPED = {}
def layer_stem(n):
    parts = [clean_spans(l['spans']).strip() for l in Q[n]['stem']]
    parts = [p for p in parts if p]
    if parts and re.fullmatch(r'\d{4,6}', parts[-1]): STRIPPED[n] = parts.pop()      # stray answer-key id line
    if parts:
        m = re.search(r'(?<=[?.)A-Z])(\d{4,6})$', parts[-1])
        if m: STRIPPED[n] = m.group(1); parts[-1] = parts[-1][:m.start()]
    return re.sub(r'\s+', ' ', ' '.join(parts)).strip()

blocks = {}
for n in range(1, 101):
    q = Q[n]
    text = E.TEXT.get(n, layer_stem(n))
    opts = E.OPTS.get(n, [re.sub(r'\s+', ' ', o['t']).strip() for o in q['opts']])
    key = [o['L'] for o in q['opts'] if o['g']][0]
    subj = q['subj']
    blocks[n] = dict(SUBJECT=subj, CONCEPT=E.CONCEPT[n], TEXT=text, A=opts[0], B=opts[1], C=opts[2], D=opts[3], ANSWER=key)

def render(blocks):
    m = E.META
    out = ["# TRICKYSSC QUESTIONS", f"EXAM: {m['EXAM']}", f"YEAR: {m['YEAR']}", f"PAPER: {m['PAPER']}", "LANG: EN", ""]
    for n in sorted(blocks):
        b = blocks[n]
        out += [f"[Q{n}]", f"SUBJECT: {b['SUBJECT']}", f"CONCEPT: {b['CONCEPT']}", f"TEXT: {b['TEXT']}",
                f"A: {b['A']}", f"B: {b['B']}", f"C: {b['C']}", f"D: {b['D']}", f"ANSWER: {b['ANSWER']}", ""]
    return "\n".join(out)

def parse(s):
    R = {}
    for m in re.finditer(r'^\[Q(\d+)\]\n((?:.+\n?)*)', s, re.M):
        body = {}
        for line in m.group(2).splitlines():
            mm = re.match(r'^(SUBJECT|CONCEPT|TEXT|A|B|C|D|ANSWER): ?(.*)$', line)
            if mm: body[mm.group(1)] = mm.group(2)
            elif line.strip(): body.setdefault('_junk', []).append(line)
        R.setdefault(int(m.group(1)), []).append(body)
    return R

def check(s, dup_exempt=()):
    F = []
    if not s.startswith(f"# TRICKYSSC QUESTIONS\nEXAM: {E.META['EXAM']}\n"): F.append('header')
    order = [int(x) for x in re.findall(r'^\[Q(\d+)\]$', s, re.M)]
    if order != list(range(1, 101)): F.append(f'order/count {len(order)}')
    P = parse(s)
    cnt = collections.Counter(); keys = collections.Counter()
    for n in range(1, 101):
        if n not in P or len(P[n]) != 1: F.append(f'Q{n} missing/dup'); continue
        b = P[n][0]
        for f in ('SUBJECT','CONCEPT','TEXT','A','B','C','D','ANSWER'):
            if f not in b or not b[f].strip(): F.append(f'Q{n} {f} missing/blank')
        if '_junk' in b: F.append(f'Q{n} stray line')
        if b.get('SUBJECT') not in SUBJECTS: F.append(f'Q{n} subject {b.get("SUBJECT")}')
        cnt[b.get('SUBJECT')] += 1
        if b.get('ANSWER') not in ('A','B','C','D'): F.append(f'Q{n} answer')
        keys[b.get('ANSWER')] += 1
        for c in [b.get(f, '') for f in ('TEXT','A','B','C','D')]:
            t = re.sub(r'\\\(.*?\\\)', 'KTX', c)
            if re.search(r'\s:', t): F.append(f'Q{n} B1 padded colon')
            if re.search(r'\(\s*\)|use \)', t): F.append(f'Q{n} empty-paren residue')
            if re.search(r'\b(cm|m|km|x|s)[23]\b', t): F.append(f'Q{n} flat superscript')
            if re.search(r'[<>]', re.sub(r'</?u>', '', c)): F.append(f'Q{n} raw angle bracket')
            if c.count(r'\(') != c.count(r'\)'): F.append(f'Q{n} unbalanced KaTeX')
            for sp in re.findall(r'\\\((.*?)\\\)', c):
                if re.search(r'(?<![\\A-Za-z])(frac|dfrac|sqrt|times|div|text|pi)(?![A-Za-z])', sp): F.append(f'Q{n} bare command')
            if re.search(r'\\u[0-9a-fA-F]{4}', c) or '\t' in c: F.append(f'Q{n} \\u/TAB')
            if re.search(r'[\u0900-\u097F]', c): F.append(f'Q{n} Devanagari')
        if b.get('TEXT', '').count('||') > 1: F.append(f'Q{n} extra ||')
        if re.search(r'[?.)]\s?\d{3,}$', b.get('TEXT', '')): F.append(f'Q{n} trailing white-span digits')
        opts = [b.get(L) for L in 'ABCD']
        if len(set(opts)) < 4 and n not in dup_exempt: F.append(f'Q{n} duplicate options')
        if re.fullmatch(r'[A-D]\.', (b.get('A') or '')): F.append(f'Q{n} image option left as label')
    return F, cnt, keys

if __name__ == '__main__':
    s = render(blocks)
    F, cnt, keys = check(s)
    g = sum(1 for n in Q for o in Q[n]['opts'] if o['g'])
    if g != 100: F.append(f'green {g}')
    drift = [f'Q{n}' for n in range(1, 101) if blocks[n]['TEXT'] != layer_stem(n)]
    figs = [n for n in blocks if '[FIGURE-BASED]' in blocks[n]['TEXT']]
    imgq = [n for n in Q if Q[n]['stem_imgs'] or any(o['imgs'] for o in Q[n]['opts'])]
    os.makedirs('/home/claude/out', exist_ok=True)
    out = f'/home/claude/out/{E.META["PREFIX"]}-questions-EN.txt'
    open(out, 'w', encoding='utf-8').write(s)
    print('FAILURES:', F)
    print('subjects', dict(cnt), 'keys', dict(sorted(keys.items())))
    print('text overridden', drift)
    print('stray digits stripped', STRIPPED)
    print('figures', figs, 'questions with images', imgq, 'bytes', len(s.encode()))
    def mut(name, f):
        t = f(s); assert t != s, name
        FF, _, _ = check(t); return name, bool(FF)
    ctl = [
        mut('drop block', lambda x: re.sub(r'\[Q37\]\n(?:.+\n)+\n', '', x, count=1)),
        mut('renumber', lambda x: x.replace('[Q12]\n', '[Q13]\n', 1)),
        mut('subject misspelt', lambda x: x.replace('SUBJECT: General Intelligence and Reasoning', 'SUBJECT: General Intelligence & Reasoning', 1)),
        mut('blank option', lambda x: re.sub(r'(\[Q5\]\n(?:.+\n){3})A: .*', r'\1A: ', x, count=1)),
        mut('break bracket', lambda x: x.replace(r'\)', '', 1)),
        mut('padded colon', lambda x: x.replace('A: ', 'A: 4 : 9 ', 1)),
        mut('white digits', lambda x: re.sub(r'(\[Q2\]\n(?:.+\n){2}TEXT: .*\?)', r'\g<1>2078', x, count=1)),
        mut('flat superscript', lambda x: x.replace('cm²', 'cm2', 1)),
        mut('bad answer', lambda x: x.replace('ANSWER: ', 'ANSWER: E', 1)),
        mut('raw <', lambda x: x.replace('TEXT: ', 'TEXT: a < b ', 1)),
        mut('Devanagari', lambda x: x.replace('TEXT: ', 'TEXT: प्रश्न ', 1)),
        mut('bare dfrac', lambda x: x.replace(r'\dfrac', 'dfrac', 1)),
        mut('duplicate option', lambda x: re.sub(r'(\[Q6\]\n(?:.+\n){3}A: (.*)\nB: ).*', r'\1\2', x, count=1)),
        mut('wrong exam', lambda x: x.replace('EXAM: rrb-ntpc-ug', 'EXAM: rrb-ntpc', 1)),
    ]
    if '||' in s: ctl.append(mut('extra ||', lambda x: x.replace('||', '||x||', 1)))
    print('controls', sum(c for _, c in ctl), '/', len(ctl), [n for n, c in ctl if not c])
